# MiniMax TTS 代码修正计划

## 问题分析

根据 `minimax文档.md`（同步语音合成官方文档），当前实现存在以下问题：

| 问题 | 当前实现 | 文档标准 | 严重程度 |
|------|----------|----------|----------|
| 协议错误 | HTTP POST | WebSocket | ⚠️ 高 |
| 参数错误 | 使用 group_id | 不需要 group_id | ⚠️ 高 |
| 端点错误 | `/v1/t2a_v2?GroupId=xxx` | `wss://api.minimaxi.com/ws/v1/t2a_v2` | ⚠️ 高 |

## 修正方案

### 1. 修改 MiniMaxTTSProvider

将 HTTP 实现改为 WebSocket 实现，符合官方文档标准。

### 2. 移除 group_id 配置

从所有配置文件中移除不需要的 group_id 参数。

### 3. 更新配置文件

简化 MiniMax 配置，移除不必要的参数。

## 文件修改清单

| 文件 | 修改内容 |
|------|----------|
| `tts_service.py` | 重写 MiniMaxTTSProvider 使用 WebSocket |
| `config.yaml` | 移除 group_id 配置项 |
| `tts_config_loader.py` | 移除 group_id 参数定义 |

## 预期结果

修正后代码将：
1. 使用 WebSocket 协议与 MiniMax API 通信
2. 不再需要 group_id 参数
3. 完全符合官方文档标准

## 风险评估

| 风险 | 影响 | 缓解措施 |
|------|------|----------|
| WebSocket 连接问题 | 网络不稳定可能导致连接失败 | 添加重试机制和超时处理 |
| 异步处理 | WebSocket 是异步的，需要调整代码流程 | 使用异步/同步包装 |