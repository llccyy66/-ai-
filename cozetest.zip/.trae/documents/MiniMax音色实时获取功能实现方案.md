# MiniMax可用音色实时获取功能实现方案

## 背景

根据MiniMax官方文档，MiniMax提供了专门的API来动态获取可用音色列表：
- **API地址**: `POST https://api.minimaxi.com/v1/get_voice`
- **功能**: 查询当前账号下可调用的全部音色ID（包括系统音色、复刻音色、文生音色）

当前系统中`MiniMax`的音色是**写死在代码里**的（`tts_config_loader.py`中只定义了10个基础音色），无法获取完整的100+系统音色列表。

## 方案设计

### 方案一：在`tts_dynamic_discoverer.py`中添加MiniMax支持（推荐）

#### 1. 核心思路
- 在现有的`DynamicTTSConfigDiscoverer`类中添加`discover_minimax_voices`方法
- 直接调用MiniMax的`GET /v1/get_voice` API获取音色列表
- 复用现有的缓存机制，避免频繁调用API

#### 2. 实现步骤
```python
# 在 tts_dynamic_discoverer.py 中添加

def discover_minimax_voices(self, api_key: str) -> Dict[str, List[Dict]]:
    """
    动态获取MiniMax可用音色列表

    API文档: https://platform.minimaxi.com/docs/api-reference/voice-management-get

    Returns:
        包含三类音色的字典:
        - system_voice: 系统预定义音色
        - voice_cloning: 复刻音色
        - voice_generation: 文生音色
    """
    url = "https://api.minimaxi.com/v1/get_voice"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    payload = {"voice_type": "all"}

    response = requests.post(url, headers=headers, json=payload, timeout=30)
    # 解析返回数据...
```

#### 3. 缓存机制
- 复用现有24小时缓存机制
- 缓存文件: `tts_providers_cache.yaml`
- 支持手动刷新

### 方案二：创建独立的MiniMax音色获取模块

#### 1. 核心思路
- 创建新的`minimax_voice_discoverer.py`模块
- 独立处理MiniMax音色获取逻辑
- 更清晰的代码分离

#### 2. 优缺点
| 方案 | 优点 | 缺点 |
|------|------|------|
| 方案一 | 代码集中，易维护 | 模块职责稍多 |
| 方案二 | 职责分离清晰 | 需要协调多个模块 |

### 方案三：使用MiniMax MCP Server

#### 1. 核心思路
- 集成MiniMax官方MCP服务器
- 通过MCP协议获取音色列表
- 更加官方和标准

#### 2. 优缺点
| 方案 | 优点 | 缺点 |
|------|------|------|
| 方案三 | 官方支持，功能完整 | 需要额外部署MCP服务 |

## 推荐方案

**推荐使用方案一**，理由：
1. 与现有架构完全兼容，无需大规模重构
2. 实现简单，代码量少
3. 复用现有缓存机制
4. 维护成本低

## 实现细节

### 1. API调用方式
```python
# MiniMax音色查询API
POST https://api.minimaxi.com/v1/get_voice
Authorization: Bearer {api_key}
Content-Type: application/json

{
  "voice_type": "all"  # 可选: system, voice_cloning, voice_generation, all
}
```

### 2. 返回数据格式
```json
{
  "system_voice": [
    {
      "voice_id": "male-qn-qingse",
      "voice_name": "青涩青年",
      "description": ["青涩青年音色"],
      "created_time": "1970-01-01"
    },
    // ... 100+ 系统音色
  ],
  "voice_cloning": [...],
  "voice_generation": [...],
  "base_resp": {
    "status_code": 0,
    "status_msg": "success"
  }
}
```

### 3. 缓存数据结构
```yaml
timestamp: 1700000000
providers:
  minimax:
    name: "MiniMax"
    voices:
      system_voice:
        - voice_id: "male-qn-qingse"
          voice_name: "青涩青年"
          gender: "male"
          description: "青涩青年音色"
      voice_cloning: [...]
      voice_generation: [...]
```

### 4. 与`tts_config_loader.py`的集成
- 在`TTSConfigLoader`中调用`DynamicTTSConfigDiscoverer.discover_minimax_voices`
- 优先使用缓存数据
- 缓存过期时自动刷新

## 需要讨论的问题

1. **缓存时间**: 是否使用现有的24小时缓存，还是设置为其他值（如1小时）？
2. **音色分类**: 是否需要将系统音色、复刻音色、文生音色分开展示？还是统一展示？
3. **Fallback机制**: 如果API调用失败，是使用内置的10个基础音色，还是禁用MiniMax？
4. **UI展示**: 是否需要在GUI中展示完整的音色列表，还是只展示常用的？

## 预期效果

实现后，用户将能够：
- ✅ 使用MiniMax官方的100+系统音色
- ✅ 使用自己创建的复刻音色
- ✅ 实时获取最新的音色列表，无需更新代码
- ✅ 通过缓存机制减少API调用

## 下一步

等待用户讨论确认方案后，开始实施。
