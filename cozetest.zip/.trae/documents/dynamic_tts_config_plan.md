# 动态TTS配置发现系统 - 实现计划

## 1. 需求分析

### 1.1 用户需求
用户希望实现一个动态配置发现系统，能够：
- 实时向服务商请求最新的配置参数（模型、音色等）
- 避免配置信息写死导致后续维护问题
- 支持多种TTS服务商的动态适配

### 1.2 技术挑战
- 并非所有服务商都提供元数据API
- 需要处理网络异常和离线场景
- 需要实现缓存机制平衡实时性和性能

### 1.3 方案选择
采用**混合方案**：
- 优先尝试动态获取配置
- 获取失败时使用本地缓存作为fallback

---

## 2. 架构设计

### 2.1 系统架构
```
┌──────────────────────────────────────────────────────────────┐
│                    动态配置发现系统                            │
├──────────────────────────────────────────────────────────────┤
│  ┌─────────────────────┐    ┌─────────────────────┐        │
│  │   DynamicDiscoverer │───▶│   ConfigCache       │        │
│  │   (动态发现器)       │    │   (本地缓存)        │        │
│  └─────────┬───────────┘    └──────────┬──────────┘        │
│            │                           │                    │
│            ▼                           ▼                    │
│  ┌─────────────────────┐    ┌─────────────────────┐        │
│  │   ConfigLoader      │◀───│   DefaultConfig     │        │
│  │   (配置加载器)       │    │   (默认配置)        │        │
│  └─────────┬───────────┘    └─────────────────────┘        │
│            │                                                │
│            ▼                                                │
│  ┌─────────────────────┐                                   │
│  │   ConfigManager     │                                   │
│  │   (配置管理CLI工具)  │                                   │
│  └─────────────────────┘                                   │
└──────────────────────────────────────────────────────────────┘
```

### 2.2 组件职责
| 组件 | 职责 | 状态 |
|------|------|------|
| DynamicDiscoverer | 调用服务商API动态获取配置 | 新增 |
| ConfigCache | 本地缓存管理，处理缓存过期 | 新增 |
| ConfigLoader | 统一配置加载入口，处理fallback逻辑 | 新增 |
| ConfigManager | 命令行管理工具 | 新增 |
| DefaultConfig | 内置默认配置，作为最终fallback | 新增 |

---

## 3. 文件结构

```
.
├── tts_dynamic_discoverer.py    # 动态配置发现器
├── tts_config_loader.py         # 配置加载器
├── tts_config_manager.py        # 配置管理CLI工具
├── tts_providers.yaml           # 默认配置文件
└── tts_providers_cache.yaml     # 缓存文件（自动生成）
```

---

## 4. 实现步骤

### 4.1 创建动态配置发现器 (tts_dynamic_discoverer.py)
- 实现阿里百炼模型和音色发现接口
- 实现缓存机制（TTL=24小时）
- 处理网络异常和API限流

### 4.2 创建配置加载器 (tts_config_loader.py)
- 统一配置加载入口
- 实现优先级：动态发现 > 本地缓存 > 默认配置
- 提供配置验证和模板生成功能

### 4.3 创建配置管理CLI工具 (tts_config_manager.py)
- 列出支持的服务商
- 刷新服务商配置
- 查看模型和音色列表
- 生成配置模板

### 4.4 更新现有TTS服务 (tts_service.py)
- 集成新的配置加载器
- 支持动态获取的音色列表

### 4.5 创建默认配置文件 (tts_providers.yaml)
- 包含阿里百炼、百度、Google等服务商配置
- 定义参数类型、默认值、选项列表

---

## 5. 关键代码设计

### 5.1 DynamicDiscoverer 类设计
```python
class DynamicDiscoverer:
    def __init__(self, cache_file: str = "tts_providers_cache.yaml"):
        self.cache_file = cache_file
        self.cache_ttl = 24 * 60 * 60  # 24小时
    
    def discover_bailian_models(self) -> List[Dict]:
        """动态获取阿里百炼模型列表"""
        pass
    
    def discover_bailian_voices(self, model: str) -> List[Dict]:
        """动态获取指定模型的音色列表"""
        pass
    
    def refresh_provider(self, provider: str) -> Dict:
        """刷新指定服务商配置"""
        pass
```

### 5.2 ConfigLoader 类设计
```python
class ConfigLoader:
    def __init__(self):
        self.discoverer = DynamicDiscoverer()
    
    def get_provider_metadata(self, provider: str) -> Dict:
        """获取服务商元数据"""
        pass
    
    def validate_config(self, provider: str, config: Dict) -> List[str]:
        """验证配置完整性"""
        pass
    
    def generate_config_template(self, provider: str) -> Dict:
        """生成配置模板"""
        pass
```

---

## 6. 依赖和环境

### 6.1 新增依赖
| 依赖 | 版本 | 用途 |
|------|------|------|
| requests | >=2.31.0 | 发起HTTP请求 |
| pyyaml | >=6.0 | YAML配置文件处理 |

### 6.2 环境变量
| 变量 | 说明 |
|------|------|
| DASHSCOPE_API_KEY | 阿里百炼API密钥（动态发现可能需要） |

---

## 7. 测试计划

### 7.1 单元测试
- 测试动态发现器的缓存机制
- 测试配置加载器的优先级逻辑
- 测试配置验证器的必填参数检查

### 7.2 集成测试
- 测试网络正常时能否正确获取配置
- 测试网络异常时是否能使用缓存
- 测试配置管理CLI工具的各项功能

---

## 8. 风险评估

| 风险 | 描述 | 应对措施 |
|------|------|----------|
| 服务商无元数据API | 无法动态获取配置 | 使用本地默认配置作为fallback |
| 网络异常 | 动态发现失败 | 使用本地缓存，记录错误日志 |
| API限流 | 频繁调用被限制 | 增加缓存TTL，减少调用频率 |
| 配置变更 | 服务商更新配置格式 | 定期刷新缓存，提示用户更新 |

---

## 9. 实施计划

| 阶段 | 任务 | 预计时间 |
|------|------|----------|
| 第一阶段 | 创建动态发现器和缓存机制 | 1小时 |
| 第二阶段 | 创建配置加载器 | 1小时 |
| 第三阶段 | 创建CLI管理工具 | 1小时 |
| 第四阶段 | 更新TTS服务集成 | 0.5小时 |
| 第五阶段 | 测试和验证 | 1小时 |

---

## 10. 输出物

- `tts_dynamic_discoverer.py` - 动态配置发现器
- `tts_config_loader.py` - 配置加载器
- `tts_config_manager.py` - CLI管理工具
- `tts_providers.yaml` - 默认配置文件
- 测试脚本和文档

---

## 11. 后续扩展

- 添加更多服务商的动态发现支持
- 实现定时自动刷新机制
- 提供Web界面配置管理