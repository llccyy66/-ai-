# 代码优化计划（第二阶段）

## 一、计划概述

本计划涵盖代码结构重构后的后续优化工作，包括：
1. 清理根目录零散文件
2. 统一模块路径
3. 完善类型注解
4. 验证测试用例
5. 创建启动脚本

---

## 二、任务详情

### 任务1：清理根目录

**目标**：整理根目录下的零散文件，提高项目整洁度

**待清理文件分类**：

| 类型 | 文件示例 | 处理方式 |
|-----|---------|---------|
| 调试脚本 | `debug_*.py` | 移入 `tools/debug/` |
| 测试脚本 | 已移入 `tests/` | 无需处理 |
| 临时文件 | `picture.jpg`, `music.mp3` | 删除 |
| 文档文件 | `*.md`, `*.txt` | 保留 |
| 配置文件 | `config.yaml`, `.env` | 保留 |
| 遗留模块 | `web_app.py`, `gui.py`, `tts_module.py` | 标记待删除 |

**执行步骤**：
1. 创建 `tools/debug/` 目录
2. 移动所有 `debug_*.py` 文件到 `tools/debug/`
3. 删除临时文件（`picture.jpg`, `music.mp3` 等）
4. 创建 `legacy/` 目录存放待删除的旧模块

---

### 任务2：统一模块路径

**目标**：删除重复的旧模块目录，保留 `src/` 下的新结构

**重复目录列表**：

| 旧目录 | 新位置 | 处理方式 |
|-------|-------|---------|
| `utils/` | `src/utils/` | 删除旧目录 |
| `modules/` | `src/gui/components/` | 删除旧目录 |
| `hetero_scheduler/` | `src/scheduler/` | 删除旧目录 |

**执行步骤**：
1. 确认 `src/utils/` 已包含所有必要文件
2. 删除根目录下的 `utils/`
3. 确认 `src/gui/components/` 已包含所有必要组件
4. 删除根目录下的 `modules/`
5. 确认 `src/scheduler/` 已包含所有必要文件
6. 删除根目录下的 `hetero_scheduler/`

---

### 任务3：完善类型注解

**目标**：为核心模块添加类型提示，提高代码可维护性

**待添加类型注解的文件**：

| 文件 | 位置 | 状态 |
|-----|------|------|
| `workflow_engine.py` | `src/core/` | 需要添加 |
| `tts_engine.py` | `src/core/` | 需要添加 |
| `image_engine.py` | `src/core/` | 需要添加 |
| `draft_generator.py` | `src/core/` | 需要添加 |
| `helpers.py` | `src/utils/` | 需要添加 |

**执行步骤**：
1. 为 `src/core/workflow_engine.py` 添加类型注解
2. 为 `src/core/tts_engine.py` 添加类型注解
3. 为 `src/core/image_engine.py` 添加类型注解
4. 为 `src/core/draft_generator.py` 添加类型注解
5. 为 `src/utils/helpers.py` 添加类型注解

---

### 任务4：验证测试

**目标**：运行现有测试用例确保重构没有破坏功能

**测试文件列表**：
- `tests/test_app.py` - 基础功能测试
- `tests/test_integration.py` - 集成测试
- `tests/test_end_to_end.py` - 端到端测试
- `tests/test_draft_creation.py` - 草稿创建测试
- `tests/test_tts_voice.py` - TTS测试
- `tests/test_image_generation.py` - 图片生成测试（已移至tests目录）

**执行步骤**：
1. 安装测试依赖（如未安装）
2. 运行单元测试
3. 运行集成测试
4. 分析测试失败原因并修复

---

### 任务5：创建启动脚本

**目标**：创建统一的项目启动脚本，方便开发和部署

**启动脚本需求**：

| 脚本类型 | 用途 | 说明 |
|---------|------|------|
| `run_api.py` | 启动API服务 | Flask + SocketIO |
| `run_gui.py` | 启动GUI应用 | Tkinter |
| `run_scheduler.py` | 启动任务调度器 | 后台任务处理 |
| `run_batch.py` | 运行批量任务 | 命令行批量处理 |

**脚本模板**：
```python
#!/usr/bin/env python3
"""启动脚本 - API服务"""

import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from src.main import create_app, create_socketio

if __name__ == '__main__':
    app = create_app()
    socketio = create_socketio(app)
    socketio.run(app, host='0.0.0.0', port=5000, debug=False)
```

---

## 三、风险评估

| 风险 | 描述 | 缓解措施 |
|-----|------|---------|
| **删除文件错误** | 误删重要文件 | 删除前确认文件内容，备份重要文件 |
| **测试失败** | 重构破坏现有功能 | 先运行测试确认基线，再进行删除操作 |
| **导入路径错误** | 删除旧目录导致导入失败 | 更新所有导入语句使用新路径 |
| **类型注解错误** | 类型不匹配导致运行时错误 | 使用类型检查工具验证 |

---

## 四、预期成果

1. 整洁的项目目录结构
2. 统一的模块路径
3. 类型安全的代码
4. 通过测试验证的功能
5. 便捷的启动脚本

---

**文档版本**: v1.0  
**创建日期**: 2026-05-15  
**状态**: 待审批