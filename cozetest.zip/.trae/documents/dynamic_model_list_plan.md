# 动态模型列表获取计划

## 1. 任务分析

### 1.1 现状分析
- 当前项目使用硬编码的模型列表，包含：`MiniMax/MiniMax-M2.5`, `Qwen/Qwen2.5-1.5B-Instruct`, `Qwen/Qwen2.5-7B-Instruct`, `Llama-3-8B-Instruct`, `GLM-4`
- 模型选择功能已实现，但模型列表是静态的，无法自动更新
- 没有从魔搭社区获取最新模型的机制

### 1.2 用户需求
- 利用提供的脚本从魔搭官方API获取免费的API推理模型
- 筛选文本生成模型
- 动态更新模型列表，而不是使用硬编码的模型
- 集成到现有的模型选择功能中

### 1.3 技术挑战
- 网络请求的异常处理
- 分页获取所有模型
- 与现有模型选择功能的集成
- 性能优化，避免每次运行都请求API

## 2. 解决方案设计

### 2.1 核心功能
1. **动态获取模型列表**：从魔搭官方API获取免费的API推理模型
2. **模型筛选**：筛选文本生成模型
3. **缓存机制**：缓存模型列表，避免频繁请求API
4. **集成到现有功能**：将动态模型列表集成到现有的模型选择功能中

### 2.2 技术实现

#### 2.2.1 模型获取模块
- 使用用户提供的脚本从魔搭官方API获取模型
- 实现分页获取所有模型
- 添加异常处理和重试机制
- 保存模型列表到缓存文件

#### 2.2.2 缓存机制
- 首次运行时获取模型列表并缓存
- 设置缓存过期时间（如24小时）
- 缓存过期后自动更新模型列表

#### 2.2.3 集成到现有功能
- 修改`get_available_models`函数，使用动态获取的模型列表
- 更新GUI中的模型选择下拉菜单
- 保持与现有功能的兼容性

## 3. 实施步骤

### 3.1 步骤1：创建模型获取模块

1. **创建`model_fetcher.py`文件**
   - 实现`get_free_api_models`函数
   - 实现缓存机制
   - 实现模型筛选功能

2. **修改`工作流测试.py`**
   - 导入模型获取模块
   - 修改`AVAILABLE_MODELS`为动态获取
   - 更新`get_available_models`函数

### 3.2 步骤2：集成到GUI

1. **修改`gui.py`**
   - 在模型设置窗口中添加"刷新模型列表"按钮
   - 实现动态更新模型选择下拉菜单
   - 显示模型获取状态

2. **添加缓存管理**
   - 显示缓存状态
   - 提供手动刷新选项

### 3.3 步骤3：测试验证

1. **测试模型获取**
   - 验证能否成功从API获取模型
   - 验证缓存机制是否正常工作
   - 验证模型筛选是否正确

2. **测试集成功能**
   - 验证命令行模式下的模型选择
   - 验证GUI模式下的模型选择
   - 验证模型切换功能

## 4. 代码修改清单

### 4.1 新增文件

| 文件 | 功能 | 优先级 |
|------|------|--------|
| `model_fetcher.py` | 模型获取和缓存 | 高 |

### 4.2 修改文件

| 文件 | 修改内容 | 优先级 |
|------|---------|--------|
| `工作流测试.py` | 使用动态模型列表 | 高 |
| `gui.py` | 集成动态模型列表 | 中 |

## 5. 技术细节

### 5.1 模型获取实现

```python
# model_fetcher.py
import requests
import json
import os
import time

API_URL = "https://www.modelscope.cn/api/v1/models"

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Referer": "https://www.modelscope.cn/models"
}

PARAMS = {
    "inferenceType": "API_INFERENCE",
    "tasks": "text-generation",
    "type": "nlp",
    "page": 1,
    "perPage": 100
}

CACHE_FILE = "model_cache.json"
CACHE_EXPIRY = 24 * 60 * 60  # 24小时

def get_free_api_models():
    """获取免费API推理模型"""
    model_ids = []
    page = 1
    
    while True:
        PARAMS["page"] = page
        try:
            response = requests.get(API_URL, headers=HEADERS, params=PARAMS, timeout=10)
            response.raise_for_status()
            result = response.json()
            
            models = result.get("data", {}).get("models", [])
            if not models:
                break
            
            for model in models:
                model_id = model.get("modelId")
                if model_id and model_id not in model_ids:
                    model_ids.append(model_id)
            
            print(f"第{page}页获取成功，累计：{len(model_ids)}个")
            page += 1
        except Exception as e:
            print(f"请求失败：{e}")
            break
    
    return model_ids

def get_models():
    """获取模型列表（带缓存）"""
    # 检查缓存
    if os.path.exists(CACHE_FILE):
        try:
            with open(CACHE_FILE, "r", encoding="utf-8") as f:
                cache_data = json.load(f)
            
            # 检查缓存是否过期
            if time.time() - cache_data.get("timestamp", 0) < CACHE_EXPIRY:
                print("使用缓存的模型列表")
                return cache_data.get("models", [])
        except:
            pass
    
    # 获取新模型列表
    print("获取最新模型列表...")
    models = get_free_api_models()
    
    # 保存到缓存
    cache_data = {
        "models": models,
        "timestamp": time.time()
    }
    try:
        with open(CACHE_FILE, "w", encoding="utf-8") as f:
            json.dump(cache_data, f, ensure_ascii=False, indent=2)
        print(f"模型列表已缓存，共{len(models)}个模型")
    except:
        print("缓存保存失败")
    
    return models

def refresh_models():
    """强制刷新模型列表"""
    # 删除缓存
    if os.path.exists(CACHE_FILE):
        os.remove(CACHE_FILE)
    return get_models()
```

### 5.2 集成到工作流测试.py

```python
# 工作流测试.py
from model_fetcher import get_models

# 动态获取模型列表
def get_available_models():
    """获取可用模型列表及其状态"""
    # 获取动态模型列表
    dynamic_models = get_models()
    # 确保包含常用模型
    common_models = [
        "MiniMax/MiniMax-M2.5",
        "Qwen/Qwen2.5-1.5B-Instruct",
        "Qwen/Qwen2.5-7B-Instruct",
        "Llama-3-8B-Instruct",
        "GLM-4"
    ]
    # 合并模型列表，去重
    all_models = list(set(dynamic_models + common_models))
    
    model_info = {}
    for model in all_models:
        quota = check_model_quota(model)
        model_info[model] = quota
    return model_info
```

### 5.3 集成到GUI

```python
# gui.py
from model_fetcher import get_models, refresh_models

def refresh_model_list(self):
    """刷新模型列表"""
    self.log("正在刷新模型列表...")
    try:
        models = refresh_models()
        # 更新下拉菜单
        self.model_var.set("")
        model_combobox['values'] = models
        self.log(f"模型列表已更新，共{len(models)}个模型")
    except Exception as e:
        self.log(f"刷新模型列表失败：{str(e)}")
```

## 6. 风险评估

### 6.1 风险点
1. **API稳定性**：魔搭API可能不稳定或返回格式变化
2. **网络依赖**：需要网络连接才能获取模型列表
3. **性能影响**：首次运行时获取模型列表可能较慢
4. **缓存过期**：缓存过期时需要重新获取模型列表

### 6.2 缓解措施
1. **异常处理**：添加完善的异常处理，当API失败时使用默认模型列表
2. **离线模式**：当网络不可用时，使用缓存的模型列表
3. **后台更新**：在后台异步更新模型列表，不阻塞主流程
4. **默认模型**：确保包含常用模型作为默认选项

## 7. 预期效果

### 7.1 功能效果
1. **动态模型列表**：自动从魔搭社区获取最新的免费API推理模型
2. **智能缓存**：缓存模型列表，避免频繁请求API
3. **用户控制**：提供手动刷新模型列表的选项
4. **兼容性**：保持与现有功能的兼容性

### 7.2 性能效果
1. **首次运行**：获取模型列表可能需要3-10秒
2. **后续运行**：使用缓存，几乎无延迟
3. **缓存更新**：每24小时自动更新一次

## 8. 结论

通过实现动态模型列表获取功能，可以自动从魔搭社区获取最新的免费API推理模型，避免硬编码模型列表的局限性。同时，通过缓存机制保证性能，通过异常处理保证稳定性，为用户提供更丰富、更及时的模型选择。

此实现将大大提升系统的灵活性和可维护性，确保用户始终能够使用最新的可用模型。