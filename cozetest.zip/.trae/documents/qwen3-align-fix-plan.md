# 千问强制对齐模块 `No module named 'torch'` 根因分析与修复计划

## 一、根因分析

### 1.1 错误现象
```
千问3强制对齐失败，不允许降级: No module named 'torch'
```

### 1.2 执行链路追踪

```
主进程 (Anaconda Python)
  → align_segments()
    → _subprocess_align_batch()
      → subprocess.run([python_exe, "qwen3_align_worker.py", ...])
        → qwen3_align_worker.py
          → from qwen_asr import Qwen3ASRModel  ← 这里触发 import torch
          → import torch  ← 报错点
```

### 1.3 根本原因：`qwen_asr_env` 虚拟环境中未安装 `torch`

经过逐层排查，确认了以下事实：

| 检查项 | 结果 |
|--------|------|
| `qwen_asr_env` 虚拟环境存在 | ✅ 存在于 `cozetest/qwen_asr_env/` |
| `qwen_asr_env/Scripts/python.exe` 存在 | ✅ 存在 |
| `qwen_asr` 包安装在 venv 中 | ✅ `site-packages/qwen_asr/` 存在 |
| `transformers` 安装在 venv 中 | ✅ 存在 |
| `accelerate` 安装在 venv 中 | ✅ 存在 |
| `bitsandbytes` 安装在 venv 中 | ✅ 存在 |
| **`torch` 安装在 venv 中** | ❌ **不存在！** |
| `torch` 安装在 Anaconda 基础环境中 | ✅ `D:\Anaconda3 2024.06-1\Lib\site-packages\torch\` 存在 |

### 1.4 为什么 `torch` 缺失？

`qwen_asr_env` 是通过 `python -m venv` 创建的虚拟环境，其 `pyvenv.cfg` 配置：

```ini
home = D:\Anaconda3 2024.06-1
include-system-site-packages = false   ← 关键！
version = 3.12.3
```

**`include-system-site-packages = false`** 意味着虚拟环境完全隔离，不会继承 Anaconda 基础环境中的任何包。虽然 `torch` 安装在 Anaconda 基础环境中，但 venv 看不到它。

而 `qwen_asr` 包的导入链中，**顶层直接 `import torch`**：

```python
# qwen_asr/inference/qwen3_asr.py:20
import torch

# qwen_asr/inference/qwen3_forced_aligner.py:22
import torch
```

因此当子进程使用 `qwen_asr_env/Scripts/python.exe` 运行 `qwen3_align_worker.py` 时，`from qwen_asr import Qwen3ASRModel` 会触发 `import torch`，而 venv 中没有 torch，直接报错。

### 1.5 为什么之前修不好？

之前的修复可能只关注了以下方向：
- 修改 Python 路径选择逻辑（但 `qwen_asr_env/Scripts/python.exe` 存在，所以总是选它）
- 修改环境变量
- 修改降级逻辑

**但从未真正解决核心问题：`qwen_asr_env` 虚拟环境中缺少 `torch` 包。**

## 二、修复方案

### 方案 A：在 `qwen_asr_env` 中安装 torch（推荐）

**优点**：彻底解决问题，环境完全自包含
**步骤**：
1. 激活 `qwen_asr_env` 虚拟环境
2. 安装 PyTorch（CUDA 版本，匹配当前 GPU）
3. 验证安装

```bash
qwen_asr_env\Scripts\activate
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu121
```

### 方案 B：修改 `pyvenv.cfg` 启用系统包继承

**优点**：无需重新安装 torch，利用 Anaconda 已有的 torch
**缺点**：可能导致版本冲突，不够干净

```ini
include-system-site-packages = true
```

### 方案 C：修改代码逻辑，当 venv 缺少 torch 时回退到 Anaconda Python

**优点**：代码层面容错
**缺点**：Anaconda Python 可能缺少 `qwen_asr` 包，只是把问题转移

### 推荐方案：A + C 组合

1. **首要**：在 `qwen_asr_env` 中安装 torch（方案 A）
2. **兜底**：在代码中增加环境预检，当检测到 torch 缺失时给出明确诊断信息而非模糊报错（方案 C 增强）

## 三、测试用例设计

### 3.1 环境预检测试脚本 `test_qwen3_align_env.py`

该脚本从最底层逐步验证，定位问题：

```python
"""千问3强制对齐模块环境预检测试

测试层级：
  L1: Python 解释器基础检查
  L2: 核心依赖包检查（torch, transformers, accelerate）
  L3: qwen_asr 包导入检查
  L4: 模型文件存在性检查
  L5: GPU 可用性检查
  L6: 端到端强制对齐测试
"""
```

#### L1 - Python 解释器检查
- 验证当前 Python 路径
- 验证 Python 版本
- 验证 `sys.path` 包含正确的 `site-packages`

#### L2 - 核心依赖包检查
- `import torch` → 版本、CUDA 可用性
- `import transformers` → 版本
- `import accelerate` → 版本
- `import bitsandbytes` → 版本（4-bit 量化需要）

#### L3 - qwen_asr 包导入检查
- `from qwen_asr import Qwen3ASRModel`
- `from qwen_asr import Qwen3ForcedAligner`

#### L4 - 模型文件检查
- `Qwen3-ASR-1.7B` 目录存在
- `Qwen3-ForcedAligner-0.6B` 目录存在
- `config.json` 文件存在
- `.safetensors` 权重文件存在

#### L5 - GPU 检查
- `torch.cuda.is_available()`
- GPU 名称、显存大小
- 4-bit 量化是否可行（显存 ≥ 6GB）

#### L6 - 端到端测试
- 生成一段简短测试音频（TTS）
- 调用 `model.forced_aligner.align()` 进行强制对齐
- 验证返回结果结构正确

### 3.2 子进程调用链路测试

测试 `_subprocess_align_batch` 的完整链路：
- 验证 `python_exe` 选择的正确性
- 验证子进程能否成功导入 torch
- 验证输入 JSON 格式正确
- 验证输出 JSON 格式正确

### 3.3 代码增强：环境预检函数

在 `_subprocess_align_batch` 中增加预检逻辑：
- 在启动子进程前，先用子进程 Python 执行 `import torch` 测试
- 如果失败，给出明确的诊断信息（"qwen_asr_env 中未安装 torch"）
- 而不是等到整个对齐流程失败才报错

## 四、实施步骤

### 步骤 1：安装 torch 到 qwen_asr_env
```bash
cd c:\Users\18622\Documents\trae_projects\cozetest
qwen_asr_env\Scripts\pip.exe install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu121
```

### 步骤 2：创建环境预检测试脚本
创建 `test_qwen3_align_env.py`，包含 L1-L6 六层测试

### 步骤 3：运行预检测试
```bash
qwen_asr_env\Scripts\python.exe test_qwen3_align_env.py
```

### 步骤 4：增强代码中的环境诊断
修改 `_subprocess_align_batch` 函数，在启动对齐子进程前增加环境预检

### 步骤 5：运行端到端测试验证
运行完整工作流，确认强制对齐模块正常工作
