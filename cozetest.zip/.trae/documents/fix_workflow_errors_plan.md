# 工作流测试.py 错误修复计划

## 问题分析

从终端输出发现以下问题：

### 问题1：音频文件路径不存在
```
用户指定的音频文件不存在: c:\Users\18622\Documents\trae_projects\cozetest\446-【Playlist】纯音乐｜「格陵兰的红帆船上看满月生升起」｜值得收藏｜学习睡眠舒缓钢琴曲｜上下班散步背景音乐-480P 标清-AVC.mp3
```

### 问题2：json 变量未定义错误
```
ERROR: 读取草稿文件失败: cannot access local variable 'json' where it is not associated with a value
```

这个问题出现在 `validate_draft` 函数中，line 2167 附近有 `json.load(f)` 调用，但在之前可能有 `json` 模块导入问题。

---

## 修复计划

### 步骤1: 检查实际音频文件名
- 验证用户提供的音频文件在目录中的实际文件名
- 注意文件名中的特殊字符可能导致匹配失败

### 步骤2: 修复 json 模块导入问题
- 检查 `validate_draft` 函数中 `json` 模块的使用
- 确保在函数内部正确导入 `json` 模块（如果需要）
- 或确认顶层导入是否正确

### 步骤3: 修复音频文件路径匹配逻辑
- 优化文件路径检查逻辑
- 支持文件名模糊匹配
- 处理特殊字符编码问题

### 步骤4: 测试验证
- 语法检查
- 运行小规模测试

---

## 具体修复步骤

#### 1. 检查音频文件
```bash
# 检查文件是否存在
ls -la "c:\Users\18622\Documents\trae_projects\cozetest\446"*mp3
```

#### 2. 修复 json 变量问题
在 `validate_draft` 函数中 line ~2167 附近：
- 确认 `json.load(f)` 前的 import 语句
- 可能需要添加 `import json` 在函数内部

#### 3. 修复音频路径检查
在 line ~2770 附近，使用 `glob` 或 `os.listdir` 来查找匹配的文件。

---

## 预期结果

修复后工作流应该：
1. 正确识别音频文件
2. 顺利通过自检验证
3. 完成关键词高亮处理