# 存储路径分离计划

## 一、需求分析

### 当前问题
1. **口播稿重复存储**：同一口播稿同时存在于 `output/script_xxx.json` 和 `任务列表/任务_xxx/01_口播文案/口播稿.md`
2. **路径职责不清**：`output/` 和 `任务列表/` 的职责边界模糊
3. **批量执行时数据流向混乱**：批量调度时，工作流测试.py 仍会向 output/ 写入文件

### 目标
- **单次运行**（工作流测试.py）：产物仅存入 `output/`
- **批量运行**（task_scheduler.py / run_hetero_scheduler.py）：产物仅存入 `任务列表/`
- **消除重复存储**：同一数据只存储一份

---

## 二、代码库研究结论

### 2.1 当前存储逻辑

| 文件 | 存储位置 | 存储内容 |
|------|---------|---------|
| `工作流测试.py` | `output/script_xxx.json` | 分段口播稿JSON |
| `工作流测试.py` | `output/audio/` | 音频文件（缓存） |
| `工作流测试.py` | `output/images/` | 图片文件（缓存） |
| `task_scheduler.py` | `任务列表/任务_xxx/01_口播文案/口播稿.md` | 口播稿Markdown |
| `task_scheduler.py` | `任务列表/任务_xxx/task_config.json` | 任务配置 |
| `task_scheduler.py` | `任务列表/任务_xxx/logs/` | 任务日志 |

### 2.2 关键代码位置

1. **`工作流测试.py` 第1057行** - 脚本保存到 output：
   ```python
   script_path = os.path.join("output", f"script_{int(time.time())}.json")
   ```

2. **`task_scheduler.py` 第86行** - 口播稿保存到任务列表：
   ```python
   write_script_content(task_folder_path, script_content)
   ```

3. **`task_scheduler.py` 第217-250行** - 调用工作流测试：
   ```python
   from 工作流测试 import segmented_workflow
   result = segmented_workflow(...)
   ```

---

## 三、修改方案

### 3.1 修改 `工作流测试.py`

**目标**：支持输出路径参数化，允许调用方指定输出位置

**修改内容**：
1. 在 `generate_segmented_script` 函数中添加 `output_dir` 参数
2. 修改脚本保存路径逻辑，根据 `output_dir` 参数决定存储位置
3. 默认保持原有行为（输出到 output/）

**文件**：`c:\Users\18622\Documents\trae_projects\cozetest\工作流测试.py`

### 3.2 修改 `task_scheduler.py`

**目标**：批量执行时指定输出路径为任务列表

**修改内容**：
1. 在调用 `segmented_workflow` 时传入 `output_dir` 参数
2. 确保工作流的产物直接写入任务列表对应的文件夹
3. 删除 `batch_generate_scripts` 中的独立文案生成逻辑（改用工作流）

**文件**：`c:\Users\18622\Documents\trae_projects\cozetest\task_scheduler.py`

### 3.3 清理策略

**目标**：定期清理 output/ 中的历史文件

**修改内容**：
1. 在 `task_scheduler.py` 中添加清理函数
2. 运行前清理 output/ 中超过指定天数的文件
3. 保留必要的缓存目录（audio、images）

---

## 四、修改步骤

### 步骤1：修改 `工作流测试.py`

```python
# 修改 generate_segmented_script 函数签名，添加 output_dir 参数
def generate_segmented_script(subject, author, word_num=500, model=None, output_dir="output"):
    # ... 原有代码 ...
    
    # 修改脚本保存路径
    script_path = None
    try:
        script_path = os.path.join(output_dir, f"script_{int(time.time())}.json")
        os.makedirs(output_dir, exist_ok=True)
        with open(script_path, "w", encoding="utf-8") as f:
            json.dump(parsed, f, ensure_ascii=False, indent=2)
        logger.info(f"口播稿已保存: {script_path}")
    except Exception:
        script_path = None
```

### 步骤2：修改 `segmented_workflow` 函数

```python
# 添加 output_dir 参数并传递给 generate_segmented_script
def segmented_workflow(subject, author, word_num=500, llm_model=None, template=None, 
                       skip_llm=False, existing_script=None, enable_text2image=False,
                       output_dir="output"):
    # ... 调用 generate_segmented_script 时传递 output_dir ...
```

### 步骤3：修改 `task_scheduler.py`

```python
# 在 run_single_task 中指定 output_dir
result = segmented_workflow(
    subject=topic,
    author="批量生产",
    word_num=task_config["word_count_limit"],
    llm_model="Pro/deepseek-ai/DeepSeek-V3.2",
    template=None,
    skip_llm=skip_llm,
    existing_script=existing_script,
    enable_text2image=enable_text2image,
    output_dir=os.path.join(task_folder_path, "01_口播文案")  # 指定输出到任务文件夹
)
```

### 步骤4：简化 `batch_generate_scripts`

```python
def batch_generate_scripts() -> bool:
    """批量生成口播文案 - 使用工作流统一处理"""
    print("\n批量生成口播文案...")
    
    pending_tasks = get_pending_tasks("待生成文案")
    
    if not pending_tasks:
        print("  暂无待生成文案的任务")
        return True
    
    success_count = 0
    for task in pending_tasks:
        task_id = task["task_id"]
        topic = task["video_topic"]
        task_folder_path = task["task_folder_path"]
        
        print(f"  生成文案 {task_id}: {topic}")
        
        try:
            # 直接调用工作流生成，输出到任务文件夹
            from 工作流测试 import generate_segmented_script
            
            result = generate_segmented_script(
                subject=topic,
                author="批量生产",
                word_num=task["word_count_limit"],
                output_dir=os.path.join(task_folder_path, "01_口播文案")
            )
            
            # 更新状态为"文案审核中"
            update_task_status(task_id, "文案审核中")
            success_count += 1
            
            print(f"    [OK] 生成成功")
        except Exception as e:
            print(f"    [ERR] 生成失败: {e}")
    
    print(f"[OK] 批量文案生成完成，成功{success_count}/{len(pending_tasks)}")
    return True
```

---

## 五、风险与依赖

### 5.1 风险评估

| 风险 | 等级 | 描述 | 应对措施 |
|------|------|------|---------|
| 路径参数传递错误 | 中 | 可能导致文件写入错误位置 | 增加路径验证逻辑 |
| 批量执行失败 | 中 | 修改后可能影响批量调度流程 | 先进行单元测试 |
| 缓存机制冲突 | 低 | output/ 缓存与任务列表文件可能冲突 | 保持缓存目录独立 |

### 5.2 依赖关系

```
工作流测试.py
    └── task_scheduler.py (调用 segmented_workflow)
            └── run_hetero_scheduler.py (调用任务调度器)
```

---

## 六、验证计划

### 测试用例

1. **单次运行测试**：
   - 运行 `工作流测试.py`
   - 验证产物仅出现在 `output/`
   - 验证 `任务列表/` 无新增文件

2. **批量运行测试**：
   - 通过 `task_scheduler.py` 添加任务并执行
   - 验证产物仅出现在 `任务列表/任务_xxx/`
   - 验证 `output/` 无新增脚本文件

3. **口播稿一致性测试**：
   - 对比 `output/` 和 `任务列表/` 中的口播稿内容
   - 确保无重复存储

---

## 七、文件修改清单

| 文件 | 修改类型 | 修改内容 |
|------|---------|---------|
| `工作流测试.py` | 修改 | 添加 `output_dir` 参数支持 |
| `task_scheduler.py` | 修改 | 指定批量执行时的输出路径 |
| `task_scheduler.py` | 修改 | 简化 `batch_generate_scripts` 函数 |

---

## 八、总结

本计划通过参数化输出路径，实现了单次运行和批量运行的存储路径分离：
- **单次运行**：产物存入 `output/`，适合临时测试
- **批量运行**：产物存入 `任务列表/`，适合持久化管理
- **消除重复**：统一使用工作流生成，避免重复存储

修改量较小，向后兼容性好，不会影响现有功能。