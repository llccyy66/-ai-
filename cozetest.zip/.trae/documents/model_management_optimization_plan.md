# 模型管理优化计划

## 1. 问题分析

### 1.1 现状分析
- 当前项目使用 `model_fetcher.py` 从魔搭官方API动态获取模型列表
- 由于API访问问题，无法正常获取模型列表
- 系统依赖缓存和降级机制来保证运行

### 1.2 用户需求
- 弃用 `model_fetcher.py` 文件
- 使用用户手动提供的模型ID列表
- 确保模型选择功能正常工作
- 保持系统的稳定性和可靠性

### 1.3 提供的模型ID
- ZhipuAI/GLM-5
- MiniMax/MiniMax-M2.7
- ZhipuAI/GLM-4.7-Flash
- Qwen/Qwen3-32B
- Qwen/Qwen3-235B-A22B-Instruct-2507
- MiniMax/MiniMax-M2.5

## 2. 解决方案设计

### 2.1 核心功能
1. **静态模型列表**：使用用户提供的模型ID作为静态模型列表
2. **移除动态获取**：删除对 `model_fetcher.py` 的依赖
3. **保持兼容性**：确保现有功能正常工作
4. **优化模型选择**：提供更清晰的模型选择界面

### 2.2 技术实现

#### 2.2.1 工作流测试.py 修改
- 移除 `model_fetcher` 导入
- 更新 `COMMON_MODELS` 为用户提供的模型列表
- 简化 `get_available_models` 函数

#### 2.2.2 GUI 修改
- 更新模型选择下拉菜单的选项
- 移除模型刷新按钮
- 保持其他功能不变

#### 2.2.3 清理
- 删除 `model_fetcher.py` 文件
- 删除相关缓存文件

## 3. 实施步骤

### 3.1 步骤1：修改工作流测试.py

1. **移除模型获取模块导入**
2. **更新模型列表**：使用用户提供的模型ID
3. **简化模型获取逻辑**：直接使用静态模型列表

### 3.2 步骤2：修改GUI

1. **更新模型选择下拉菜单**：使用新的模型列表
2. **移除模型刷新按钮**：不再需要动态刷新
3. **更新相关功能**：确保模型选择功能正常

### 3.3 步骤3：清理

1. **删除 model_fetcher.py** 文件
2. **删除模型缓存文件**
3. **清理相关代码**：移除不再使用的功能

### 3.4 步骤4：测试验证

1. **测试命令行模式**：验证模型选择功能
2. **测试GUI模式**：验证模型选择界面
3. **测试模型切换**：验证429错误处理

## 4. 代码修改清单

### 4.1 修改文件

| 文件 | 修改内容 | 优先级 |
|------|---------|--------|
| `工作流测试.py` | 移除模型获取模块，更新模型列表 | 高 |
| `gui.py` | 更新模型选择下拉菜单，移除刷新按钮 | 高 |

### 4.2 删除文件

| 文件 | 原因 | 优先级 |
|------|------|--------|
| `model_fetcher.py` | 无法正常获取模型列表 | 高 |
| `model_cache.json` | 不再需要缓存 | 中 |
| `modelscope_official_free_api_models.txt` | 不再需要 | 低 |

## 5. 技术细节

### 5.1 工作流测试.py 修改

```python
# 移除模型获取模块导入
# from model_fetcher import get_models, get_cache_info

# 更新模型列表为用户提供的模型ID
COMMON_MODELS = [
    "ZhipuAI/GLM-5",
    "MiniMax/MiniMax-M2.7",
    "ZhipuAI/GLM-4.7-Flash",
    "Qwen/Qwen3-32B",
    "Qwen/Qwen3-235B-A22B-Instruct-2507",
    "MiniMax/MiniMax-M2.5"
]

# 简化模型获取函数
def get_available_models():
    """获取可用模型列表及其状态"""
    model_info = {}
    for model in COMMON_MODELS:
        quota = check_model_quota(model)
        model_info[model] = quota
    return model_info
```

### 5.2 GUI 修改

```python
# 更新模型选择下拉菜单选项
model_options = [
    "ZhipuAI/GLM-5",
    "MiniMax/MiniMax-M2.7",
    "ZhipuAI/GLM-4.7-Flash",
    "Qwen/Qwen3-32B",
    "Qwen/Qwen3-235B-A22B-Instruct-2507",
    "MiniMax/MiniMax-M2.5"
]

# 移除模型刷新按钮
# refresh_model_btn = ttk.Button(model_list_frame, text="刷新模型", command=self.refresh_model_list, width=10)
# refresh_model_btn.pack(side=tk.LEFT, padx=5)

# 移除refresh_model_list方法
# def refresh_model_list(self):
#     ...
```

## 6. 风险评估

### 6.1 风险点
1. **模型可用性**：用户提供的模型可能不可用或需要特殊权限
2. **额度限制**：新模型可能有不同的额度限制
3. **兼容性**：修改后可能影响现有功能

### 6.2 缓解措施
1. **模型验证**：在运行时检查模型可用性
2. **错误处理**：完善的异常处理机制
3. **向后兼容**：保持现有API接口不变

## 7. 预期效果

### 7.1 功能效果
1. **稳定的模型列表**：使用用户提供的可靠模型ID
2. **简化的代码结构**：移除复杂的动态获取逻辑
3. **可靠的模型选择**：用户可以选择已知可用的模型
4. **保持功能完整**：所有现有功能正常工作

### 7.2 性能效果
1. **启动速度**：移除网络请求，启动更快
2. **运行稳定性**：避免网络依赖，更加稳定
3. **维护性**：代码更简洁，易于维护

## 8. 结论

通过使用用户提供的模型ID列表，我们可以完全弃用 `model_fetcher.py` 文件，避免网络依赖带来的问题。同时，保持系统的稳定性和可靠性，确保模型选择功能正常工作。

此实现将大大简化代码结构，提高系统的稳定性和可维护性，为用户提供更可靠的模型选择体验。