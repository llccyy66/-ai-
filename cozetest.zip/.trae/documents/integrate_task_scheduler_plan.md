# 集成任务调度器到异构调度器 - 实施计划

## 1. 需求分析

用户希望将 `task_scheduler.py` 的功能集成到 `run_hetero_scheduler.py`，以便以后只需要使用一个脚本即可完成所有批量任务处理。

### 待集成功能

| 功能 | 来源 | 说明 |
|------|------|------|
| 批量初始化任务文件夹 | task_scheduler.py | 处理「待初始化」状态任务 |
| 批量生成口播文案 | task_scheduler.py | 调用大模型生成文案 |
| 一键跳过审核 | task_scheduler.py | 直接进入执行阶段 |
| 任务状态管理 | task_scheduler.py | 更新任务状态流转 |
| 异构调度执行 | run_hetero_scheduler.py | A类/B类任务区分执行 |

## 2. 实施步骤

### 步骤1：修改 `hetero_scheduler/integrated_scheduler.py`

添加以下功能：
- `batch_init_task_folders()` - 批量初始化任务文件夹
- `batch_generate_scripts()` - 批量生成口播文案
- `skip_review_and_execute()` - 跳过审核直接执行
- 更新 `run()` 方法，整合所有阶段

### 步骤2：更新 `run_hetero_scheduler.py`

简化入口，直接调用集成后的调度器

### 步骤3：测试验证

验证集成后的功能是否正常工作

## 3. 文件修改清单

| 文件 | 修改类型 | 说明 |
|------|----------|------|
| hetero_scheduler/integrated_scheduler.py | 修改 | 添加批量初始化和文案生成功能 |
| run_hetero_scheduler.py | 修改 | 更新入口调用 |

## 4. 风险处理

- **风险1**: 函数命名冲突
  - 处理：使用命名空间隔离，添加前缀区分
- **风险2**: 配置依赖问题
  - 处理：确保正确导入配置模块
- **风险3**: 状态管理冲突
  - 处理：统一使用 utils.task_queue_utils 模块

## 5. 预期输出

集成后 `run_hetero_scheduler.py` 将支持：
1. 阶段1: 批量初始化待初始化任务
2. 阶段2: 批量生成口播文案
3. 阶段3: 审核选择（跳过或手动审核）
4. 阶段4: 异构调度执行

用户只需运行一个脚本即可完成所有批量任务处理。