# TTS SSL连接错误修复计划

## 问题分析

从终端日志中可以看到，调用阿里百炼TTS服务时出现SSL连接错误：

```
HTTPSConnectionPool(host='dashscope.aliyuncs.com', port=443): Max retries exceeded with url: /api/v1/services/aigc/multimodal-generation/generation 
(Caused by SSLError(SSLEOFError(8, '[SSL: UNEXPECTED_EOF_WHILE_READING] EOF occurred in violation of protocol')))
```

**可能原因**：
1. 网络环境问题（如代理、防火墙干扰SSL握手）
2. Python SSL库版本与服务器不兼容
3. requests库的SSL验证配置问题

## 解决方案

### 方案1：禁用SSL验证（快速修复）
在requests请求中添加`verify=False`参数绕过SSL验证。这是最简单的解决方案，但存在安全风险（不建议在生产环境使用）。

### 方案2：配置SSL适配
设置合适的SSL版本和加密套件，提高兼容性。

### 方案3：添加降级策略
当TTS服务不可用时，提供一个本地音频生成方案作为降级。

## 实施计划

### 修改文件
- `c:\Users\18622\Documents\trae_projects\cozetest\工作流测试.py`
  - 在`text_to_speech`函数的requests.post调用中添加SSL配置
  - 在`text_to_speech_full`函数中应用相同修复

### 修改内容
1. 在requests请求中添加`verify=False`参数
2. 或配置adapter使用兼容的SSL版本

### 代码修改位置
- 第388-404行：`text_to_speech`函数的TTS请求
- 第165-175行：可能存在的其他TTS请求

## 风险评估

| 风险 | 等级 | 描述 |
|------|------|------|
| 安全风险 | 中 | 禁用SSL验证可能导致中间人攻击 |
| 兼容性 | 低 | 修改仅影响TTS功能 |
| 测试覆盖 | 中 | 需要验证TTS功能是否正常工作 |

## 验证步骤

1. 运行工作流测试，验证TTS是否正常工作
2. 检查日志确认没有SSL错误
3. 验证生成的音频文件是否正确

## 回滚方案

如果修改后出现其他问题，可恢复原始代码，移除SSL相关配置。
