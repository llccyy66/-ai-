# 代码结构重构计划

## 一、项目现状分析

### 1.1 当前目录结构问题

根据项目分析，当前代码存在以下主要问题：

| 问题类型 | 具体表现 | 影响 |
|---------|---------|------|
| **文件组织混乱** | 50+个Python文件散落在根目录 | 难以定位和维护 |
| **命名不规范** | 混用中英文命名 | 代码可读性差 |
| **巨型文件** | `web_app.py`超过1300行 | 难以理解和修改 |
| **职责不清** | 业务逻辑、API路由、状态管理混在一起 | 模块耦合度高 |

### 1.2 当前文件分类统计

| 类型 | 文件数量 | 示例 |
|-----|---------|------|
| 测试文件 | ~40个 | `test_app.py`, `test_batch_monitor.py` |
| 调试脚本 | ~10个 | `debug_align.py`, `debug_scheduler.py` |
| 核心模块 | ~10个 | `web_app.py`, `gui.py`, `tts_module.py` |
| 工具模块 | 8个 | `utils/*.py` |
| 调度器模块 | 3个 | `hetero_scheduler/*.py` |
| 关键词高亮模块 | 3个 | `keyword_highlight/*.py` |

---

## 二、重构目标

1. **建立清晰的模块化结构**：按职责划分目录
2. **降低耦合度**：模块间依赖清晰
3. **提高可维护性**：便于添加新功能和定位问题
4. **符合Python规范**：遵循PEP8标准

---

## 三、重构后的目录结构

```
src/
├── api/                    # REST API层（新增）
│   ├── __init__.py
│   ├── routes/             # 路由定义（新增）
│   │   ├── __init__.py
│   │   ├── workflow.py     # 工作流API
│   │   ├── batch.py        # 批量任务API
│   │   ├── templates.py    # 模板管理API
│   │   └── ideas.py        # 点子生成API
│   └── schemas.py          # 请求/响应数据结构（新增）
├── core/                   # 核心业务逻辑（新增）
│   ├── __init__.py
│   ├── workflow_engine.py  # 工作流引擎（从工作流测试.py抽取）
│   ├── tts_engine.py       # TTS引擎（从tts_module.py抽取）
│   ├── image_engine.py     # 图片生成引擎（从工作流测试.py抽取）
│   └── draft_generator.py  # 草稿生成器（保留modules/draft_generator.py）
├── config/                 # 统一配置管理（新增）
│   ├── __init__.py
│   └── settings.py         # 类型安全的配置类
├── models/                 # 数据模型（新增）
│   ├── __init__.py
│   ├── task.py             # 任务模型
│   └── workflow.py         # 工作流模型
├── services/               # 外部服务封装（新增）
│   ├── __init__.py
│   ├── llm_service.py      # LLM服务封装
│   ├── tts_service.py      # TTS服务封装
│   └── image_service.py    # 图片服务封装
├── utils/                  # 工具函数（保留并整理）
│   ├── __init__.py
│   ├── logger.py
│   ├── helpers.py
│   └── json_utils.py
├── gui/                    # GUI模块（保留并整理）
│   ├── __init__.py
│   ├── main.py             # GUI主入口（从gui.py抽取）
│   └── components/         # GUI组件（从modules/*.py抽取）
│       ├── __init__.py
│       ├── workflow_control.py
│       ├── parameter_settings.py
│       └── result_display.py
├── scheduler/              # 调度器模块（原hetero_scheduler）
│   ├── __init__.py
│   ├── scheduler.py
│   ├── sub_queue.py
│   └── task_queue.py
└── main.py                 # 应用入口（新增）
```

---

## 四、文件迁移映射表

### 4.1 核心业务逻辑

| 源文件 | 目标位置 | 说明 |
|-------|---------|------|
| `工作流测试.py` | `src/core/workflow_engine.py` | 核心工作流逻辑 |
| `tts_module.py` | `src/core/tts_engine.py` | TTS引擎逻辑 |
| `modules/draft_generator.py` | `src/core/draft_generator.py` | 草稿生成器 |

### 4.2 API路由

| 源文件 | 目标位置 | 说明 |
|-------|---------|------|
| `web_app.py` | `src/api/routes/workflow.py` | 工作流相关API |
| `web_app.py` | `src/api/routes/batch.py` | 批量任务API |
| `web_app.py` | `src/api/routes/templates.py` | 模板管理API |
| `web_app.py` | `src/api/routes/ideas.py` | 点子生成API |

### 4.3 GUI模块

| 源文件 | 目标位置 | 说明 |
|-------|---------|------|
| `gui.py` | `src/gui/main.py` | GUI主入口 |
| `modules/workflow_control.py` | `src/gui/components/workflow_control.py` | 工作流控制组件 |
| `modules/parameter_settings.py` | `src/gui/components/parameter_settings.py` | 参数设置组件 |
| `modules/result_display.py` | `src/gui/components/result_display.py` | 结果显示组件 |
| `modules/log_panel.py` | `src/gui/components/log_panel.py` | 日志面板组件 |
| `modules/model_settings.py` | `src/gui/components/model_settings.py` | 模型设置组件 |

### 4.4 调度器模块

| 源文件 | 目标位置 | 说明 |
|-------|---------|------|
| `hetero_scheduler/scheduler.py` | `src/scheduler/scheduler.py` | 调度器主类 |
| `hetero_scheduler/sub_queue.py` | `src/scheduler/sub_queue.py` | 子队列管理 |

### 4.5 工具模块

| 源文件 | 目标位置 | 说明 |
|-------|---------|------|
| `utils/__init__.py` | `src/utils/__init__.py` | 保留 |
| `utils/logger.py` | `src/utils/logger.py` | 保留 |
| `utils/helpers.py` | `src/utils/helpers.py` | 保留，清理冗余 |
| `utils/json_utils.py` | `src/utils/json_utils.py` | 保留 |
| `utils/config.py` | `src/config/settings.py` | 整合到配置模块 |

---

## 五、实施步骤

### 步骤1：创建目录结构（第1天）

```bash
mkdir -p src/api/routes
mkdir -p src/core
mkdir -p src/config
mkdir -p src/models
mkdir -p src/services
mkdir -p src/gui/components
mkdir -p src/scheduler
```

### 步骤2：迁移工具模块（第1天）

1. 复制 `utils/logger.py` → `src/utils/logger.py`
2. 复制 `utils/helpers.py` → `src/utils/helpers.py`
3. 复制 `utils/json_utils.py` → `src/utils/json_utils.py`
4. 创建 `src/utils/__init__.py`

### 步骤3：创建配置模块（第2天）

1. 创建 `src/config/settings.py` - 使用pydantic-settings
2. 创建 `src/config/__init__.py`

### 步骤4：迁移核心业务逻辑（第2-3天）

1. 从 `工作流测试.py` 抽取工作流引擎逻辑 → `src/core/workflow_engine.py`
2. 从 `tts_module.py` 抽取TTS引擎 → `src/core/tts_engine.py`
3. 复制 `modules/draft_generator.py` → `src/core/draft_generator.py`

### 步骤5：拆分API路由（第3-4天）

1. 从 `web_app.py` 拆分工作流API → `src/api/routes/workflow.py`
2. 从 `web_app.py` 拆分批量任务API → `src/api/routes/batch.py`
3. 从 `web_app.py` 拆分模板管理API → `src/api/routes/templates.py`
4. 从 `web_app.py` 拆分点子生成API → `src/api/routes/ideas.py`
5. 创建 `src/api/schemas.py` - Pydantic数据模型
6. 创建 `src/api/__init__.py` 和 `src/api/routes/__init__.py`

### 步骤6：迁移GUI模块（第4-5天）

1. 从 `gui.py` 抽取主入口 → `src/gui/main.py`
2. 复制 `modules/workflow_control.py` → `src/gui/components/workflow_control.py`
3. 复制 `modules/parameter_settings.py` → `src/gui/components/parameter_settings.py`
4. 复制 `modules/result_display.py` → `src/gui/components/result_display.py`
5. 复制 `modules/log_panel.py` → `src/gui/components/log_panel.py`
6. 创建 `src/gui/__init__.py` 和 `src/gui/components/__init__.py`

### 步骤7：迁移调度器模块（第5天）

1. 复制 `hetero_scheduler/scheduler.py` → `src/scheduler/scheduler.py`
2. 复制 `hetero_scheduler/sub_queue.py` → `src/scheduler/sub_queue.py`
3. 创建 `src/scheduler/__init__.py`

### 步骤8：创建应用入口（第6天）

1. 创建 `src/main.py` - Flask应用入口
2. 更新导入路径

### 步骤9：测试验证（第7天）

1. 运行现有测试用例
2. 验证API功能正常
3. 验证GUI功能正常

---

## 六、风险评估

| 风险 | 描述 | 缓解措施 |
|-----|------|---------|
| **导入路径问题** | 重构后模块导入路径变更 | 使用IDE重构工具批量更新 |
| **测试用例失败** | 重构可能破坏现有功能 | 先运行测试用例确认基线 |
| **依赖缺失** | 新目录结构可能遗漏依赖 | 检查所有import语句 |
| **配置文件路径** | 配置文件路径可能失效 | 更新配置读取逻辑 |

---

## 七、后续优化计划

完成结构重构后，后续优化包括：

1. **命名规范统一**：统一使用英文命名，遵循PEP8
2. **消除代码冗余**：合并重复的工具函数
3. **类型注解完善**：为所有函数添加类型提示
4. **测试整理**：将测试文件移入`tests/`目录

---

## 八、所需资源

| 资源 | 说明 |
|-----|------|
| Python版本 | 3.10+ |
| 依赖包 | pydantic-settings, flask, flask-socketio |
| 工具 | Git（版本控制）, IDE（重构支持） |

---

## 九、预期成果

1. 清晰的模块化目录结构
2. 低耦合的模块设计
3. 符合Python规范的代码风格
4. 易于维护和扩展的代码库

---

**文档版本**: v1.0  
**创建日期**: 2026-05-15  
**状态**: 待审批