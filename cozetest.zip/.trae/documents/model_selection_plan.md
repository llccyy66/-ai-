# 模型选择与额度管理方案

## 1. 问题分析

### 1.1 问题描述
根据终端输出分析，当前系统在调用大模型API时遇到了429错误：
- `insufficient_quota`：用户配额不足
- `rate limit`：模型调用频率限制

### 1.2 官方解决方案
官方建议：
- 换一个模型
- 通过API-Provider绑定外部API提供方
- 查看HTTP响应头中的限额信息

### 1.3 技术挑战
1. 如何获取可用模型列表
2. 如何检查模型额度
3. 如何实现模型选择功能
4. 如何处理模型切换的异常情况

## 2. 解决方案设计

### 2.1 核心功能
1. **模型扫描**：获取所有可用的模型及其额度信息
2. **额度检查**：通过HTTP响应头检查当前模型的剩余额度
3. **模型选择**：让用户选择合适的模型
4. **动态切换**：在运行时根据额度情况自动切换模型

### 2.2 技术实现

#### 2.2.1 模型扫描功能
- 使用ModelScope API获取可用模型列表
- 检查每个模型的额度信息
- 缓存模型列表和额度信息

#### 2.2.2 额度检查功能
- 在每次API调用前检查模型额度
- 解析HTTP响应头中的限额信息
- 当额度不足时触发模型切换

#### 2.2.3 模型选择界面
- 命令行模式：交互式模型选择
- GUI模式：下拉菜单选择
- 保存用户选择的默认模型

#### 2.2.4 异常处理
- 捕获429错误并自动切换模型
- 实现重试机制
- 记录模型使用情况

## 3. 实施步骤

### 3.1 步骤1：添加模型管理模块

1. **创建模型管理工具函数**
   - `get_available_models()`：获取可用模型列表
   - `check_model_quota(model_id)`：检查模型额度
   - `select_model()`：模型选择逻辑

2. **修改call_llm函数**
   - 添加模型参数
   - 实现模型切换逻辑
   - 增加额度检查

### 3.2 步骤2：实现命令行模型选择

1. **添加模型选择交互**
   - 运行前扫描模型
   - 显示模型列表和额度
   - 让用户选择模型

2. **保存用户选择**
   - 保存到配置文件
   - 下次运行时默认使用

### 3.3 步骤3：集成到GUI

1. **添加模型设置界面**
   - 模型选择下拉菜单
   - 额度显示
   - 模型切换按钮

2. **实时额度检查**
   - 定期检查模型额度
   - 当额度不足时提醒用户

### 3.4 步骤4：异常处理和重试

1. **429错误处理**
   - 捕获429错误
   - 自动切换到其他模型
   - 记录切换日志

2. **重试机制**
   - 实现指数退避重试
   - 最大重试次数限制
   - 失败后的降级策略

## 4. 代码修改清单

### 4.1 工作流测试.py

| 位置 | 修改内容 | 优先级 |
|------|---------|--------|
| 第30-108行 | call_llm函数：添加模型参数和切换逻辑 | 高 |
| 新增 | 模型管理工具函数 | 高 |
| 第853-960行 | 主函数：添加模型选择逻辑 | 高 |

### 4.2 gui.py

| 位置 | 修改内容 | 优先级 |
|------|---------|--------|
| 第176-220行 | 大模型设置窗口：添加模型选择 | 中 |
| 第253-385行 | run_workflow：集成模型切换 | 中 |

## 5. 技术细节

### 5.1 模型扫描实现

```python
def get_available_models():
    """获取可用模型列表"""
    models = [
        "MiniMax/MiniMax-M2.5",
        "Qwen/Qwen2-1.5B-Instruct",
        "Llama-3-8B-Instruct",
        "GLM-4"
    ]
    model_info = {}
    for model in models:
        quota = check_model_quota(model)
        model_info[model] = quota
    return model_info

def check_model_quota(model_id):
    """检查模型额度"""
    try:
        # 发送测试请求获取响应头
        client = OpenAI(
            base_url='https://api-inference.modelscope.cn/v1',
            api_key='ms-1b80bfb3-02b0-4c82-abbe-c867b7faa160',
        )
        response = client.chat.completions.create(
            model=model_id,
            messages=[
                {"role": "user", "content": "test"}
            ],
            max_tokens=1
        )
        # 解析响应头
        headers = response.response.headers
        return {
            "limit": headers.get("modelscope-ratelimit-model-requests-limit"),
            "remaining": headers.get("modelscope-ratelimit-model-requests-remaining")
        }
    except Exception as e:
        return {"error": str(e)}
```

### 5.2 模型选择实现

```python
def select_model():
    """选择模型"""
    models = get_available_models()
    print("可用模型列表：")
    for i, (model, info) in enumerate(models.items()):
        if "error" in info:
            print(f"{i+1}. {model} - 不可用: {info['error']}")
        else:
            print(f"{i+1}. {model} - 剩余额度: {info['remaining']}/{info['limit']}")
    
    # 检查当前模型额度
    current_model = "MiniMax/MiniMax-M2.5"
    if current_model in models and "error" not in models[current_model]:
        remaining = models[current_model].get("remaining", 0)
        if int(remaining) > 10:
            print(f"\n当前模型 {current_model} 额度充足，默认使用")
            return current_model
    
    # 用户选择
    choice = input("请选择模型编号: ")
    try:
        selected = list(models.keys())[int(choice)-1]
        return selected
    except:
        return current_model
```

### 5.3 异常处理实现

```python
def call_llm(system_prompt, user_input, temperature=0.5, model=None):
    """调用大模型，支持模型切换"""
    if not model:
        model = "MiniMax/MiniMax-M2.5"
    
    retry_count = 0
    max_retries = 3
    
    while retry_count < max_retries:
        try:
            client = OpenAI(
                base_url='https://api-inference.modelscope.cn/v1',
                api_key='ms-1b80bfb3-02b0-4c82-abbe-c867b7faa160',
            )
            
            response = client.chat.completions.create(
                model=model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_input}
                ],
                temperature=temperature,
                stream=True
            )
            
            # 处理响应...
            return content
            
        except Exception as e:
            print(f"请求异常：{str(e)}")
            
            # 处理429错误
            if "429" in str(e):
                retry_count += 1
                if retry_count < max_retries:
                    # 尝试切换模型
                    models = get_available_models()
                    for m in models:
                        if m != model and "error" not in models[m]:
                            remaining = models[m].get("remaining", 0)
                            if int(remaining) > 0:
                                print(f"切换到模型：{m}")
                                model = m
                                break
                else:
                    # 降级处理
                    return get_default_response(system_prompt)
            else:
                # 其他错误直接返回默认值
                return get_default_response(system_prompt)
```

## 6. 风险评估

### 6.1 风险点
1. **模型可用性**：部分模型可能不可用或需要特殊权限
2. **额度检查准确性**：响应头信息可能不完整或不准确
3. **性能影响**：模型扫描和额度检查会增加启动时间
4. **用户体验**：模型选择过程可能会增加用户操作步骤

### 6.2 缓解措施
1. **缓存机制**：缓存模型列表和额度信息，减少重复请求
2. **默认模型**：设置可靠的默认模型，避免用户每次都需要选择
3. **异步检查**：在后台异步检查额度，不阻塞主流程
4. **错误处理**：完善的错误处理和降级策略

## 7. 预期效果

### 7.1 功能效果
1. **自动模型切换**：当遇到429错误时自动切换到其他可用模型
2. **额度管理**：实时显示和管理模型额度
3. **用户控制**：用户可以选择合适的模型
4. **稳定性提升**：减少API调用失败的情况

### 7.2 性能效果
1. **启动时间**：模型扫描增加约5-10秒启动时间
2. **运行时间**：模型切换可能增加少量运行时间
3. **成功率**：API调用成功率显著提升

## 8. 结论

通过实现模型选择和额度管理功能，可以有效解决API 429限流问题，提高系统的稳定性和可靠性。同时，用户可以根据自己的需求选择合适的模型，提升整体使用体验。

该方案既满足了官方的建议，又提供了灵活的模型管理机制，为系统的长期稳定运行提供了保障。