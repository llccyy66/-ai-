# 项目 Import 路径修复与模块迁移计划

## 一、目标

1. 修复 src/ 内部所有 import 路径，统一使用 `src.` 前缀或相对导入
2. 将根目录依赖模块迁移到 src/ 对应位置，消除 src/ 对根目录的反向依赖
3. 将 prompts/ 迁移到 src/prompts/
4. 基于新结构建立规范的 pytest 测试套件

---

## 二、当前问题总览

### 问题1：src/ 内部使用旧 import 路径

src/main.py 第4-5行通过 `sys.path.insert(0, src_dir)` 临时将 src/ 目录加入 sys.path，使得 `from utils.xxx`、`from core import xxx` 等旧路径暂时可用。但这不是规范的 Python 包导入方式，且在其他入口（如直接运行子模块）时会失败。

**受影响的文件和 import（共 14 个文件，30+ 处）：**

| 文件 | 旧路径 import | 修改方式 |
|------|--------------|---------|
| src/main.py:11 | `from api.routes import ...` | 改为相对导入 |
| src/main.py:12 | `from utils.logger import logger` | 改为相对导入 |
| src/core/workflow_engine.py:9-15 | `from utils.logger/logger/json_utils/config` | 改为相对导入 |
| src/core/image_engine.py:14-15,77 | `from utils.logger/config`, `from prompts.loader` | 改为相对导入 |
| src/core/draft_generator.py:6-7 | `from utils.logger`, `from config_loader` | 改为相对导入 |
| src/core/tts_engine.py:7-8,17 | `from utils.logger/config`, `from tts_service` | 改为相对导入 |
| src/api/routes/workflow.py:6-7,79 | `from core`, `from utils.logger`, `from template_loader` | 改为相对导入 |
| src/api/routes/batch.py:6-7,65 | `from core`, `from utils.logger`, `from template_loader` | 改为相对导入 |
| src/api/routes/ideas.py:4-5 | `from core`, `from utils.logger` | 改为相对导入 |
| src/api/routes/templates.py:5,13,28,53 | `from utils.logger`, `from template_loader` | 改为相对导入 |
| src/gui/main.py:9-12 | `from gui.components.xxx` | 改为相对导入 |
| src/gui/components/workflow_control.py:5-6,112,115 | `from utils.style/base_module/logger` | 改为相对导入 |
| src/gui/components/result_display.py:5-6,159,365 | `from utils.style/base_module/logger` | 改为相对导入 |
| src/gui/components/parameter_settings.py:5-6 | `from utils.style/base_module` | 改为相对导入 |
| src/gui/components/model_settings.py:5-6,398 | `from utils.style`, `from 工作流测试`, `from utils.logger` | 改为相对导入 |
| src/gui/components/log_panel.py:5-6 | `from utils.style/base_module` | 改为相对导入 |
| src/utils/json_utils.py:13,26 | `from utils.logger` | 改为相对导入 |
| src/utils/logger.py:36 | `from utils.log_config` | 改为相对导入 |
| src/utils/helpers.py:7 | `from utils.logger` | 改为相对导入 |

### 问题2：src/ 反向依赖根目录模块

| 根目录文件 | 被 src/ 中引用的位置 |
|-----------|---------------------|
| config_loader.py | src/core/draft_generator.py |
| template_loader.py | src/api/routes/templates.py, workflow.py, batch.py |
| tts_service.py | src/core/tts_engine.py |
| tts_config_loader.py | tts_service.py（间接被 src/ 依赖） |
| tts_dynamic_discoverer.py | tts_config_loader.py（间接被 src/ 依赖） |
| workflow_test.py | src/gui/components/model_settings.py |

### 问题3：prompts/ 散落在根目录

被 src/core/image_engine.py 和 workflow_test.py 引用。

### 问题4：中文文件名引用

`from 工作流测试 import check_model_quota` — model_settings.py 中引用了不存在的中文模块名。

---

## 三、导入策略决策

**核心原则：src/ 内部统一使用相对导入（PEP 328），根目录入口脚本使用 `from src.xxx` 绝对导入。**

理由：
- 相对导入是 Python 包的标准做法，不依赖 sys.path hack
- src/ 内部模块互相引用时，相对导入更健壮（不受运行目录影响）
- 根目录的入口脚本（run_api.py 等）已正确使用 `from src.xxx` 绝对导入

**示例：**
```python
# src/core/workflow_engine.py 中
# 旧：from utils.logger import logger
# 新：from ..utils.logger import logger

# src/api/routes/workflow.py 中
# 旧：from core import WorkflowEngine
# 新：from ...core import WorkflowEngine

# 根目录 run_api.py 中（不变）
# from src.main import create_app
```

---

## 四、执行步骤

### 阶段1：修复 src/ 内部 import 路径（不迁移文件，仅改 import）

此阶段仅修改 src/ 内部的 import 语句，将旧路径改为相对导入。**不移动任何文件。**

#### 1.1 修改 src/main.py

```python
# 删除 sys.path hack（第4-5行）
# 旧：
src_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, src_dir)

from api.routes import workflow_bp, batch_bp, templates_bp, ideas_bp
from utils.logger import logger

# 新：
from .api.routes import workflow_bp, batch_bp, templates_bp, ideas_bp
from .utils.logger import logger
```

#### 1.2 修改 src/core/ 下文件

**workflow_engine.py：**
```python
# 旧：from utils.logger import logger
# 新：from ..utils.logger import logger

# 旧：from utils.json_utils import JSONUtils
# 新：from ..utils.json_utils import JSONUtils

# 旧：from utils.config import (SILICONFLOW_API_KEY, ...)
# 新：from ..utils.config import (SILICONFLOW_API_KEY, ...)
```

**image_engine.py：**
```python
# 旧：from utils.logger import logger
# 新：from ..utils.logger import logger

# 旧：from utils.config import SILICONFLOW_API_KEY, ...
# 新：from ..utils.config import SILICONFLOW_API_KEY, ...

# 旧：from prompts.loader import get_image_generation_params
# 新：暂时保留（阶段3迁移 prompts 后再改）
```

**draft_generator.py：**
```python
# 旧：from utils.logger import logger
# 新：from ..utils.logger import logger

# 旧：from config_loader import get_text2image_config, ...
# 新：暂时保留（阶段2迁移 config_loader 后再改）
```

**tts_engine.py：**
```python
# 旧：from utils.logger import logger
# 新：from ..utils.logger import logger

# 旧：from utils.config import DEFAULT_TTS_MODEL
# 新：from ..utils.config import DEFAULT_TTS_MODEL

# 旧：from tts_service import get_tts_service
# 新：暂时保留（阶段2迁移 tts_service 后再改）
```

#### 1.3 修改 src/api/routes/ 下文件

**workflow.py：**
```python
# 旧：from core import WorkflowEngine, TTSEngine, ImageEngine, DraftGenerator
# 新：from ...core import WorkflowEngine, TTSEngine, ImageEngine, DraftGenerator

# 旧：from utils.logger import logger
# 新：from ...utils.logger import logger

# 旧：from template_loader import get_template_by_id
# 新：暂时保留（阶段2迁移 template_loader 后再改）
```

**batch.py：** 同 workflow.py 模式

**ideas.py：**
```python
# 旧：from core import WorkflowEngine
# 新：from ...core import WorkflowEngine

# 旧：from utils.logger import logger
# 新：from ...utils.logger import logger
```

**templates.py：**
```python
# 旧：from utils.logger import logger
# 新：from ...utils.logger import logger

# 旧：from template_loader import list_templates
# 新：暂时保留（阶段2迁移 template_loader 后再改）
```

#### 1.4 修改 src/gui/ 下文件

**main.py：**
```python
# 旧：from gui.components.workflow_control import WorkflowControlPanel
# 新：from .components.workflow_control import WorkflowControlPanel
# （同理其他3个组件）
```

**components/workflow_control.py：**
```python
# 旧：from utils.style import apply_style, apply_theme, COLORS, FONTS, PADDING
# 新：from ...utils.style import apply_style, apply_theme, COLORS, FONTS, PADDING

# 旧：from utils.base_module import BaseModule
# 新：from ...utils.base_module import BaseModule

# 旧：from utils.logger import logger
# 新：from ...utils.logger import logger
```

**components/result_display.py、parameter_settings.py、log_panel.py：** 同上模式

**components/model_settings.py：**
```python
# 旧：from utils.style import apply_style, apply_theme, COLORS, FONTS, PADDING
# 新：from ...utils.style import apply_style, apply_theme, COLORS, FONTS, PADDING

# 旧：from 工作流测试 import check_model_quota
# 新：暂时保留（阶段2迁移 workflow_test 后再改）

# 旧：from utils.logger import logger
# 新：from ...utils.logger import logger
```

#### 1.5 修改 src/utils/ 下文件

**json_utils.py：**
```python
# 旧：from utils.logger import logger
# 新：from .logger import logger
```

**logger.py：**
```python
# 旧：from utils.log_config import LOG_CONFIG
# 新：from .log_config import LOG_CONFIG
```

**helpers.py：**
```python
# 旧：from utils.logger import logger
# 新：from .logger import logger
```

#### 1.6 验证阶段1

修改完成后，运行以下命令验证 import 是否正确：
```bash
python -c "from src.main import create_app; print('OK')"
python -c "from src.core import WorkflowEngine; print('OK')"
python -c "from src.api.routes import workflow_bp; print('OK')"
```

---

### 阶段2：迁移根目录依赖模块到 src/

按依赖顺序分批迁移，每批迁移后立即修改所有引用方的 import。

#### 2.1 第一批：配置层（无内部依赖）

**迁移 config_loader.py → src/config/config_loader.py**

1. 将 `config_loader.py` 复制到 `src/config/config_loader.py`
2. 修改 `src/config/__init__.py`，添加 `from .config_loader import ...`
3. 修改引用方：
   - `src/core/draft_generator.py`：`from config_loader import ...` → `from ..config.config_loader import ...`
   - `workflow_test.py`：`from config_loader import ...` → `from src.config.config_loader import ...`（6处）
4. 处理路径问题：`CONFIG_PATH = "config.yaml"` 改为基于项目根目录的路径
5. 删除根目录 `config_loader.py`

**迁移 template_loader.py → src/config/template_loader.py**

1. 将 `template_loader.py` 复制到 `src/config/template_loader.py`
2. 修改 `src/config/__init__.py`，添加 `from .template_loader import ...`
3. 修改引用方：
   - `src/api/routes/templates.py`：`from template_loader import ...` → `from ...config.template_loader import ...`（3处）
   - `src/api/routes/workflow.py`：`from template_loader import ...` → `from ...config.template_loader import ...`
   - `src/api/routes/batch.py`：`from template_loader import ...` → `from ...config.template_loader import ...`
   - `workflow_test.py`：`from template_loader import ...` → `from src.config.template_loader import ...`
4. 处理路径问题：`TEMPLATE_FILE = "web/templates_data.json"` 改为基于项目根目录的路径
5. 删除根目录 `template_loader.py`

#### 2.2 第二批：TTS 配置链（按依赖顺序）

**迁移 tts_dynamic_discoverer.py → src/config/tts_dynamic_discoverer.py**

1. 将 `tts_dynamic_discoverer.py` 复制到 `src/config/tts_dynamic_discoverer.py`
2. 修改文件内延迟导入：`from utils import config as config_module` → `from ..utils import config as config_module`
3. 修改缓存文件路径：`tts_providers_cache.yaml` 改为基于项目根目录
4. 删除根目录 `tts_dynamic_discoverer.py`

**迁移 tts_config_loader.py → src/config/tts_config_loader.py**

1. 将 `tts_config_loader.py` 复制到 `src/config/tts_config_loader.py`
2. 修改内部 import：`from tts_dynamic_discoverer import ...` → `from .tts_dynamic_discoverer import ...`
3. 修改默认配置路径：`tts_providers.yaml` 改为基于项目根目录
4. 修改引用方：
   - `tts_service.py`（即将迁移）：`from tts_config_loader import ...` → `from ..config.tts_config_loader import ...`
   - `tts_config_manager.py`：`from tts_config_loader import ...` → `from src.config.tts_config_loader import ...`
5. 删除根目录 `tts_config_loader.py`

**迁移 tts_service.py → src/core/tts_service.py**

1. 将 `tts_service.py` 复制到 `src/core/tts_service.py`
2. 修改内部 import：
   - `from utils.task_queue_utils import load_global_config` → `from ..utils.task_queue_utils import load_global_config`
   - `from tts_config_loader import TTSConfigLoader` → `from ..config.tts_config_loader import TTSConfigLoader`
3. 修改引用方：
   - `src/core/tts_engine.py`：`from tts_service import get_tts_service` → `from .tts_service import get_tts_service`
   - `workflow_test.py`：`from tts_service import ...` → `from src.core.tts_service import ...`（2处）
4. 处理临时文件路径
5. 删除根目录 `tts_service.py`

#### 2.3 第三批：核心工作流

**迁移 workflow_test.py → src/core/workflow_test.py**

1. 将 `workflow_test.py` 复制到 `src/core/workflow_test.py`
2. 修改内部所有 import：
   - `from utils.logger import logger` → `from ..utils.logger import logger`
   - `from utils.json_utils import JSONUtils` → `from ..utils.json_utils import JSONUtils`
   - `from utils.config import (...)` → `from ..utils.config import (...)`
   - `from config_loader import ...` → `from ..config.config_loader import ...`
   - `from template_loader import ...` → `from ..config.template_loader import ...`
   - `from tts_service import ...` → `from .tts_service import ...`
   - `from prompts.loader import ...` → `from ..prompts.loader import ...`（阶段3后生效）
   - `from keyword_highlight import ...` → 删除或注释（模块已删除）
3. 修改引用方：
   - `src/gui/components/model_settings.py`：`from 工作流测试 import check_model_quota` → `from ...core.workflow_test import check_model_quota`
   - `idea_generator.py`：`from 工作流测试 import call_llm, SILICONFLOW_API_KEY` → `from src.core.workflow_test import call_llm, SILICONFLOW_API_KEY`
4. 删除根目录 `workflow_test.py`

#### 2.4 第四批：独立模块

**迁移 idea_generator.py → src/scheduler/idea_generator.py**

1. 将 `idea_generator.py` 复制到 `src/scheduler/idea_generator.py`
2. 修改内部 import：
   - `from utils.task_queue_utils import ...` → `from ..utils.task_queue_utils import ...`
   - `from 工作流测试 import ...` → `from ..core.workflow_test import ...`
   - `from utils.config import ...` → `from ..utils.config import ...`
3. 删除根目录 `idea_generator.py`

**迁移 langchain_tongyi_tts.py → src/core/langchain_tongyi_tts.py**

1. 将 `langchain_tongyi_tts.py` 复制到 `src/core/langchain_tongyi_tts.py`
2. 无需修改 import（无内部依赖）
3. 删除根目录 `langchain_tongyi_tts.py`

**迁移 import_to_jianying.py → src/utils/import_to_jianying.py**

1. 将 `import_to_jianying.py` 复制到 `src/utils/import_to_jianying.py`
2. 无需修改 import（无内部依赖）
3. 删除根目录 `import_to_jianying.py`

**迁移 tts_config_manager.py → src/config/tts_config_manager.py**

1. 将 `tts_config_manager.py` 复制到 `src/config/tts_config_manager.py`
2. 修改内部 import：`from tts_config_loader import ...` → `from .tts_config_loader import ...`
3. 删除根目录 `tts_config_manager.py`

**保留在根目录的文件（运维工具/启动入口）：**
- `run_api.py` — 启动入口
- `run_gui.py` — 启动入口
- `run_scheduler.py` — 启动入口
- `download_qwen3_models.py` — 运维工具
- `qwen3_align_worker.py` — 运维工具
- `qwen3_optimize.py` — 运维工具

---

### 阶段3：迁移 prompts/ 到 src/prompts/

1. 将 `prompts/` 目录整体移动到 `src/prompts/`
2. 修改引用方：
   - `src/core/image_engine.py`：`from prompts.loader import ...` → `from ..prompts.loader import ...`
   - `src/core/workflow_test.py`：`from prompts.loader import ...` → `from ..prompts.loader import ...`（3处）
3. 补充 `src/prompts/__init__.py` 中缺失的 `get_image_generation_params` 导出
4. 删除根目录 `prompts/`

---

### 阶段4：基于 src/ 重写测试

#### 4.1 建立测试基础设施

1. 创建 `tests/conftest.py`：
   - 配置 pytest 的 sys.path，确保 src/ 可导入
   - 提供通用 fixture（Flask 测试客户端、临时目录等）

2. 创建 `tests/__init__.py`

#### 4.2 编写核心模块测试

按模块优先级编写：

| 测试文件 | 测试目标 | 优先级 |
|---------|---------|--------|
| `tests/test_config.py` | src/config/settings.py, config_loader.py, template_loader.py | 高 |
| `tests/test_utils.py` | src/utils/logger.py, json_utils.py, helpers.py, config.py | 高 |
| `tests/test_workflow_engine.py` | src/core/workflow_engine.py（核心工作流） | 高 |
| `tests/test_tts_engine.py` | src/core/tts_engine.py, tts_service.py | 中 |
| `tests/test_image_engine.py` | src/core/image_engine.py | 中 |
| `tests/test_draft_generator.py` | src/core/draft_generator.py | 中 |
| `tests/test_api_routes.py` | src/api/routes/ 下所有路由 | 中 |
| `tests/test_scheduler.py` | src/scheduler/ 下调度器 | 低 |
| `tests/test_prompts.py` | src/prompts/loader.py | 低 |

#### 4.3 测试编写原则

- 使用 pytest fixture 而非全局状态
- Mock 外部 API 调用（LLM、TTS、图片生成）
- 每个测试独立，不依赖执行顺序
- 测试文件命名：`test_<module_name>.py`

---

## 五、路径处理策略

迁移后多个文件使用相对路径（如 `config.yaml`、`web/templates_data.json`），需要统一处理。

**方案：在 src/config/settings.py 中定义项目根目录常量**

```python
import os

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
# 指向 d:\trae_projects\cozetest

CONFIG_PATH = os.path.join(PROJECT_ROOT, "config.yaml")
TEMPLATES_DATA_PATH = os.path.join(PROJECT_ROOT, "web", "templates_data.json")
TTS_PROVIDERS_PATH = os.path.join(PROJECT_ROOT, "tts_providers.yaml")
TTS_PROVIDERS_CACHE_PATH = os.path.join(PROJECT_ROOT, "tts_providers_cache.yaml")
```

所有迁移后的文件统一从 `src.config.settings` 获取路径常量。

---

## 六、风险与注意事项

1. **workflow_test.py 体量巨大（214KB+）**：内部有大量延迟导入和函数内导入，需逐一排查修改
2. **中文文件名引用**：`from 工作流测试 import ...` 需在迁移 workflow_test.py 后统一修改
3. **keyword_highlight 引用**：workflow_test.py 中 `from keyword_highlight import ...` 引用了已删除的模块，需删除或注释
4. **qwen_asr 引用**：workflow_test.py 和 qwen3_align_worker.py 中 `from qwen_asr import ...` 引用了不存在的模块，需处理
5. **循环依赖风险**：tts_dynamic_discoverer.py 延迟导入了 utils.config，迁移后需确保不产生循环导入
6. **运行时路径**：所有相对路径需改为基于 PROJECT_ROOT 的绝对路径

---

## 七、最终项目结构

```
d:\trae_projects\cozetest/
├── .env / .env.example / .gitignore
├── config.yaml
├── tts_providers.yaml / tts_providers_cache.yaml
├── 任务队列.json
├── 视频封面.png
├── run_api.py              ← 启动入口
├── run_gui.py              ← 启动入口
├── run_scheduler.py        ← 启动入口
├── download_qwen3_models.py ← 运维工具
├── qwen3_align_worker.py   ← 运维工具
├── qwen3_optimize.py       ← 运维工具
├── output/                  ← 运行时输出
├── logs/                    ← 运行时日志
├── web/
│   └── templates_data.json
├── tests/                   ← 新的测试套件
│   ├── conftest.py
│   ├── test_config.py
│   ├── test_utils.py
│   ├── test_workflow_engine.py
│   └── ...
└── src/
    ├── __init__.py
    ├── main.py
    ├── api/
    │   ├── __init__.py
    │   ├── schemas.py
    │   └── routes/
    │       ├── __init__.py
    │       ├── workflow.py
    │       ├── batch.py
    │       ├── templates.py
    │       └── ideas.py
    ├── config/
    │   ├── __init__.py
    │   ├── settings.py
    │   ├── config_loader.py      ← 新迁移
    │   ├── template_loader.py    ← 新迁移
    │   ├── tts_config_loader.py  ← 新迁移
    │   ├── tts_dynamic_discoverer.py ← 新迁移
    │   └── tts_config_manager.py ← 新迁移
    ├── core/
    │   ├── __init__.py
    │   ├── workflow_engine.py
    │   ├── workflow_test.py      ← 新迁移
    │   ├── tts_engine.py
    │   ├── tts_service.py        ← 新迁移
    │   ├── image_engine.py
    │   ├── draft_generator.py
    │   └── langchain_tongyi_tts.py ← 新迁移
    ├── gui/
    │   ├── __init__.py
    │   ├── main.py
    │   └── components/
    │       ├── __init__.py
    │       ├── workflow_control.py
    │       ├── parameter_settings.py
    │       ├── model_settings.py
    │       ├── result_display.py
    │       └── log_panel.py
    ├── scheduler/
    │   ├── __init__.py
    │   ├── scheduler.py
    │   ├── sub_queue.py
    │   ├── task_queue.py
    │   └── idea_generator.py     ← 新迁移
    ├── prompts/                   ← 新迁移
    │   ├── __init__.py
    │   ├── loader.py
    │   ├── image_generation.json
    │   ├── script_generation.json
    │   └── tts_config.json
    └── utils/
        ├── __init__.py
        ├── base_module.py
        ├── concurrency.py
        ├── config.py
        ├── helpers.py
        ├── import_to_jianying.py  ← 新迁移
        ├── json_utils.py
        ├── log_config.py
        ├── logger.py
        ├── scrollable_frame.py
        ├── style.py
        └── task_queue_utils.py
```
