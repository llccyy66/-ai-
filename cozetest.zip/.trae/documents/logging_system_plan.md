# 日志系统优化设计方案

## 1. 项目现状分析

### 1.1 当前日志系统问题

- **简单的print输出**：当前代码主要使用`print`语句输出日志信息
- **缺乏统一接口**：不同模块使用不同的日志输出方式
- **无结构化信息**：日志信息缺乏时间戳、模块名、函数名等结构化信息
- **无日志级别**：没有区分DEBUG、INFO、WARNING、ERROR等不同级别的日志
- **无持久化存储**：日志信息仅输出到控制台，没有保存到文件
- **无异常处理**：异常信息处理简单，缺乏详细的堆栈跟踪
- **无性能监控**：缺乏关键操作的执行时间统计

### 1.2 代码分析

- **工作流测试.py**：主要使用`print`语句输出信息，包含多个核心函数如`generate_video_script`、`split_script`、`generate_image_prompts`等
- **gui.py**：有一个简单的`log`方法，将信息输出到日志面板，但功能有限

## 2. 日志系统设计目标

1. **统一日志接口**：提供统一的日志记录方法，方便在整个项目中使用
2. **多种日志级别**：支持DEBUG、INFO、WARNING、ERROR、CRITICAL等不同级别的日志
3. **详细的日志信息**：包含时间戳、模块名、函数名、行号等结构化信息
4. **多输出目标**：同时输出到控制台、日志文件和GUI界面
5. **异常处理**：提供详细的异常信息和堆栈跟踪
6. **性能监控**：记录关键操作的执行时间
7. **可配置性**：支持通过配置文件调整日志行为
8. **线程安全**：确保在多线程环境下的日志记录安全

## 3. 日志系统实现方案

### 3.1 核心组件设计

1. **Logger类**：核心日志类，提供统一的日志记录接口
2. **LogHandler**：日志处理器，负责将日志输出到不同目标
3. **LogFormatter**：日志格式化器，负责将日志信息格式化为指定格式
4. **ContextManager**：上下文管理器，用于记录代码块的执行时间

### 3.2 文件结构

```
cozetest/
├── utils/
│   ├── __init__.py
│   ├── logger.py      # 核心日志模块
│   └── log_config.py  # 日志配置
├── 工作流测试.py       # 主工作流文件
└── gui.py            # GUI界面
```

### 3.3 核心功能实现

#### 3.3.1 日志级别

- **DEBUG**：详细的调试信息，通常仅在开发和调试时使用
- **INFO**：一般信息，用于确认系统正常运行
- **WARNING**：警告信息，表示可能出现的问题
- **ERROR**：错误信息，表示发生了错误但系统仍能继续运行
- **CRITICAL**：严重错误信息，表示系统可能无法继续运行

#### 3.3.2 日志格式

```
[2026-04-13 19:41:48] [INFO] [工作流测试.py:181] [generate_video_script] 开始生成视频文案...
```

#### 3.3.3 日志输出目标

1. **控制台**：实时输出日志信息
2. **日志文件**：将日志保存到文件，方便后续分析
3. **GUI界面**：在GUI应用中显示日志信息

#### 3.3.4 性能监控

- 提供装饰器和上下文管理器，用于记录函数和代码块的执行时间
- 自动计算执行时间并记录到日志中

#### 3.3.5 异常处理

- 捕获异常并记录详细的异常信息和堆栈跟踪
- 支持异常的分类和自定义处理

## 4. 具体实现步骤

### 4.1 创建核心日志模块

1. **创建 utils/logger.py**：实现核心日志功能
2. **创建 utils/log_config.py**：定义日志配置

### 4.2 集成到工作流测试.py

1. 替换现有的print语句为日志调用
2. 添加性能监控和异常处理

### 4.3 集成到gui.py

1. 修改现有的log方法，使用新的日志系统
2. 确保GUI日志面板能够显示结构化的日志信息

### 4.4 测试和优化

1. 测试日志系统的功能和性能
2. 优化日志输出格式和性能

## 5. 代码实现示例

### 5.1 utils/logger.py

```python
import logging
import time
import traceback
import threading
from functools import wraps

class Logger:
    def __init__(self, name=__name__, log_file="logs/app.log"):
        self.logger = logging.getLogger(name)
        self.logger.setLevel(logging.DEBUG)
        
        # 确保日志目录存在
        import os
        log_dir = os.path.dirname(log_file)
        if log_dir and not os.path.exists(log_dir):
            os.makedirs(log_dir)
        
        # 文件处理器
        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        file_handler.setLevel(logging.DEBUG)
        
        # 控制台处理器
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        
        # 格式化器
        formatter = logging.Formatter(
            '[%(asctime)s] [%(levelname)s] [%(filename)s:%(lineno)d] [%(funcName)s] %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        
        file_handler.setFormatter(formatter)
        console_handler.setFormatter(formatter)
        
        # 添加处理器
        if not self.logger.handlers:
            self.logger.addHandler(file_handler)
            self.logger.addHandler(console_handler)
        
        # GUI日志回调
        self.gui_callback = None
    
    def set_gui_callback(self, callback):
        """设置GUI日志回调"""
        self.gui_callback = callback
    
    def _log(self, level, message, *args, **kwargs):
        """核心日志记录方法"""
        # 获取调用者信息
        import inspect
        caller_frame = inspect.currentframe().f_back.f_back
        caller_info = inspect.getframeinfo(caller_frame)
        
        # 构建日志信息
        log_message = message % args
        
        # 记录日志
        getattr(self.logger, level)(log_message, extra={
            'filename': caller_info.filename.split('/')[-1],
            'lineno': caller_info.lineno,
            'funcName': caller_info.function
        })
        
        # GUI回调
        if self.gui_callback:
            self.gui_callback(log_message, level)
    
    def debug(self, message, *args):
        """记录DEBUG级别日志"""
        self._log('debug', message, *args)
    
    def info(self, message, *args):
        """记录INFO级别日志"""
        self._log('info', message, *args)
    
    def warning(self, message, *args):
        """记录WARNING级别日志"""
        self._log('warning', message, *args)
    
    def error(self, message, *args):
        """记录ERROR级别日志"""
        self._log('error', message, *args)
    
    def critical(self, message, *args):
        """记录CRITICAL级别日志"""
        self._log('critical', message, *args)
    
    def exception(self, message, *args):
        """记录异常信息"""
        # 获取异常信息
        exc_info = traceback.format_exc()
        log_message = f"{message % args}\n{exc_info}"
        
        # 记录错误日志
        self._log('error', log_message)
    
    def timeit(self, func):
        """性能监控装饰器"""
        @wraps(func)
        def wrapper(*args, **kwargs):
            start_time = time.time()
            try:
                result = func(*args, **kwargs)
                end_time = time.time()
                execution_time = end_time - start_time
                self.info(f"函数 {func.__name__} 执行完成，耗时 {execution_time:.4f} 秒")
                return result
            except Exception as e:
                end_time = time.time()
                execution_time = end_time - start_time
                self.error(f"函数 {func.__name__} 执行失败，耗时 {execution_time:.4f} 秒")
                raise
        return wrapper
    
    def time_context(self, name):
        """性能监控上下文管理器"""
        return TimeContext(self, name)

class TimeContext:
    def __init__(self, logger, name):
        self.logger = logger
        self.name = name
    
    def __enter__(self):
        self.start_time = time.time()
        self.logger.info(f"开始执行: {self.name}")
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        end_time = time.time()
        execution_time = end_time - start_time
        if exc_type:
            self.logger.error(f"执行 {self.name} 失败，耗时 {execution_time:.4f} 秒")
        else:
            self.logger.info(f"执行 {self.name} 完成，耗时 {execution_time:.4f} 秒")

# 创建全局日志实例
logger = Logger()
```

### 5.2 utils/log_config.py

```python
# 日志配置
LOG_CONFIG = {
    "log_file": "logs/app.log",
    "log_level": "INFO",
    "max_log_size": 10 * 1024 * 1024,  # 10MB
    "backup_count": 5
}
```

### 5.3 集成到工作流测试.py

```python
# 导入日志模块
from utils.logger import logger

@logger.timeit
def generate_video_script(subject, author, word_num, model=None):
    """工作流节点145450：生成B站财富认知视频文案"""
    logger.info(f"开始生成视频文案：主题={subject}, 作者={author}, 字数={word_num}")
    system_prompt = """你是专业的B站知识区财富认知类视频文案创作者..."""
    user_input = f"生成{word_num}字文案，主题：{subject}，UP主：{author}"
    try:
        result = call_llm(system_prompt, user_input, temperature=0.5, model=model)
        logger.info("视频文案生成完成")
        return result
    except Exception as e:
        logger.exception(f"生成文案时出错")
        # 返回默认文案
        return "# 普通人如何摆脱月光族"
```

### 5.4 集成到gui.py

```python
# 导入日志模块
from utils.logger import logger

class VideoWorkflowGUI:
    def __init__(self, root):
        # ... 现有代码 ...
        
        # 设置日志回调
        logger.set_gui_callback(self.log)
        
    def log(self, message, level="info"):
        """记录日志"""
        if hasattr(self, "log_panel"):
            self.log_panel.log(message, level)
```

## 6. 预期效果

1. **结构化日志**：日志信息包含时间戳、级别、模块名、函数名、行号等详细信息
2. **多级别日志**：根据不同的日志级别显示不同的颜色和格式
3. **持久化存储**：日志信息保存到文件，方便后续分析和调试
4. **性能监控**：自动记录关键函数的执行时间，帮助识别性能瓶颈
5. **异常处理**：详细记录异常信息和堆栈跟踪，方便排查问题
6. **统一接口**：整个项目使用统一的日志接口，提高代码一致性
7. **线程安全**：在多线程环境下安全记录日志

## 7. 风险和注意事项

1. **性能影响**：详细的日志记录可能会对性能产生一定影响，尤其是在高频操作中
2. **日志文件大小**：需要定期清理日志文件，避免占用过多磁盘空间
3. **配置管理**：需要确保日志配置的合理设置，避免日志过多或过少
4. **兼容性**：确保日志系统与现有代码的兼容性，避免破坏现有功能

## 8. 后续优化方向

1. **日志轮转**：实现日志文件的自动轮转，避免单个日志文件过大
2. **远程日志**：支持将日志发送到远程服务器，方便集中管理
3. **日志分析**：提供日志分析工具，帮助识别问题和优化性能
4. **结构化日志**：支持JSON格式的结构化日志，方便机器解析
5. **日志过滤**：支持根据条件过滤日志，提高日志查看效率
