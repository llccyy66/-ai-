# 草稿保存路径配置实现计划

## 1. 问题分析

用户希望在 config.yaml 中添加配置项，让生成的剪映草稿直接保存到 `D:\JianyingPro Drafts` 路径，而不是当前的项目目录。同时需要确保 `run_hetero_scheduler.py` 和 `工作流测试.py` 都能正确支持这个功能。

## 2. 当前实现分析

### 2.1 草稿保存机制
通过查看代码，我发现：

1. **DraftFolder 类** (`pyJianYingDraft-0.2.6/pyJianYingDraft/draft_folder.py`)：负责管理草稿文件夹的创建和保存
2. **工作流测试.py**：有两个主要函数创建草稿：
   - 第 1731 行：`draft_folder = DraftFolder(project_dir)`
   - 第 3820 行：`draft_folder = DraftFolder(project_dir)` (在 `create_jianying_draft_with_pyJianYingDraft` 函数中)

### 2.2 现有配置文件
- `config.yaml`：目前没有草稿保存路径的配置
- `config_loader.py`：负责读取配置文件的模块

### 2.3 异构调度器
- `hetero_scheduler/integrated_scheduler.py`：调用 `工作流测试.py` 中的 `segmented_workflow` 函数
- 需要确保该调度器也能正确使用新的草稿保存路径

## 3. 实现方案

### 3.1 修改 config.yaml
添加草稿保存路径配置项：
```yaml
# 剪映草稿保存路径配置
draft_save:
  enabled: true
  path: "D:\\JianyingPro Drafts"
```

### 3.2 修改 config_loader.py
添加函数来读取草稿保存路径配置

### 3.3 修改 工作流测试.py
- 修改草稿创建逻辑，支持可选的草稿保存路径
- 如果配置了草稿保存路径，则将草稿复制到目标位置，或直接在目标位置创建
- 保持向后兼容性：如果没有配置，仍然使用原有的 project_dir

### 3.4 验证 run_hetero_scheduler.py
- 该调度器通过调用工作流测试中的函数来执行，所以只要工作流测试支持了新功能，调度器也会自动支持
- 不需要单独修改调度器代码

## 4. 具体实现步骤

### 步骤 1：修改 config.yaml
在 config.yaml 末尾添加草稿保存路径配置

### 步骤 2：修改 config_loader.py
添加 `get_draft_save_path()` 函数

### 步骤 3：修改 工作流测试.py
- 在草稿创建后，如果配置了保存路径，需要：
  - 选项 A：将草稿从 project_dir 复制到配置路径
  - 选项 B：直接在配置路径创建草稿（更高效）
- 选择选项 B 更高效

## 5. 风险和注意事项
- 需要确保目标路径存在，如果不存在需要创建
- 需要考虑路径格式问题（Windows 路径格式）
- 保持向后兼容，不破坏现有功能
