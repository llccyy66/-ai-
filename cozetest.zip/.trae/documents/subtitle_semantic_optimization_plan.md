# 字幕语义优化功能实现计划

## 一、需求分析

### 1.1 问题描述

当前字幕分割存在以下语义断裂问题：
- **人名拆分**：如"特朗普"被拆分为"特朗" + "普"
- **数字符号拆分**：如"50%"被拆分为"50" + "%"
- **词语拆分**：如"人工智能"被拆分为"人工" + "智能"
- **标点位置不当**：标点符号单独占一行

### 1.2 解决方案

在时间戳生成后、绑定数据构建前，插入LLM语义优化步骤，让大模型充当"字幕编辑"角色，对原始时间戳进行语义级优化。

---

## 二、实现方案

### 2.1 方案架构

```
步骤3: align_segments() → 原始时间戳
            │
            ▼
步骤3.5: semantic_optimize_timestamps() → 语义优化后的时间戳（新增）
            │
            ▼
步骤4: build_binding_data()
```

### 2.2 核心函数设计

#### 函数签名

```python
def semantic_optimize_timestamps(original_text, timestamps, model=None):
    """使用大模型对时间戳进行语义优化
    
    Args:
        original_text: 原始完整文本
        timestamps: 原始时间戳列表
        model: LLM模型
    
    Returns:
        list: 优化后的时间戳列表
    """
```

#### 优化规则

| 规则 | 描述 |
|------|------|
| 人名完整性 | 确保中文姓名不被拆分到不同字幕 |
| 数字符号完整性 | 确保数字与百分号、单位等组合保持在同一字幕 |
| 词语完整性 | 确保多字词不被拆分 |
| 标点位置 | 标点符号应跟随前一个字幕，不应单独占一行 |
| 阅读流畅性 | 每个字幕长度适中（2-10个字） |

---

## 三、文件修改计划

### 3.1 修改文件列表

| 文件 | 修改类型 | 说明 |
|------|----------|------|
| `工作流测试.py` | 新增函数 + 修改工作流 | 添加语义优化函数和调用逻辑 |

### 3.2 具体修改内容

#### 修改1：新增语义优化函数

在 `工作流测试.py` 中添加 `semantic_optimize_timestamps()` 函数，位置在 `align_segments()` 函数之后。

#### 修改2：在工作流中插入调用

在 `segmented_workflow()` 函数中，步骤3和步骤4之间插入语义优化调用：

```python
# 当前位置：约第3119行
aligned_segments, qwen3_api_status = align_segments(tts_results, project_dir=project_dir, tts_model=tts_model)
step_times["步骤3-并行处理"] = time.time() - t0

# ========== 新增：步骤3.5 语义优化 ==========
t0 = time.time()
step_timestamps["步骤3.5-语义优化"] = time.strftime("%H:%M:%S")
print(f"\n[步骤3.5] 语义优化字幕时间戳")

# 收集所有时间戳
all_timestamps = []
for seg in aligned_segments:
    all_timestamps.extend(seg["timestamps"])

# 调用LLM进行语义优化
optimized_timestamps = semantic_optimize_timestamps(full_text, all_timestamps, llm_model)

# 将优化后的时间戳重新分配回各段
timestamp_idx = 0
for seg in aligned_segments:
    seg["timestamps"] = optimized_timestamps[timestamp_idx:timestamp_idx + len(seg["timestamps"])]
    timestamp_idx += len(seg["timestamps"])

step_times["步骤3.5-语义优化"] = time.time() - t0
# ========== 语义优化结束 ==========

# 步骤4: 构建绑定数据
t0 = time.time()
step_timestamps["步骤4-绑定"] = time.strftime("%H:%M:%S")
binding_data = build_binding_data(aligned_segments, semantic_groups, image_results)
```

---

## 四、系统提示词设计

```python
system_prompt = """你是一个专业的短视频字幕优化专家。你的任务是对AI生成的字幕时间戳进行语义优化。

## 优化规则
1. **人名完整性**：确保中文姓名（如"特朗普"、"习近平"）不被拆分到不同字幕
2. **数字符号完整性**：确保数字与百分号、单位等组合（如"50%"、"3.14元"）保持在同一字幕
3. **词语完整性**：确保多字词（如"人工智能"、"中华人民共和国"）不被拆分
4. **标点位置**：标点符号应跟随前一个字幕，不应单独占一行
5. **阅读流畅性**：每个字幕长度适中（2-10个字），避免过短或过长

## 优化策略
1. 识别需要合并的相邻时间戳
2. 将它们的文本合并，时间取最早开始和最晚结束
3. 保持其他时间戳不变

## 输出格式
你必须输出优化后的时间戳JSON数组，格式如下：
[
  {"text": "字幕内容", "start": 0.0, "end": 0.5},
  {"text": "特朗普说过50%", "start": 1.0, "end": 1.7}
]

注意：只输出JSON，不要输出其他内容。时间戳必须按时间顺序排列。"""
```

---

## 五、输入输出示例

### 输入（原始时间戳）

```json
{
  "original_text": "普通人想要摆脱月光族的困境，特朗普说过50%的人都有这个问题。",
  "timestamps": [
    {"text": "普通人", "start": 0.0, "end": 0.3},
    {"text": "特朗", "start": 1.4, "end": 1.6},
    {"text": "普", "start": 1.6, "end": 1.7},
    {"text": "50", "start": 1.9, "end": 2.0},
    {"text": "%", "start": 2.0, "end": 2.1}
  ]
}
```

### 输出（优化后时间戳）

```json
[
  {"text": "普通人", "start": 0.0, "end": 0.3},
  {"text": "特朗普说过50%", "start": 1.4, "end": 2.1}
]
```

---

## 六、风险处理

| 风险 | 处理方案 |
|------|----------|
| LLM调用失败 | 回退使用原始时间戳 |
| LLM输出格式错误 | JSON解析失败时使用原始时间戳 |
| 性能影响 | 记录耗时，便于后续优化 |

---

## 七、测试验证

### 测试用例

| 测试场景 | 输入 | 期望输出 |
|----------|------|----------|
| 人名拆分 | "特朗普" | 保持完整 |
| 数字符号拆分 | "50%" | 保持完整 |
| 多字词拆分 | "人工智能" | 保持完整 |
| 标点位置 | "很好。明天" | 合并为"很好。明天" |

---

## 八、实施步骤

1. 在 `工作流测试.py` 中添加 `semantic_optimize_timestamps()` 函数
2. 在 `segmented_workflow()` 函数中插入调用
3. 测试功能是否正常工作
4. 验证语义优化效果

---

## 九、相关依赖

- `call_llm()` 函数：用于调用大语言模型
- `json` 模块：用于解析LLM输出
- 现有日志系统：用于记录优化过程