# TTS语音合成失败分析报告

## 问题描述

**错误信息**：
```
websockets.exceptions.InvalidStatus: server rejected WebSocket connection: HTTP 200
```

**发生位置**：
- 文件：[tts_service.py:112](file:///c:/Users/18622/Documents/trae_projects/cozetest/tts_service.py#L112)
- 函数：MiniMaxTTSProvider._synthesize()
- 调用链：text_to_speech → tts_service.synthesize() → _synthesize()

---

## 问题分析

### 1. 技术层面分析

#### WebSocket连接失败原因

错误信息 `server rejected WebSocket connection: HTTP 200` 表明：

| 可能原因 | 说明 | 检查方法 |
|---------|------|---------|
| **API密钥无效** | Bearer Token不被服务器接受 | 验证密钥格式和有效性 |
| **API密钥过期** | MiniMax密钥可能已过期 | 登录MiniMax控制台检查 |
| **权限不足** | 密钥没有TTS服务权限 | 检查API Key权限列表 |
| **端点变更** | WebSocket URL可能已更新 | 查看MiniMax最新文档 |
| **服务端限制** | IP白名单或请求频率限制 | 检查账户限制 |

#### 代码执行流程

```
text_to_speech() 
  ↓
tts_service.synthesize() 
  ↓
MiniMaxTTSProvider.synthesize()
  ├─ 创建URL: wss://api.minimaxi.com/ws/v1/t2a_v2
  ├─ 创建认证头: {"Authorization": f"Bearer {api_key}"}
  ├─ 创建SSL上下文（跳过证书验证）
  └─ 建立WebSocket连接
      ↓
      [错误发生在此处]
```

### 2. 配置分析

查看 [config.yaml:173-178](file:///c:/Users/18622/Documents/trae_projects/cozetest/config.yaml#L173-L178)：

```yaml
tts:
  provider: "minimax"
  api_key: ""  # 为空，从环境变量读取
  model: "speech-2.8-hd"
  voice: "male-qn-qingse"
```

API密钥配置为空，实际从环境变量 `MINIMAX_API_KEY` 获取（[tts_service.py:65](file:///c:/Users/18622/Documents/trae_projects/cozetest/tts_service.py#L65)）。

### 3. 错误处理分析

#### 重试机制（存在但可能不够完善）

[工作流测试.py:444-464](file:///c:/Users/18622/Documents/trae_projects/cozetest/工作流测试.py#L444-L464)：

```python
max_tts_retries = 3
for tts_attempt in range(max_tts_retries):
    try:
        audio_path = tts_service.synthesize(...)
    except Exception as tts_e:
        is_network_error = any(kw in str(tts_e) for kw in 
            ["SSL", "Connection", "timeout", "EOF", "timed out", "Reset"])
        if is_network_error and tts_attempt < max_tts_retries - 1:
            # 重试逻辑
```

**问题**：`InvalidStatus` 错误未包含在网络错误关键词列表中，可能导致首次失败就抛出异常。

---

## 根本原因推测

根据HTTP 200响应码分析，最可能的原因是：

1. **❌ 最可能：API Key无效或过期**
   - Bearer Token格式正确但服务器拒绝
   - 需要重新获取有效的API Key

2. **❌ 次可能：服务端拒绝该类型的WebSocket请求**
   - MiniMax可能更新了API端点
   - 需要验证URL是否正确

3. **❌ 较少可能：网络/防火墙问题**
   - WebSocket握手失败但返回200
   - 通常这种情况返回的是403或404

---

## 解决方案建议

### 方案A：验证MiniMax API Key（推荐优先尝试）

1. **检查环境变量**
   ```bash
   echo $env:MINIMAX_API_KEY
   ```

2. **登录MiniMax控制台**
   - 访问 https://platform.minimaxi.com
   - 检查API Key状态和余额

3. **测试API Key有效性**
   - 确认Key未被禁用
   - 确认有TTS服务权限

### 方案B：切换到备用TTS服务商（阿里百炼）

当前代码已支持多服务商，切换步骤：

1. 修改 [config.yaml:174](file:///c:/Users/18622/Documents/trae_projects/cozetest/config.yaml#L174)：
   ```yaml
   tts:
     provider: "bailian"  # 切换为阿里百炼
     api_key: "sk-xxxxx"  # 填入阿里百炼Key
     model: "qwen3-tts-flash"
     voice: "Moon"
   ```

2. 或设置环境变量：
   ```bash
   $env:DASHSCOPE_API_KEY="sk-xxxxx"
   ```

### 方案C：增强错误处理

建议将 `InvalidStatus` 纳入网络错误重试机制：

修改 [工作流测试.py:457](file:///c:/Users/18622/Documents/trae_projects/cozetest/工作流测试.py#L457)：
```python
is_network_error = any(kw in tts_error_msg for kw in 
    ["SSL", "Connection", "timeout", "EOF", "timed out", "Reset", 
     "InvalidStatus", "rejected WebSocket"])
```

---

## 诊断步骤清单

- [ ] 1. 确认 `MINIMAX_API_KEY` 环境变量已设置
- [ ] 2. 验证API Key在MiniMax官网有效
- [ ] 3. 检查账户余额是否充足
- [ ] 4. 确认TTS服务已开通
- [ ] 5. 尝试切换到阿里百炼作为备选

---

## 结论

**问题类型**：认证/授权失败

**解决优先级**：
1. 验证MiniMax API Key有效性
2. 如Key无效，切换到阿里百炼
3. 代码层面可优化错误重试机制

**预计修复时间**：5-15分钟（主要取决于API Key状态确认）
