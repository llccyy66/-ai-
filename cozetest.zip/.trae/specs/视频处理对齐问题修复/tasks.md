# 视频处理对齐问题修复 - 实现计划

## 任务1: 诊断字幕乱码问题
- **Priority**: P0
- **Depends On**: None
- **Description**:
  - 检查字幕内容在draft_content.json中的存储格式
  - 验证字幕文本的编码是否正确
  - 区分终端显示乱码和实际数据存储乱码
- **Acceptance Criteria Addressed**: AC-1
- **Test Requirements**:
  - `programmatic` TR-1.1: 检查draft_content.json中字幕的content字段编码
  - `human-judgment` TR-1.2: 在剪映中预览视频，检查字幕是否正确显示

## 任务2: 调整图片生成数量算法
- **Priority**: P0
- **Depends On**: None
- **Description**:
  - 修改图片分配算法，确保每5秒生成一张图片
  - 对于109秒的视频，应生成约22张图片
  - 图片时间范围应均匀分布，覆盖整个视频时长
- **Acceptance Criteria Addressed**: AC-2
- **Test Requirements**:
  - `programmatic` TR-2.1: 运行工作流，检查生成的图片数量是否为约22张
  - `programmatic` TR-2.2: 检查图片时间范围是否均匀分布

## 任务3: 优化语音文本处理流程
- **Priority**: P1
- **Depends On**: 任务1
- **Description**:
  - 分析当前文本校验逻辑的执行条件
  - 优化文本一致性判断逻辑，避免不必要的TTS重新生成
  - 如果ASR识别的文本与原始文本一致（仅数字格式不同），不应重新生成TTS
- **Acceptance Criteria Addressed**: AC-3
- **Test Requirements**:
  - `programmatic` TR-3.1: 检查日志，确认没有不必要的TTS重新生成
  - `programmatic` TR-3.2: 验证文本校验逻辑的正确性

## 任务4: 验证修复效果
- **Priority**: P1
- **Depends On**: 任务1, 任务2, 任务3
- **Description**:
  - 运行完整工作流，验证修复效果
  - 确保字幕内容正确显示
  - 确保图片生成数量满足要求
  - 确保语音文本处理流程优化
- **Acceptance Criteria Addressed**: AC-1, AC-2, AC-3
- **Test Requirements**:
  - `human-judgment` TR-4.1: 在剪映中预览视频，检查字幕内容
  - `programmatic` TR-4.2: 检查生成的图片数量和时间范围
  - `programmatic` TR-4.3: 检查日志，确认没有不必要的TTS重新生成