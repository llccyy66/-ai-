# 音频优先的多模态绑定优化 - 实施计划

## [ ] Task 1: 调研阿里百炼API能力
- **Priority**: P0
- **Depends On**: None
- **Description**: 
  - 调研阿里百炼TTS对长文本的支持长度
  - 调研阿里百炼ASR的时间戳输出能力
  - 确认API调用方式和参数
- **Acceptance Criteria Addressed**: AC-1, AC-2
- **Test Requirements**:
  - `programmatic` TR-1.1: 验证阿里百炼TTS支持500字长文本
  - `programmatic` TR-1.2: 验证阿里百炼ASR返回时间戳信息
- **Notes**: 记录API文档链接和调用示例

## [ ] Task 2: 实现完整文案TTS生成
- **Priority**: P0
- **Depends On**: Task 1
- **Description**: 
  - 创建 `text_to_speech_full()` 函数，支持长文本一次性生成
  - 处理API调用和错误重试
  - 保存完整音频文件
- **Acceptance Criteria Addressed**: AC-1
- **Test Requirements**:
  - `programmatic` TR-2.1: 500字文本成功生成完整音频
  - `human-judgment` TR-2.2: 音频流畅无段落感
- **Notes**: 处理可能的API超时和长度限制

## [ ] Task 3: 实现音频时间轴ASR识别
- **Priority**: P0
- **Depends On**: Task 2
- **Description**: 
  - 创建 `audio_to_subtitles()` 函数，调用ASR API
  - 解析ASR结果，生成SRT格式字幕
  - 处理识别错误和时间戳提取
- **Acceptance Criteria Addressed**: AC-2
- **Test Requirements**:
  - `programmatic` TR-3.1: ASR成功识别并生成带时间戳的SRT
  - `programmatic` TR-3.2: 字幕分割准确率≥95%
- **Notes**: 实现ASR失败的降级策略（使用现有逐条分割）

## [ ] Task 4: 优化分镜提示词生成
- **Priority**: P1
- **Depends On**: Task 3
- **Description**: 
  - 修改 `generate_image_prompts()` 函数，支持基于时间戳的分割字幕
  - 确保提示词与对应时间段的语义匹配
- **Acceptance Criteria Addressed**: AC-3
- **Test Requirements**:
  - `programmatic` TR-4.1: 为每个时间段生成合适的提示词
  - `human-judgment` TR-4.2: 提示词与语义匹配度≥90%
- **Notes**: 保持与现有图片生成逻辑兼容

## [ ] Task 5: 实现新的工作流流程
- **Priority**: P0
- **Depends On**: Task 2, Task 3, Task 4
- **Description**: 
  - 创建新的 `main_audio_first()` 函数
  - 实现：完整文案 → 完整配音 → ASR分割 → 图片生成 → 绑定
  - 保持与现有自检体系的兼容性
- **Acceptance Criteria Addressed**: AC-4, AC-5
- **Test Requirements**:
  - `programmatic` TR-5.1: 完整流程执行无错误
  - `programmatic` TR-5.2: 自检报告PASS
- **Notes**: 添加流程选择参数，支持切换新旧流程

## [ ] Task 6: 性能测试与优化
- **Priority**: P1
- **Depends On**: Task 5
- **Description**: 
  - 测试新流程的执行时间
  - 与现有流程对比性能
  - 优化API调用和文件处理
- **Acceptance Criteria Addressed**: NFR-1
- **Test Requirements**:
  - `programmatic` TR-6.1: 新流程时间不超过旧流程的120%
  - `programmatic` TR-6.2: 内存使用合理
- **Notes**: 记录性能测试结果

## [ ] Task 7: 质量评估
- **Priority**: P1
- **Depends On**: Task 5
- **Description**: 
  - 对比新旧流程的配音流畅度
  - 评估图片与配音的绑定准确性
  - 验证时间轴对齐精度
- **Acceptance Criteria Addressed**: NFR-2, NFR-3
- **Test Requirements**:
  - `human-judgment` TR-7.1: 配音流畅度优于旧流程
  - `programmatic` TR-7.2: 时间轴对齐误差≤0.5秒
- **Notes**: 记录主观评估结果

## [ ] Task 8: 文档更新
- **Priority**: P2
- **Depends On**: Task 5
- **Description**: 
  - 更新工程文档，添加新流程说明
  - 记录API调用方式和参数
  - 提供新流程的使用示例
- **Acceptance Criteria Addressed**: None
- **Test Requirements**:
  - `human-judgment` TR-8.1: 文档完整清晰
- **Notes**: 保持与现有文档风格一致