# 修改文生图默认模型 - 产品需求文档

## Overview
- **Summary**: 将文生图默认模型从 `Kwai-Kolors/Kolors` 修改为 `Z-Image-Turbo`
- **Purpose**: 提升文生图生成速度和质量
- **Target Users**: 视频生成系统用户

## Goals
- 将默认图像生成模型改为 `Z-Image-Turbo`
- 更新模型列表以包含新模型
- 验证修改后代码能正常运行

## Non-Goals (Out of Scope)
- 修改文生图API调用逻辑
- 修改参数配置
- 测试实际图像生成效果

## Background & Context
当前系统使用 `Kwai-Kolors/Kolors` 作为默认文生图模型，现需更换为 `Z-Image-Turbo` 模型以获得更好的性能。

## Functional Requirements
- **FR-1**: 修改 `DEFAULT_IMAGE_MODEL` 变量值为 `Z-Image-Turbo`
- **FR-2**: 更新 `IMAGE_MODELS` 列表包含 `Z-Image-Turbo`

## Constraints
- **Technical**: 新模型必须支持硅基流动API
- **Dependencies**: 硅基流动平台需支持 `Z-Image-Turbo` 模型

## Assumptions
- `Z-Image-Turbo` 模型在硅基流动平台可用
- 新模型与现有API调用兼容

## Acceptance Criteria

### AC-1: 默认模型修改
- **Given**: 当前默认模型为 `Kwai-Kolors/Kolors`
- **When**: 修改 `utils/config.py` 中的配置
- **Then**: `DEFAULT_IMAGE_MODEL` 应等于 `Z-Image-Turbo`
- **Verification**: `programmatic`

### AC-2: 模型列表更新
- **Given**: 当前模型列表包含 `Kwai-Kolors/Kolors`
- **When**: 修改 `utils/config.py` 中的配置
- **Then**: `IMAGE_MODELS` 列表应包含 `Z-Image-Turbo`
- **Verification**: `programmatic`

### AC-3: 代码验证
- **Given**: 修改完成后
- **When**: 读取配置文件
- **Then**: 确认修改正确无误
- **Verification**: `human-judgment`

## Open Questions
- [ ] 确认 `Z-Image-Turbo` 模型在硅基流动平台的可用性
