# 修改文生图默认模型 - 验证检查清单

- [x] DEFAULT_IMAGE_MODEL 已修改为 `Z-Image-Turbo`
- [x] IMAGE_MODELS 列表包含 `Z-Image-Turbo`
- [x] 配置文件语法正确，无错误
- [x] 配置模块可正常导入
- [x] 检查是否有其他文件引用了旧模型名称 `Kwai-Kolors/Kolors`（已更新代码文件中的引用，日志文件保留历史记录）
