# 修改文生图默认模型 - 任务列表

## [x] Task 1: 修改 DEFAULT_IMAGE_MODEL 配置
- **Priority**: P0
- **Depends On**: None
- **Description**: 
  - 将 `utils/config.py` 中的 `DEFAULT_IMAGE_MODEL` 从 `Kwai-Kolors/Kolors` 修改为 `Z-Image-Turbo`
- **Acceptance Criteria Addressed**: AC-1
- **Test Requirements**:
  - `programmatic` TR-1.1: 读取配置文件确认 `DEFAULT_IMAGE_MODEL == 'Z-Image-Turbo'`
  - `human-judgement` TR-1.2: 检查代码修改是否正确

## [x] Task 2: 更新 IMAGE_MODELS 列表
- **Priority**: P0
- **Depends On**: Task 1
- **Description**: 
  - 将 `utils/config.py` 中的 `IMAGE_MODELS` 列表更新为包含 `Z-Image-Turbo`
- **Acceptance Criteria Addressed**: AC-2
- **Test Requirements**:
  - `programmatic` TR-2.1: 验证 `'Z-Image-Turbo' in IMAGE_MODELS`
  - `human-judgement` TR-2.2: 确认列表格式正确

## [x] Task 3: 代码验证
- **Priority**: P1
- **Depends On**: Task 2
- **Description**: 
  - 重新读取配置文件验证修改是否正确
  - 检查是否有其他文件引用了旧模型名称
- **Acceptance Criteria Addressed**: AC-3
- **Test Requirements**:
  - `programmatic` TR-3.1: 导入配置模块确认无语法错误
  - `human-judgement` TR-3.2: 确认所有修改正确无误

# Task Dependencies
- Task 2 depends on Task 1
- Task 3 depends on Task 2
