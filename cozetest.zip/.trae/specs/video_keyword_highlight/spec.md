# 视频关键词醒目展示功能 - 产品需求文档

## Overview
- **Summary**: 基于ASR语音识别和FFmpeg视频处理，实现视频中关键词的自动识别和醒目展示功能。系统从视频语音中提取核心关键词，在对应时间段以高亮字幕/特效形式展示。
- **Purpose**: 提升视频内容的信息传递效率，帮助观众快速抓住视频核心要点，增强观看体验。
- **Target Users**: 视频创作者、教育内容制作者、知识分享博主

## Goals
- 从视频语音中自动识别并提取核心关键词
- 精准定位关键词在视频中的时间戳位置
- 使用FFmpeg实现关键词的醒目视觉展示
- 支持多种视觉效果（高亮框、颜色变化、动画）
- 提供配置化的关键词展示样式

## Non-Goals (Out of Scope)
- 不支持手动标注关键词
- 不支持实时视频流处理
- 不提供视频播放器界面
- 不涉及视频上传/存储服务

## Background & Context
当前项目已有完整的视频生成工作流，包括TTS配音、字幕生成、图片生成等功能。本功能作为增强功能，旨在提升视频内容的信息密度和观看体验。

## Functional Requirements
- **FR-1**: 支持从音频文件进行ASR语音识别
- **FR-2**: 支持通过大模型提取核心关键词
- **FR-3**: 支持关键词与时间戳的精准对齐
- **FR-4**: 支持生成FFmpeg可执行的字幕/特效指令
- **FR-5**: 支持多种视觉效果（高亮框、颜色变化、缩放）
- **FR-6**: 支持配置关键词展示样式（字体、颜色、大小）

## Non-Functional Requirements
- **NFR-1**: ASR识别准确率 ≥ 95%（普通话标准发音）
- **NFR-2**: 时间戳精度 ≤ 0.5秒
- **NFR-3**: 单视频处理时间 ≤ 视频时长的2倍
- **NFR-4**: 支持批量处理多视频
- **NFR-5**: 错误处理友好，提供明确错误提示

## Constraints
- **Technical**: Python 3.8+, FFmpeg 4.0+, 需要网络连接调用ASR和大模型服务
- **Business**: ASR和大模型调用有API成本
- **Dependencies**: openai-whisper/pyannote-audio, ffmpeg-python, 大模型API

## Assumptions
- 输入视频包含清晰的人声语音
- 用户有可用的ASR服务或本地模型
- 用户环境已安装FFmpeg

## Acceptance Criteria

### AC-1: ASR语音识别
- **Given**: 输入一段包含语音的音频文件
- **When**: 调用ASR识别接口
- **Then**: 返回包含文本和时间戳的识别结果
- **Verification**: `programmatic`
- **Notes**: 时间戳精度需达到词级别

### AC-2: 关键词提取
- **Given**: ASR识别结果文本
- **When**: 调用大模型提取关键词
- **Then**: 返回Top-N核心关键词列表
- **Verification**: `programmatic`
- **Notes**: N可配置，默认5-10个

### AC-3: 时间戳对齐
- **Given**: ASR结果和关键词列表
- **When**: 执行时间戳对齐算法
- **Then**: 返回每个关键词对应的精确起止时间
- **Verification**: `programmatic`
- **Notes**: 支持模糊匹配处理

### AC-4: FFmpeg命令生成
- **Given**: 关键词时间戳数据和样式配置
- **When**: 调用命令生成函数
- **Then**: 输出可执行的FFmpeg命令或ASS字幕文件
- **Verification**: `programmatic`

### AC-5: 视频渲染
- **Given**: 原始视频和生成的字幕/特效文件
- **When**: 执行FFmpeg命令
- **Then**: 输出带有关键词醒目展示的视频
- **Verification**: `human-judgment`

### AC-6: 样式配置
- **Given**: 用户配置样式参数
- **When**: 生成关键词展示效果
- **Then**: 视频中的关键词按配置样式展示
- **Verification**: `human-judgment`

## Open Questions
- [ ] 选择哪种ASR方案（本地Whisper vs 云服务）
- [ ] 关键词密度阈值如何设置
- [ ] 是否需要支持用户自定义关键词
- [ ] 是否需要提供预览功能

## Glossary
- **ASR**: 自动语音识别 (Automatic Speech Recognition)
- **FFmpeg**: 开源视频处理工具
- **ASS**: Advanced SubStation Alpha，高级字幕格式
- **时间戳**: 音频/视频中某一时刻的时间标记