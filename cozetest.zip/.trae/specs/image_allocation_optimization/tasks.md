# 图片分配算法优化 - 实现计划

## [ ] Task 1: 分析当前图片分配算法
- **Priority**: P0
- **Depends On**: None
- **Description**: 
  - 分析当前图片分配算法的实现逻辑
  - 理解聚类信息的结构和使用方式
  - 确定需要修改的代码部分
- **Acceptance Criteria Addressed**: AC-1
- **Test Requirements**:
  - `programmatic` TR-1.1: 分析当前代码，确认图片分配逻辑
  - `programmatic` TR-1.2: 确认聚类信息的结构和传递方式
- **Notes**: 需要查看 generate_image_prompts 函数的返回值结构，以及 create_jianying_draft_with_pyJianYingDraft 函数中图片分配的代码

## [ ] Task 2: 修改图片分配算法
- **Priority**: P0
- **Depends On**: Task 1
- **Description**: 
  - 修改 create_jianying_draft_with_pyJianYingDraft 函数中的图片分配逻辑
  - 考虑聚类信息，使图片与对应的字幕内容匹配
  - 确保每张图片的时间范围与对应聚类的字幕时间范围一致
- **Acceptance Criteria Addressed**: AC-1, AC-2
- **Test Requirements**:
  - `programmatic` TR-2.1: 实现新的图片分配算法
  - `programmatic` TR-2.2: 确保图片时间范围与聚类时间范围一致
- **Notes**: 需要修改图片分配部分的代码，使用聚类信息来计算每个图片的时间范围

## [ ] Task 3: 测试优化后的算法
- **Priority**: P1
- **Depends On**: Task 2
- **Description**: 
  - 运行完整工作流，测试优化后的图片分配算法
  - 检查生成的剪映草稿中图片的时间分配
  - 验证图片是否与对应的字幕内容匹配
- **Acceptance Criteria Addressed**: AC-1, AC-2, AC-3
- **Test Requirements**:
  - `programmatic` TR-3.1: 运行完整工作流，确保系统正常运行
  - `programmatic` TR-3.2: 检查生成的草稿中图片的时间分配
  - `human-judgment` TR-3.3: 预览视频，确认图片与字幕内容匹配
- **Notes**: 需要运行完整工作流，生成剪映草稿并检查结果