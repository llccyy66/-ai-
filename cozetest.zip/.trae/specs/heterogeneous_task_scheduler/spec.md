# 异构任务调度系统 - Product Requirement Document

## Overview
- **Summary**: 开发一套异构任务调度系统，实现A类长耗时任务（带文生图）与B类短耗时任务（无文生图）的高效协同调度，最大化资源利用率
- **Purpose**: 解决当前系统中长耗时任务阻塞短耗时任务、资源闲置的问题，实现A类任务文生图阶段的IO阻塞窗口充分利用
- **Target Users**: 短视频批量生产系统用户，需要高效执行混合任务队列

## Goals
- 以A类长耗时任务为核心锚点，优先保障A类任务全链路执行顺畅
- 100%利用A类任务文生图阶段的IO阻塞窗口，填充B类短耗时任务执行
- 避免长耗时任务阻塞短耗时任务，避免两类任务的资源竞争
- 全程严格遵守强依赖规则，无任何执行顺序错误
- 最大化压榨TTS、ASR环节的资源利用率

## Non-Goals (Out of Scope)
- 不涉及视频渲染、导出等后续环节
- 不涉及前端界面开发
- 不修改现有工作流核心逻辑，仅添加调度层

## Background & Context
- 当前系统存在两类耗时特征差异极大的异构任务
- A类任务：带文生图环节，完整链路为【TTS→提示词生成→ASR→文生图】
- B类任务：无文生图环节，链路为【TTS→ASR】
- 文生图环节为长耗时IO阻塞操作，期间TTS/ASR资源闲置

## Functional Requirements
- **FR-1**: 实现一级大队列架构（A类任务专属队列、B类任务专属队列）
- **FR-2**: 实现二级子队列架构（TTS专属子队列、ASR专属子队列）
- **FR-3**: 实现强依赖规则校验（TTS完成后才能ASR，提示词完成后才能文生图）
- **FR-4**: 实现三级优先级调度（P0>A类前置 > P1>A类文生图 > P2>B类）
- **FR-5**: 实现A类任务文生图阶段触发B类任务调度
- **FR-6**: 实现动态水位填充优化
- **FR-7**: 实现预调度机制优化
- **FR-8**: 实现任务状态追踪（待调度、执行中、已完成、执行失败）
- **FR-9**: 实现异常处理（指数退避重试、失败队列）

## Non-Functional Requirements
- **NFR-1**: A类任务文生图阶段，TTS/ASR子队列资源利用率≥95%
- **NFR-2**: A类任务前置环节无被B类任务阻塞情况
- **NFR-3**: 任务失败后自动重试，不阻塞后续任务
- **NFR-4**: 系统支持监控埋点（耗时、成功率、队列空闲率）

## Constraints
- **Technical**: Python 3.8+, 使用asyncio实现异步调度
- **Dependencies**: 依赖现有工作流测试.py中的TTS、ASR、文生图接口

## Assumptions
- 任务环节执行时间可预测，历史数据可用于预调度
- 系统资源充足，可并行执行多个任务环节
- 工作流接口支持异步调用或可封装为异步

## Acceptance Criteria

### AC-1: 强依赖合规性
- **Given**: 系统执行任意任务
- **When**: 任务进入ASR子队列
- **Then**: 该任务的TTS环节已100%完成
- **Verification**: `programmatic`

### AC-2: 优先级合规性
- **Given**: A类任务前置环节与B类任务同时等待调度
- **When**: 子队列有空闲资源
- **Then**: A类任务前置环节优先执行
- **Verification**: `programmatic`

### AC-3: 资源利用率合规性
- **Given**: A类任务处于文生图阶段
- **When**: B类任务队列有待执行任务
- **Then**: TTS/ASR子队列无空闲状态
- **Verification**: `programmatic`

### AC-4: A类队列保活合规性
- **Given**: 当前A类任务执行完成
- **When**: A类队列有待执行任务
- **Then**: 下一个A类任务立即启动
- **Verification**: `programmatic`

### AC-5: 异常处理合规性
- **Given**: 任务执行失败
- **When**: 重试次数<3
- **Then**: 启动指数退避重试
- **Verification**: `programmatic`

### AC-6: 启动规则合规性
- **Given**: 系统启动，A类队列有待执行任务
- **When**: 开始调度
- **Then**: 首个执行任务为A类任务
- **Verification**: `programmatic`

## Open Questions
- [ ] 文生图执行阶段的具体判定标准需要确认
- [ ] 子队列最大并发数配置需要确认
