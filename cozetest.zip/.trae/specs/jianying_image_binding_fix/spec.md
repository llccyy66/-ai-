# 剪映草稿图片绑定与字幕同步修复 - 产品需求文档

## Overview
- **Summary**: 修复剪映草稿生成时图片绑定错位和字幕缺失问题，确保所有图片和字幕都能正确添加到时间线上，并提供完整的终端日志输出供调试验证。
- **Purpose**: 解决当前生成的草稿中只有第一张图片和第一句字幕被添加到时间线的问题，确保图片按时间戳正确绑定到音频轨道，字幕与音频同步。
- **Target Users**: 需要使用工作流生成完整剪映草稿的用户。

## Why Now
- 用户运行工作流后发现生成的草稿存在问题：
  - 只有 IMG_001.jpg 成功添加到轨道，02～08 的图片都没有正常导入
  - 字幕也没有完整添加，只有 "你是不是总觉得钱不够花？" 这一句出现在时间线上
  - 用户推测是因为图片没有按时间戳绑定到音频上，导致后续字幕无法关联
- 需要通过终端日志完整展示草稿内容，无需手动打开草稿即可核对

## What Changes
- **图片时间戳绑定修复**：确保所有图片按照音频字幕对的时间范围正确分配到视频轨道
- **字幕完整性修复**：确保所有字幕都被正确添加到字幕轨道
- **终端日志增强**：添加详细的终端日志输出，展示草稿内的所有内容（音频、图片、字幕、时间线信息）
- **数据验证增强**：添加数据完整性验证，确保 audio_list、image_list、script_list 三者正确对应

## Impact
- Affected specs: `draft_fix`（当前spec继承自draft_fix的基础草稿生成能力）
- Affected code:
  - `c:\Users\18622\Documents\trae_projects\cozetest\工作流测试.py` 中的 `create_jianying_draft_with_pyJianYingDraft` 函数
  - 图片分配逻辑和字幕同步逻辑

## ADDED Requirements

### Requirement: 图片时间戳绑定
系统 SHALL 确保每张图片都按照时间戳正确添加到视频轨道。

#### Scenario: 正常情况
- **WHEN** 有多张图片和对应的字幕/音频片段
- **THEN** 每张图片都应该根据其对应的字幕时间范围被添加到视频轨道的正确位置
- **Example**: 图片IMG_002.jpg应被添加到第二段字幕对应的时间范围内

### Requirement: 字幕完整性
系统 SHALL 确保所有字幕都被添加到字幕轨道。

#### Scenario: 正常情况
- **WHEN** 有N条字幕文本
- **THEN** N条字幕都应该被添加到字幕轨道，每个字幕对应正确的时间范围
- **Example**: 如果有6段音频/字幕对，应该有6条字幕在字幕轨道上

### Requirement: 终端日志完整输出
系统 SHALL 通过终端日志输出完整的草稿内容供调试验证。

#### Scenario: 草稿生成完成
- **WHEN** 草稿生成完成
- **THEN** 终端应该输出：
  - 音频片段数量和每个片段的时长、开始时间
  - 字幕数量和每条字幕的内容、时间范围
  - 图片数量和每张图片的时间范围、对应字幕索引
  - 草稿总时长
- **Example**: 终端输出应包含 "音频片段: 6个, 总时长: XX秒"、"字幕: 6条"、"图片: 8张" 等信息

## MODIFIED Requirements

### Requirement: 数据完整性验证
原有的数据完整性验证 SHALL 增加以下检查：
- 验证 audio_list 和 script_list 长度一致
- 验证 image_list 中的每张图片都有对应的字幕索引或时间范围
- 当数据不一致时，记录警告但继续处理而不是抛出异常

## REMOVED Requirements
- 无

## Acceptance Criteria

### AC-1: 图片完整添加
- **Given**: 工作流正常运行，生成了8张图片
- **When**: 草稿生成完成
- **Then**: 8张图片都应该被添加到视频轨道，每个都有正确的时间范围
- **Verification**: `programmatic` - 检查终端日志输出

### AC-2: 字幕完整添加
- **Given**: 工作流生成了6段音频/字幕
- **When**: 草稿生成完成
- **Then**: 6条字幕都应该被添加到字幕轨道
- **Verification**: `programmatic` - 检查终端日志输出

### AC-3: 终端日志完整
- **Given**: 草稿生成完成
- **When**: 检查终端日志
- **Then**: 日志应包含所有素材的详细信息，包括音频、字幕、图片的数量和时间范围
- **Verification**: `programmatic` - 检查终端日志内容

### AC-4: 连续运行成功
- **Given**: 修复后的代码
- **When**: 连续运行两次工作流
- **Then**: 两次运行都应该成功完成草稿生成，无报错
- **Verification**: `programmatic` - 两次运行都无异常

## Open Questions
- [x] 图片时间范围如何计算？答：根据对应字幕的起始时间和结束时间
- [x] 如果图片数量与字幕数量不一致如何处理？答：按顺序分配，多余的图片或字幕部分留空
- [x] 如何确保日志输出完整？答：在关键步骤添加详细的logger.info输出

## Constraints
- **Technical**: 使用 pyJianYingDraft 库生成剪映草稿
- **Dependencies**: 依赖 pyJianYingDraft 库及其依赖项
- **Validation**: 必须通过终端日志验证，无需手动打开草稿

## Assumptions
- pyJianYingDraft 库已经正确安装
- 素材文件（图片、音频）已经正确生成
- 音频和字幕已经通过 Qwen3-ForcedAligner 正确对齐
