# 草稿文件命名规则规范

## Overview
- **Summary**: 修改草稿文件命名规则，使D盘和任务目录下的草稿文件夹名称与任务目录名称保持一致
- **Purpose**: 方便用户识别和管理草稿文件，确保两个位置的草稿名称统一
- **Target Users**: 使用批量任务处理的用户

## Goals
- D盘和任务目录下的草稿文件夹名称相同
- 草稿文件夹名称 = 任务目录名称（如：2026年存款利率下调的3个核心影响_1778054788）
- 保持原有功能不变

## Non-Goals (Out of Scope)
- 不改变草稿内容结构
- 不影响其他工作流步骤

## Background & Context
- 当前草稿命名：draft_{时间戳}
- 用户希望：草稿名称与任务目录名称一致
- D盘路径：D:\JianyingPro Drafts\{任务目录名}
- 任务目录路径：output\{任务目录名}\{任务目录名}

## Functional Requirements
- **FR-1**: 草稿文件夹名称 = 任务目录名称
- **FR-2**: D盘和任务目录下的草稿名称完全相同
- **FR-3**: 支持配置开关控制是否启用此命名规则

## Non-Functional Requirements
- **NFR-1**: 修改不影响现有工作流
- **NFR-2**: 兼容已有代码逻辑

## Constraints
- **Technical**: 需要修改草稿生成逻辑
- **Dependencies**: 依赖项目目录名称

## Assumptions
- 任务目录名称格式为：{主题}_{时间戳}

## Acceptance Criteria

### AC-1: 草稿命名与任务目录一致
- **Given**: 任务目录名为 "2026年存款利率下调的3个核心影响_1778054788"
- **When**: 生成草稿
- **Then**: D盘和任务目录下的草稿文件夹都命名为 "2026年存款利率下调的3个核心影响_1778054788"
- **Verification**: `programmatic`

### AC-2: 配置开关控制
- **Given**: 配置文件中设置了命名规则开关
- **When**: 修改开关状态
- **Then**: 对应启用或禁用此命名规则
- **Verification**: `programmatic`

## Open Questions
- [ ] 是否需要保留原有的 draft_xxx 命名方式作为选项

---

# tasks.md

# 草稿命名规则修改 - 实施计划

## [ ] Task 1: 在配置文件中添加命名规则配置
- **Priority**: P0
- **Depends On**: None
- **Description**: 
  - 在 config.yaml 的 draft_save 配置中添加 naming_rule 配置项
- **Acceptance Criteria Addressed**: AC-2
- **Test Requirements**:
  - `programmatic`: 配置文件能正确读取该配置项
- **Notes**: 默认使用任务目录名称作为草稿名称

## [ ] Task 2: 修改草稿生成逻辑
- **Priority**: P0
- **Depends On**: Task 1
- **Description**: 
  - 修改 create_jianying_draft_v2 函数，使用任务目录名称作为草稿名称
  - 确保D盘和任务目录下的草稿名称一致
- **Acceptance Criteria Addressed**: AC-1
- **Test Requirements**:
  - `programmatic`: D盘和任务目录下的草稿名称相同
  - `programmatic`: 草稿名称与任务目录名称一致
- **Notes**: 

## [ ] Task 3: 测试验证
- **Priority**: P1
- **Depends On**: Task 2
- **Description**: 
  - 运行A类任务测试
  - 验证D盘和任务目录下的草稿名称
- **Acceptance Criteria Addressed**: AC-1
- **Test Requirements**:
  - `programmatic`: 检查两个位置的草稿名称是否相同且等于任务目录名称
- **Notes**: 

---

# checklist.md

- [ ] 配置文件中添加了 naming_rule 配置项
- [ ] 草稿生成逻辑使用任务目录名称作为草稿名称
- [ ] D盘和任务目录下的草稿名称相同
- [ ] 草稿名称与任务目录名称一致
- [ ] 测试验证通过