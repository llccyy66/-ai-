# 图片生成优化 - 任务列表

## [ ] Task 1: 优化 generate_image 函数的API限流处理
  - **Priority**: P0
  - **Depends On**: None
  - **Description**: 
    - 增加智能API限流处理，解析Retry-After头
    - 实现更智能的指数退避策略
    - 增加最大重试次数
    - 优化错误处理，提供更详细的错误信息
  - **Acceptance Criteria Addressed**: [智能API限流处理]
  - **Test Requirements**:
    - `programmatic` TR-1.1: 当遇到API限流时，能正确解析Retry-After并等待
    - `programmatic` TR-1.2: 指数退避策略能有效避免持续限流
  - **Notes**: 重点关注429错误的处理

## [ ] Task 2: 优化 batch_generate_images 函数的并发控制
  - **Priority**: P0
  - **Depends On**: Task 1
  - **Description**:
    - 将max_workers从3减少到2
    - 实现请求队列，避免同时发送过多请求
    - 增加进度显示，实时显示生成进度
  - **Acceptance Criteria Addressed**: [并发控制, 进度监控]
  - **Test Requirements**:
    - `programmatic` TR-2.1: 并发数不超过2
    - `programmatic` TR-2.2: 批量生成21张图片时无API限流
  - **Notes**: 控制并发是解决API限流的关键

## [ ] Task 3: 增加图片生成失败的降级策略
  - **Priority**: P0
  - **Depends On**: Task 1, Task 2
  - **Description**:
    - 当图片生成失败时，使用简化的备用提示词
    - 当所有重试都失败时，使用相关主题的缓存图片
    - 增加失败时的详细错误信息
  - **Acceptance Criteria Addressed**: [图片生成失败降级]
  - **Test Requirements**:
    - `programmatic` TR-3.1: 图片生成失败时能使用备用提示词
    - `programmatic` TR-3.2: 备用提示词生成失败时能使用缓存图片
  - **Notes**: 确保即使API限流严重，也能生成足够的图片

## [ ] Task 4: 优化 generate_semantic_image_prompts 函数的超时控制
  - **Priority**: P1
  - **Depends On**: None
  - **Description**:
    - 为generate_semantic_image_prompts设置300秒超时
    - 超时后使用备用语义群生成策略
    - 增加超时预警机制
  - **Acceptance Criteria Addressed**: [LLM超时控制]
  - **Test Requirements**:
    - `programmatic` TR-4.1: LLM生成超时后能使用备用策略
    - `programmatic` TR-4.2: 备用策略能生成足够的语义群
  - **Notes**: 避免LLM生成时间过长影响整体流程

## [ ] Task 5: 集成测试与验证
  - **Priority**: P1
  - **Depends On**: Task 1, Task 2, Task 3, Task 4
  - **Description**:
    - 运行完整工作流，验证图片生成成功率
    - 验证21张图片全部生成成功
    - 验证LLM生成时间在合理范围内
  - **Acceptance Criteria Addressed**: [智能API限流处理, 并发控制, 图片生成失败降级, LLM超时控制, 进度监控]
  - **Test Requirements**:
    - `programmatic` TR-5.1: 21张图片全部生成成功
    - `programmatic` TR-5.2: LLM生成时间不超过300秒
  - **Notes**: 确保优化后的流程稳定可靠
