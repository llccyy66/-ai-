# 图片生成优化与错误处理 Spec

## Why
21张图片中只有8张成功生成，其余13张因API限流失败。同时LLM生成21个语义群耗时535秒，存在超时风险。需要优化图片生成的错误处理、并行控制和降级策略。

## What Changes
- 优化 `generate_image` 函数：增加更智能的API限流处理，动态调整重试策略
- 优化 `batch_generate_images` 函数：控制并发数，避免同时请求导致限流
- 增加图片生成失败的降级策略：当图片生成失败时，使用备用提示词或缓存图片
- 优化 `generate_semantic_image_prompts` 函数：增加超时控制，避免LLM生成时间过长
- 增加图片生成进度监控和预警机制

## Impact
- Affected specs: 视频处理测试验证, 图片重复问题修复, 字幕乱码根因修复
- Affected code: 工作流测试.py (generate_image, batch_generate_images, generate_semantic_image_prompts)

## ADDED Requirements

### Requirement: 智能API限流处理
系统 SHALL 实现智能的API限流处理，根据限流响应动态调整重试间隔和策略。

#### Scenario: API限流时的处理
- **WHEN** 遇到API限流（429错误）
- **THEN** 系统应根据响应头中的Retry-After或使用指数退避策略，避免立即重试导致更严重的限流

### Requirement: 并发控制
系统 SHALL 控制图片生成的并发数，避免同时发送过多请求导致API限流。

#### Scenario: 批量生成21张图片
- **WHEN** 批量生成21张图片
- **THEN** 系统应控制并发数不超过2，避免触发API限流

### Requirement: 图片生成失败降级
系统 SHALL 实现图片生成失败的降级策略，当图片生成失败时，使用备用提示词或缓存图片。

#### Scenario: 图片生成失败
- **WHEN** 图片生成失败
- **THEN** 系统应尝试使用简化的备用提示词重新生成，或使用相关主题的缓存图片

### Requirement: LLM超时控制
系统 SHALL 为 `generate_semantic_image_prompts` 函数增加超时控制，避免LLM生成时间过长。

#### Scenario: LLM生成21个语义群
- **WHEN** LLM生成21个语义群
- **THEN** 系统应设置合理的超时时间（如300秒），超时后使用备用策略

### Requirement: 进度监控
系统 SHALL 增加图片生成的进度监控和预警机制，实时显示生成进度和失败情况。

#### Scenario: 批量生成图片
- **WHEN** 批量生成图片
- **THEN** 系统应实时显示生成进度，失败时提供详细的错误信息和建议

## MODIFIED Requirements

### Requirement: 图片生成函数
修改 `generate_image` 函数，增加智能API限流处理和更健壮的错误处理。

### Requirement: 批量图片生成函数
修改 `batch_generate_images` 函数，控制并发数，增加降级策略。

### Requirement: 语义群提示词生成函数
修改 `generate_semantic_image_prompts` 函数，增加超时控制。

## REMOVED Requirements
(None)

## 根因分析

### 问题1：API限流导致图片生成失败
- **现象**：21张图片中13张失败，错误信息为"图像生成返回None"
- **根因**：并发请求过多（3个线程同时请求），触发硅基流动API限流
- **机制**：`batch_generate_images` 使用ThreadPoolExecutor(max_workers=3)同时发送3个请求，超过API的并发限制

### 问题2：LLM生成时间过长
- **现象**：生成21个语义群耗时535秒（约9分钟）
- **根因**：LLM需要生成大量语义群，处理时间长，可能导致后续步骤超时

### 问题3：缺少降级策略
- **现象**：图片生成失败后没有备用方案
- **根因**：当API限流时，简单的指数退避重试可能不足以解决问题

## 修复方案

1. **优化API限流处理**：
   - 解析API响应中的Retry-After头
   - 使用更智能的指数退避策略
   - 增加最大重试次数

2. **控制并发数**：
   - 将 `max_workers` 从3减少到2
   - 实现请求队列，避免同时发送过多请求

3. **增加降级策略**：
   - 当图片生成失败时，使用简化的备用提示词
   - 当所有重试都失败时，使用相关主题的缓存图片

4. **增加超时控制**：
   - 为 `generate_semantic_image_prompts` 设置300秒超时
   - 超时后使用备用语义群生成策略

5. **增加进度监控**：
   - 实时显示图片生成进度
   - 失败时提供详细的错误信息和建议
