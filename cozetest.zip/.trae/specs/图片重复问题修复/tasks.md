# Tasks

- [x] Task 1: 修改语义群提示词生成逻辑，确保提示词数量与图片数量一致
  - [x] SubTask 1.1: 修改 generate_semantic_image_prompts 函数，增加 num_images 参数，在系统提示中要求LLM生成指定数量的语义群
  - [x] SubTask 1.2: 修改 segmented_workflow 中的调用，传入 num_images 参数
  - [x] SubTask 1.3: 测试验证提示词数量与图片数量一致

- [x] Task 2: 修改提示词分配逻辑，确保每个提示词唯一
  - [x] SubTask 2.1: 在 segmented_workflow 中，为每个提示词添加序号或变体描述，确保唯一性
  - [x] SubTask 2.2: 移除循环使用提示词的逻辑（`i % len(semantic_prompts)`）
  - [x] SubTask 2.3: 测试验证每个提示词都是唯一的

- [x] Task 3: 增加图片重复自检机制
  - [x] SubTask 3.1: 在 validate_draft 中增加提示词数量校验：提示词数量必须等于图片数量
  - [x] SubTask 3.2: 在 validate_draft 中增加图片文件hash校验：检测是否有重复的图片文件
  - [x] SubTask 3.3: 在 validate_draft 中增加文件大小规律性检测：检测是否有规律性重复的文件大小
  - [x] SubTask 3.4: 在终端输出中标注重复图片（红色警告）
  - [x] SubTask 3.5: 测试验证自检机制能正确检测图片重复

- [x] Task 4: 集成测试与验证
  - [x] SubTask 4.1: 运行完整工作流，验证图片无重复
  - [x] SubTask 4.2: 验证自检程序能正确检测重复
  - [x] SubTask 4.3: 连续两次运行验证稳定性

# Task Dependencies
- Task 2 depends on Task 1
- Task 3 depends on Task 1
- Task 4 depends on Task 1, Task 2, Task 3
