# 图片重复问题修复 Spec

## Why
24张图片中只有5个不同的提示词（由语义群生成），导致图片按5张一组循环重复。核心问题是：语义群数量（5个）远少于图片数量（24张），提示词被循环复用，相同提示词生成相同图片（通过缓存hash命中）。

## What Changes
- 修改 `generate_semantic_image_prompts` 函数，使语义群数量与图片数量一致
- 修改 `segmented_workflow` 中的提示词分配逻辑，确保每张图片有独立提示词
- 增加图片重复自检机制：提示词数量校验、图片文件hash校验、文件大小规律性检测
- **BREAKING**: 语义群数量不再由LLM自由决定，而是根据图片数量强制要求

## Impact
- Affected specs: 视频处理测试验证, 字幕乱码根因修复
- Affected code: 工作流测试.py (generate_semantic_image_prompts, segmented_workflow, validate_draft, build_binding_data)

## ADDED Requirements

### Requirement: 提示词数量与图片数量一致
系统 SHALL 确保生成的提示词数量与所需图片数量一致。如果需要24张图片，则必须生成24个不同的提示词。

#### Scenario: 24张图片需要24个提示词
- **WHEN** 视频总时长116秒，需要24张图片（每5秒一张）
- **THEN** 系统生成24个不同的提示词，每张图片使用独立提示词

### Requirement: 图片重复自检
系统 SHALL 在自检阶段检测图片是否重复，包括：提示词数量校验、图片文件hash校验、文件大小规律性检测。

#### Scenario: 检测到图片重复
- **WHEN** 自检程序检查生成的图片
- **THEN** 能检测到重复图片并报告错误

### Requirement: 提示词唯一性保证
系统 SHALL 确保每个提示词都是唯一的，避免因提示词重复导致图片缓存命中。

#### Scenario: 提示词重复
- **WHEN** 两个提示词完全相同
- **THEN** 系统检测到重复并为重复提示词添加序号或变体描述

## MODIFIED Requirements

### Requirement: 语义群提示词生成
修改 `generate_semantic_image_prompts` 函数，增加 `num_images` 参数，要求LLM生成指定数量的语义群和提示词。

## REMOVED Requirements
(None)

## 根因分析

### 问题数据流
```
generate_semantic_image_prompts(full_text) → 5个语义群（5个提示词）
    ↓
segmented_workflow: num_images = 24
    ↓
prompt_list = [semantic_prompts[i % 5] for i in range(24)]
    → 提示词按5个一组循环：[0,1,2,3,4, 0,1,2,3,4, 0,1,2,3,4, 0,1,2,3,4, 0,1,2,3,4]
    ↓
batch_generate_images: 相同提示词 → hash命中缓存 → 返回相同图片
    → 5个不同的图片文件被循环使用24次
```

### 缓存机制导致重复
`generate_image` 函数使用提示词的hash作为缓存key。相同提示词会命中缓存，直接返回已缓存的图片文件，不会重新生成。因此5个提示词只生成5张不同的图片。

### 修复方案
1. 修改 `generate_semantic_image_prompts`，传入 `num_images` 参数，要求LLM生成与图片数量一致的语义群
2. 在提示词分配时，确保每个提示词唯一（添加序号或变体描述）
3. 增加自检机制：提示词数量校验、图片hash校验、文件大小规律性检测
