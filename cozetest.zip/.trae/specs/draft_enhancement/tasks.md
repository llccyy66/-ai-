# Tasks

- [x] Task 1: 创建提示词配置文件体系
  - [x] 1.1 创建 prompts/ 目录
  - [x] 1.2 创建 prompts/script_generation.json（文案生成提示词）
  - [x] 1.3 创建 prompts/image_generation.json（文生图提示词，含纯白背景+火柴人风格）
  - [x] 1.4 创建 prompts/tts_config.json（配音效果配置）
  - [x] 1.5 创建 prompts/loader.py（配置文件加载器，支持自动同步）

- [x] Task 2: 修改文生图提示词为火柴人黑白线条画风格
  - [x] 2.1 更新 generate_image_prompts() 中的系统提示词，使用配置文件
  - [x] 2.2 强制纯白背景(#ffffff)为最高优先级
  - [x] 2.3 限定火柴人风格：圆形头部+不超过5根线条+清晰表情
  - [x] 2.4 严格仅使用纯黑色(#000000)和纯白色(#ffffff)

- [x] Task 3: 修复音频重复引用bug
  - [x] 3.1 检查 create_jianying_draft_with_pyJianYingDraft() 中音频添加逻辑
  - [x] 3.2 确保每个音频文件路径在时间线中唯一
  - [x] 3.3 添加音频去重检查逻辑

- [x] Task 4: 图片时间轴按聚类字幕时间分配
  - [x] 4.1 修改草稿生成函数，记录每个音频片段的开始和结束时间
  - [x] 4.2 根据聚类的 subtitle_indices 计算每个图片的时间范围
  - [x] 4.3 用聚类时间范围替代平均分配

- [x] Task 5: 实现图片数量智能计算
  - [x] 5.1 添加 calculate_image_count() 函数
  - [x] 5.2 基于视频总时长和单张显示时长计算图片数量
  - [x] 5.3 在 generate_image_prompts() 中使用计算出的图片数量
  - [ ] 5.4 在 GUI 参数设置中添加"图片显示时长"滑块（5-10秒）

- [x] Task 6: 实现视频结构规范
  - [x] 6.1 设置草稿整体背景为纯白色(#ffffff)
  - [x] 6.2 左上角添加"财富认知"文字（黑体24px黑色）
  - [ ] 6.3 右上角添加用户名文字（黑体18px黑色）
  - [x] 6.4 底部20%区域添加字幕（微软雅黑20px黑色，单行居中）
  - [x] 6.5 中间区域图片16:9比例居中
  - [x] 6.6 图片添加淡入(0.5s)+淡出(0.5s)动画

- [x] Task 7: 背景模板自定义功能
  - [x] 7.1 创建 modules/background_template.py
  - [x] 7.2 实现模板选择、预览、保存功能
  - [x] 7.3 在GUI中添加背景模板入口
  - [x] 7.4 确保与现有视频生成流程兼容

- [x] Task 8: 集成测试与验证
  - [x] 8.1 运行完整工作流，验证无ERROR日志
  - [x] 8.2 验证音频无重复引用
  - [x] 8.3 验证图片时间轴与聚类对应
  - [x] 8.4 验证视频结构规范正确
  - [x] 8.5 验证提示词配置文件可正确加载和修改
  - [x] 8.6 修复TTS SSL错误：添加重试机制（3次重试+指数退避）
  - [x] 8.7 修复audio_list None值处理：草稿生成时跳过失败项+main()中重试失败配音
  - [x] 8.8 修复图片SegmentOverlap：添加last_image_end防重叠逻辑
  - [x] 8.9 修复背景音乐SegmentOverlap：添加独立"背景音乐"音轨
  - [x] 8.10 修复不连续subtitle_indices：截断为连续索引段
  - [x] 8.11 修复图片提示词JSON解析失败：添加3次重试机制
  - [x] 8.12 替换pydub为mutagen检查背景音乐时长
  - [x] 8.13 两次验证运行均无ERROR日志

# Task Dependencies
- [Task 1] 必须在 [Task 2] 之前完成
- [Task 2] 依赖 [Task 1]
- [Task 3] 和 [Task 4] 可以并行执行
- [Task 5] 依赖 [Task 4]（需要知道时间分配方式）
- [Task 6] 依赖 [Task 4]（图片时间轴确定后才能添加动画）
- [Task 7] 可以与 [Task 3-6] 并行执行
- [Task 8] 必须在所有其他任务完成后执行
