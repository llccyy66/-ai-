# 草稿文件双位置保存功能 - 产品需求文档

## Overview
- **Summary**: 修改草稿生成逻辑，让剪映草稿文件同时保存到D盘默认位置和任务目录下
- **Purpose**: 确保草稿文件的双重备份，方便用户在任务目录中直接查看和管理草稿
- **Target Users**: 使用批量任务处理的用户

## Goals
- 草稿文件同时保存到 D:\JianyingPro Drafts 和任务目录
- 保持原有功能不变，仅增加备份功能
- 支持配置开关控制是否启用双位置保存

## Non-Goals (Out of Scope)
- 不改变现有草稿生成逻辑
- 不修改剪映草稿格式
- 不影响其他工作流步骤

## Background & Context
- 当前草稿仅保存到 D:\JianyingPro Drafts
- 用户希望在任务目录中也能找到草稿文件
- 任务目录结构：output/{任务名称}_{时间戳}/

## Functional Requirements
- **FR-1**: 草稿生成后自动复制一份到任务目录
- **FR-2**: 任务目录中保持相同的草稿文件夹结构
- **FR-3**: 支持通过配置文件控制是否启用此功能

## Non-Functional Requirements
- **NFR-1**: 复制操作不影响原有的草稿生成流程
- **NFR-2**: 如果复制失败，不影响主流程

## Constraints
- **Technical**: 需要处理目录创建、文件复制等操作
- **Dependencies**: 依赖 shutil 库进行文件复制

## Assumptions
- D盘存在且有写入权限
- 任务目录已创建

## Acceptance Criteria

### AC-1: 草稿双位置保存
- **Given**: 工作流执行完成，草稿生成成功
- **When**: 启用双位置保存功能
- **Then**: 草稿文件同时出现在 D:\JianyingPro Drafts 和任务目录下
- **Verification**: `programmatic`

### AC-2: 配置开关控制
- **Given**: 配置文件中设置了双位置保存开关
- **When**: 修改开关状态
- **Then**: 对应启用或禁用双位置保存功能
- **Verification**: `programmatic`

### AC-3: 复制失败不影响主流程
- **Given**: 任务目录不可写或其他原因导致复制失败
- **When**: 草稿生成完成后尝试复制
- **Then**: 主流程继续正常执行，仅记录警告日志
- **Verification**: `programmatic`

## Open Questions
- [ ] 是否需要在配置文件中添加开关

---

# tasks.md

# 草稿双位置保存 - 实施计划

## [ ] Task 1: 在配置文件中添加双位置保存开关
- **Priority**: P0
- **Depends On**: None
- **Description**: 
  - 在 config.yaml 中添加 `draft_backup.enabled` 配置项
- **Acceptance Criteria Addressed**: AC-2
- **Test Requirements**:
  - `programmatic`: 配置文件能正确读取该配置项
- **Notes**: 默认启用

## [ ] Task 2: 修改配置加载器
- **Priority**: P0
- **Depends On**: Task 1
- **Description**: 
  - 在 config_loader.py 中添加获取草稿备份配置的函数
- **Acceptance Criteria Addressed**: AC-2
- **Test Requirements**:
  - `programmatic`: 能正确返回配置值
- **Notes**: 

## [ ] Task 3: 修改草稿生成逻辑
- **Priority**: P0
- **Depends On**: Task 2
- **Description**: 
  - 在 create_jianying_draft_v2 函数中添加复制逻辑
  - 使用 shutil.copytree 复制草稿文件夹
  - 添加错误处理
- **Acceptance Criteria Addressed**: AC-1, AC-3
- **Test Requirements**:
  - `programmatic`: 草稿文件同时出现在两个位置
  - `programmatic`: 复制失败时不影响主流程
- **Notes**: 

## [ ] Task 4: 测试验证
- **Priority**: P1
- **Depends On**: Task 3
- **Description**: 
  - 运行A类任务测试
  - 验证草稿文件存在于两个位置
- **Acceptance Criteria Addressed**: AC-1
- **Test Requirements**:
  - `programmatic`: 检查两个位置的文件是否存在
- **Notes**: 

---

# checklist.md

- [ ] 配置文件中添加了 draft_backup.enabled 配置项
- [ ] config_loader.py 添加了获取配置的函数
- [ ] 草稿生成逻辑中添加了复制代码
- [ ] 复制失败时有错误处理和日志记录
- [ ] 测试验证草稿文件存在于两个位置
- [ ] 复制失败不影响主流程