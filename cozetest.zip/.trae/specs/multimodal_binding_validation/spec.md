# 多模态绑定自检与免剪映验证 Spec

## Why
当前工作流生成的剪映草稿无法在不打开剪映的情况下验证文字、图片、配音三者的绑定正确性。存在标题文字时长硬编码为300秒、文件命名无绑定关联、缺少自检报告等问题，需要构建完整的自检体系实现可量化、可验证、可追溯。

## What Changes
- **BREAKING**: 标题文字时长从硬编码300秒改为动态匹配配音总时长
- 新增统一绑定ID机制，为每组"字幕+配音+图片"分配全局唯一ID
- 新增标准化文件命名规则（TTS_/IMG_/SUB_前缀+绑定ID+时长）
- 新增自检报告模块，自动校验绑定ID一致性、时长匹配、字幕同步、配音重复
- 新增配音重复检测算法（基于文本内容比对+音频时长异常检测）
- 修改图片生成提示词为标准化正面/负面提示词格式
- 修改图片生成固定参数（Seed/Steps/Guidance Scale）
- 新增日志本地持久化路径明确标识
- 新增完整工程文档生成功能

## Impact
- Affected specs: draft_enhancement (标题时长修改、文件命名修改)
- Affected code: 工作流测试.py (核心流程重构), utils/config.py (新增配置), prompts/image_generation.json (提示词标准化)

## ADDED Requirements

### Requirement: 统一绑定ID机制
系统 SHALL 为每一组"字幕内容+对应配音+对应图片"分配全局唯一绑定ID（格式：`B{timestamp}_{index}`），三者强制携带相同ID。

#### Scenario: 绑定ID生成与传递
- **WHEN** 工作流生成字幕列表后
- **THEN** 为每条字幕分配绑定ID，配音文件和图片文件均携带该ID
- **AND** 文件命名遵循规则：`TTS_{绑定ID}_{时长ms}.mp3`、`IMG_{绑定ID}_{段落序号}.jpg`

### Requirement: 标题文字动态时长
系统 SHALL 将标题文字（"财富认知"）的显示时长从硬编码300秒改为动态匹配配音总时长，误差≤0.1秒。

#### Scenario: 标题时长动态适配
- **WHEN** 所有配音片段添加完成后，总时长为T
- **THEN** 标题文字的trange为`("0s", f"{T}s")`
- **AND** 标题时长与配音总时长差值≤0.1秒

### Requirement: 配音重复检测
系统 SHALL 在配音生成后自动检测是否存在重复朗读，通过文本内容比对和音频时长异常检测实现。

#### Scenario: 配音重复检测
- **WHEN** 批量配音生成完成
- **THEN** 系统自动比对相邻音频的文本内容，检测是否存在完全相同的字幕文本
- **AND** 检测相邻音频时长是否异常接近（差值<0.1秒且文本相同视为重复）
- **AND** 重复检测结果记录到自检报告

### Requirement: 字幕时间轴自检
系统 SHALL 自动校验字幕文本与语音文本一致性，校验时间戳误差≤0.5秒。

#### Scenario: 字幕同步自检
- **WHEN** 草稿生成完成
- **THEN** 系统逐句校验字幕文本与原始字幕列表完全匹配（100%）
- **AND** 逐句校验字幕显示时长与对应音频时长差值≤0.5秒
- **AND** 校验字幕总时长与音频总时长差值≤0.5秒

### Requirement: 音频时长与文字模块时长校验
系统 SHALL 读取配音文件实际时长T1，与文字模块配置时长T2比对，差值Δ=|T1-T2|≤0.1秒。

#### Scenario: 时长匹配校验
- **WHEN** 草稿生成完成
- **THEN** 系统使用mutagen读取所有音频文件实际时长
- **AND** 计算音频总时长与标题文字时长差值
- **AND** 差值>0.1秒时在自检报告中标记为失败

### Requirement: 自检结论报告
系统 SHALL 在每次工作流完成后自动生成自检报告，包含绑定ID一致性、配音重复检测、字幕同步误差、时长匹配、图片语义绑定准确率。

#### Scenario: 自检报告生成
- **WHEN** 工作流执行完成
- **THEN** 系统自动生成JSON格式自检报告，保存至项目目录
- **AND** 报告包含：binding_id_check、voice_duplication_check、subtitle_sync_check、duration_match_check、image_binding_check
- **AND** 所有检查项通过时报告status为PASS，任一失败为FAIL
- **AND** 报告路径记录到日志

### Requirement: 图片生成提示词标准化
系统 SHALL 强制使用标准化正面/负面提示词格式生成图片，正面提示词包含【场景】【风格】【配色】【禁止】四段，负面提示词固定。

#### Scenario: 标准化提示词生成
- **WHEN** 调用图片生成API
- **THEN** 正面提示词严格遵循：场景描述+风格描述+配色描述+禁止描述
- **AND** 负面提示词固定为：色彩、照片写实风格、3D渲染、真实质感、渐变效果等
- **AND** 图片生成固定参数：Seed=4793688095, Steps=50, Guidance Scale=5.8

### Requirement: 日志本地持久化
系统 SHALL 将运行期间产生的所有日志文件存放至本地 `logs/` 目录，日志路径明确告知用户。

#### Scenario: 日志存储
- **WHEN** 工作流运行
- **THEN** 日志文件保存至 `c:\Users\18622\Documents\trae_projects\cozetest\logs\app.log`
- **AND** 自检报告保存至对应项目目录下的 `validation_report.json`
- **AND** 工作流完成时在终端输出日志路径和报告路径

### Requirement: 工程文档生成
系统 SHALL 在所有检查点通过后，自动生成完整工程文档，包含工程结构、流程细节、实现方案、算法细节。

#### Scenario: 工程文档生成
- **WHEN** 两次验证运行均无错误
- **THEN** 系统在项目根目录生成 `工程文档.md`
- **AND** 文档包含：项目结构、流程图、各模块实现细节、算法说明、配置说明

## MODIFIED Requirements

### Requirement: 标题文字时长
原标题文字"财富认知"使用硬编码300秒时长。修改为动态计算：在所有音频片段添加完成后，使用 `current_time`（音频总时长）作为标题显示时长。

### Requirement: 文件命名规则
原文件命名使用 `audio_{timestamp}.mp3` 和 `image_{timestamp}_{hash}.jpg`。修改为携带绑定ID的命名：`TTS_{绑定ID}_{时长ms}.mp3`、`IMG_{绑定ID}_{序号}.jpg`。

### Requirement: 图片生成提示词
原提示词使用单一prompt字段。修改为正面提示词（positive_prompt）+ 负面提示词（negative_prompt）双字段，并固定生成参数。

## REMOVED Requirements

### Requirement: WebUI重构
**Reason**: 当前项目核心需求是自检与绑定验证，WebUI重构属于独立大型任务，不在本次变更范围内。当前Tkinter GUI满足基本操作需求。
**Migration**: 保留现有Tkinter GUI，后续可作为独立spec实施。

### Requirement: MCN浏览器测试
**Reason**: 项目当前不具备MCN内核浏览器环境，该需求超出当前技术栈范围。
**Migration**: 通过自动化自检脚本+两次验证运行替代浏览器测试。

### Requirement: 视频封面自定义
**Reason**: pyJianYingDraft库当前版本不支持视频封面配置，剪映draft格式中封面为独立模块。
**Migration**: 后续版本考虑实现。
