# Tasks

- [x] Task 1: 实现统一绑定ID机制与文件命名规则
  - [x] 1.1 在main()中生成绑定ID列表（格式：B{timestamp}_{index}）
  - [x] 1.2 修改text_to_speech()输出文件命名为TTS_{绑定ID}_{时长ms}.mp3
  - [x] 1.3 修改generate_image()输出文件命名为IMG_{绑定ID}_{序号}.jpg
  - [x] 1.4 在image_data中携带绑定ID信息

- [x] Task 2: 修复标题文字硬编码时长为动态匹配
  - [x] 2.1 将标题文字的trange从固定300秒改为延迟设置
  - [x] 2.2 在所有音频片段添加完成后，使用current_time作为标题时长
  - [x] 2.3 验证标题时长与配音总时长差值≤0.1秒

- [x] Task 3: 实现配音重复检测算法
  - [x] 3.1 创建detect_voice_duplication()函数，比对相邻字幕文本
  - [x] 3.2 检测完全相同的字幕文本（文本重复）
  - [x] 3.3 检测音频时长异常接近的相邻片段（时长差<0.1秒且文本相同）
  - [x] 3.4 在main()中配音生成后调用重复检测

- [x] Task 4: 实现字幕时间轴自检算法
  - [x] 4.1 创建validate_subtitle_sync()函数
  - [x] 4.2 逐句校验字幕文本与原始字幕列表完全匹配
  - [x] 4.3 逐句校验字幕显示时长与对应音频时长差值≤0.5秒
  - [x] 4.4 校验字幕总时长与音频总时长差值≤0.5秒

- [x] Task 5: 实现音频时长与文字模块时长校验
  - [x] 5.1 创建validate_duration_match()函数
  - [x] 5.2 使用mutagen读取所有音频文件实际时长
  - [x] 5.3 计算音频总时长与标题文字时长差值
  - [x] 5.4 差值>0.1秒时标记为校验失败

- [x] Task 6: 实现图片语义绑定自检
  - [x] 6.1 创建validate_image_binding()函数
  - [x] 6.2 校验每张图片的subtitle_indices是否在有效范围内
  - [x] 6.3 校验图片时间范围与对应字幕时间范围一致性
  - [x] 6.4 校验图片无时间重叠

- [x] Task 7: 实现自检结论报告生成
  - [x] 7.1 创建generate_validation_report()函数
  - [x] 7.2 汇总所有自检结果为JSON格式
  - [x] 7.3 报告保存至项目目录下validation_report.json
  - [x] 7.4 所有检查通过时status为PASS，任一失败为FAIL
  - [x] 7.5 在终端输出报告路径和关键指标

- [x] Task 8: 标准化图片生成提示词与固定参数
  - [x] 8.1 修改image_generation.json，新增negative_prompt字段
  - [x] 8.2 修改generate_image_prompts()输出包含positive_prompt和negative_prompt
  - [x] 8.3 修改generate_image()使用固定参数：Seed=4793688095, Steps=50, Guidance Scale=5.8
  - [x] 8.4 修改generate_image()传递negative_prompt到API

- [x] Task 9: 日志路径明确标识与输出
  - [x] 9.1 在工作流完成时输出日志存放路径
  - [x] 9.2 在工作流完成时输出自检报告路径
  - [x] 9.3 确保日志包含所有关键步骤的详细记录

- [x] Task 10: 集成自检流程到main()
  - [x] 10.1 在草稿生成后依次调用所有自检函数
  - [x] 10.2 生成自检报告
  - [x] 10.3 根据自检结果决定是否继续

- [x] Task 11: 两次验证运行
  - [x] 11.1 第一次完整运行，验证无ERROR且自检报告PASS
  - [x] 11.2 第二次完整运行，验证无ERROR且自检报告PASS
  - [x] 11.3 如任一次失败，分析修复后重新验证

- [x] Task 12: 生成完整工程文档
  - [x] 12.1 在项目根目录生成工程文档.md
  - [x] 12.2 包含项目结构、流程图、模块说明、算法细节、配置说明

# Task Dependencies
- [Task 1] 必须最先完成（绑定ID是后续任务的基础）
- [Task 2] 独立，可与Task 1并行
- [Task 3] 依赖 [Task 1]（需要绑定ID进行重复检测）
- [Task 4] 依赖 [Task 2]（需要动态标题时长进行校验）
- [Task 5] 依赖 [Task 2]
- [Task 6] 依赖 [Task 1]
- [Task 7] 依赖 [Task 3, 4, 5, 6]（汇总所有自检结果）
- [Task 8] 独立，可与Task 1-6并行
- [Task 9] 独立
- [Task 10] 依赖 [Task 7]（集成自检流程）
- [Task 11] 依赖 [Task 10]（验证运行）
- [Task 12] 依赖 [Task 11]（验证通过后生成文档）
