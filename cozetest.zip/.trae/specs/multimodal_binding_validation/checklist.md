# Checklist

## 绑定ID机制验证
- [x] 每条字幕分配了唯一绑定ID（格式：B{timestamp}_{index}）
- [x] 配音文件命名遵循TTS_{绑定ID}_{时长ms}.mp3规则
- [x] 图片文件命名遵循IMG_{绑定ID}_{序号}.jpg规则
- [x] 同一绑定ID的配音和图片可通过文件名关联

## 标题文字动态时长验证
- [x] 标题文字时长不再硬编码为300秒
- [x] 标题文字时长等于配音总时长（current_time）
- [x] 标题时长与配音总时长差值≤0.1秒

## 配音重复检测验证
- [x] detect_voice_duplication()函数存在且可调用
- [x] 完全相同的字幕文本被检测为重复
- [x] 时长异常接近（差值<0.1秒）且文本相同的片段被标记
- [x] 重复检测结果记录到自检报告

## 字幕时间轴自检验证
- [x] validate_subtitle_sync()函数存在且可调用
- [x] 字幕文本与原始字幕列表100%匹配
- [x] 每条字幕显示时长与对应音频时长差值≤0.5秒
- [x] 字幕总时长与音频总时长差值≤0.5秒

## 音频时长校验验证
- [x] validate_duration_match()函数存在且可调用
- [x] 使用mutagen读取音频文件实际时长
- [x] 音频总时长与标题文字时长差值≤0.1秒
- [x] 差值超标时自检报告标记为失败

## 图片语义绑定自检验证
- [x] validate_image_binding()函数存在且可调用
- [x] 每张图片的subtitle_indices在有效范围内
- [x] 图片时间范围与对应字幕时间范围一致
- [x] 图片无时间重叠

## 自检报告验证
- [x] generate_validation_report()函数存在且可调用
- [x] 报告为JSON格式，包含所有自检项结果
- [x] 所有检查通过时status为PASS
- [x] 任一检查失败时status为FAIL
- [x] 报告保存至项目目录下validation_report.json
- [x] 终端输出报告路径和关键指标

## 图片提示词标准化验证
- [x] image_generation.json包含negative_prompt字段
- [x] generate_image_prompts()输出包含positive_prompt和negative_prompt
- [x] generate_image()使用固定参数：Seed=4793688095
- [x] generate_image()使用固定参数：Steps=50
- [x] generate_image()使用固定参数：Guidance Scale=5.8
- [x] negative_prompt传递到API调用

## 日志与路径验证
- [x] 工作流完成时输出日志存放路径
- [x] 工作流完成时输出自检报告路径
- [x] 日志路径为c:\Users\18622\Documents\trae_projects\cozetest\logs\app.log
- [x] 自检报告路径为项目目录下validation_report.json

## 集成测试验证
- [x] 第一次完整运行无ERROR且自检报告PASS
- [x] 第二次完整运行无ERROR且自检报告PASS
- [x] 两次运行配音均无重复
- [x] 两次运行字幕同步误差均≤0.5秒

## 工程文档验证
- [x] 工程文档.md存在于项目根目录
- [x] 文档包含项目结构说明
- [x] 文档包含流程图和流程细节
- [x] 文档包含各模块实现方案
- [x] 文档包含算法细节说明
- [x] 文档包含配置说明
