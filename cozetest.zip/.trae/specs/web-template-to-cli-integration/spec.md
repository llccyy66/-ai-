# Web模板到命令行工作流集成 - 产品需求文档

## Overview

- **Summary**: 实现Web界面创建的模板能够被命令行工作流使用，打通Web界面和命令行工作流之间的数据传递，实现模板的跨系统复用。
- **Purpose**: 解决Web界面模板与命令行工作流完全隔离的问题，让用户在Web界面创建的模板能够在命令行工作流中生效。
- **Target Users**: 视频内容创作者、需要批量生成视频的用户、希望通过Web界面设计模板并通过命令行批量处理的用户。

## Why

当前Web界面和命令行工作流是完全独立的两个系统：

- Web界面模板保存在 `web/templates_data.json`
- 命令行工作流使用硬编码参数，不读取任何模板数据
- 用户无法将在Web界面设计的模板应用到命令行工作流中

这导致用户需要重复配置相同的参数，降低了工作效率。

## What Changes

- 添加模板加载功能到命令行工作流
- 修改 `main()` 函数，添加模板ID参数
- 统一Web模板格式与工作流期望格式
- 添加配置传递机制，实现数据共享

## Impact

- **Affected specs**:
  - `custom_template_system`: 模板数据格式定义
  - `template_visual_editor`: Web界面模板编辑功能
- **Affected code**:
  - `工作流测试.py`: 添加模板加载和使用逻辑
  - `web/templates_data.json`: 模板数据存储
  - `web/static/js/app.js`: API接口可能需要调整

## ADDED Requirements

### Requirement: 命令行模板加载功能

系统 SHALL 提供命令行参数，允许用户指定使用的模板ID。

#### Scenario: 使用模板ID运行工作流

- **WHEN** 用户通过命令行运行工作流并指定模板ID
- **THEN** 系统从 `web/templates_data.json` 加载对应模板，并应用模板配置

### Requirement: 模板配置应用

系统 SHALL 将Web界面创建的模板配置（背景颜色、标题样式、字幕样式等）应用到剪映草稿生成过程中。

#### Scenario: 应用封面模板配置

- **WHEN** 工作流加载了封面模板
- **THEN** 生成的剪映草稿使用模板中定义的颜色、字体、位置等配置

### Requirement: 模板验证与回退

系统 SHALL 在模板加载失败时使用默认配置，并记录警告日志。

#### Scenario: 模板加载失败

- **WHEN** 指定的模板ID不存在或模板数据损坏
- **THEN** 系统使用默认配置继续运行，并在日志中记录警告

## MODIFIED Requirements

### Requirement: main() 函数参数扩展

**Original**: `main()` 函数使用硬编码参数
**Modified**: `main()` 函数接受命令行参数，包括模板ID

#### Scenario: 带参数运行工作流

- **WHEN** 用户运行 `python 工作流测试.py --template-id 123`
- **THEN** 系统加载ID为123的模板并应用配置

## REMOVED Requirements

无

## Open Questions

- [ ] 模板数据中需要包含哪些具体配置项？
- [ ] 命令行参数的具体格式是什么？
- [ ] 模板配置如何映射到剪映草稿生成参数？
- [ ] 是否需要支持模板预览功能？需要

