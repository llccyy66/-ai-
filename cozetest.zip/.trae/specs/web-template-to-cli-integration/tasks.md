# Web模板到命令行工作流集成 - 实现计划

## [x] 任务 1: 分析现有模板数据格式和命令行工作流参数
- **Priority**: P0
- **Depends On**: 无
- **Description**:
  - 分析 `web/templates_data.json` 的模板数据格式
  - 分析命令行工作流 (`工作流测试.py`) 需要哪些配置参数
  - 确定需要映射的配置项
- **Acceptance Criteria Addressed**: AC-1
- **Test Requirements**:
  - `programmatic` TR-1.1: 确认模板数据格式包含所有必要字段
  - `programmatic` TR-1.2: 确认工作流需要哪些配置参数
- **Notes**: 这是集成的基础，需要先明确数据格式和参数需求

## [ ] 任务 2: 设计模板数据格式扩展方案
- **Priority**: P0
- **Depends On**: 任务 1
- **Description**:
  - 设计统一的模板数据格式
  - 确定配置项与剪映草稿生成参数的映射关系
  - 编写模板数据验证逻辑
- **Acceptance Criteria Addressed**: AC-1, AC-3
- **Test Requirements**:
  - `programmatic` TR-2.1: 模板数据格式能够表达所有必要的配置
  - `programmatic` TR-2.2: 配置项映射关系正确
- **Notes**: 需要确保新格式与现有格式兼容

## [ ] 任务 3: 实现命令行参数解析
- **Priority**: P0
- **Depends On**: 任务 2
- **Description**:
  - 修改 `main()` 函数，添加命令行参数解析
  - 支持 `--template-id` 参数指定模板
  - 支持 `--list-templates` 参数列出可用模板
  - 添加帮助信息说明参数用法
- **Acceptance Criteria Addressed**: AC-2
- **Test Requirements**:
  - `programmatic` TR-3.1: `python 工作流测试.py --template-id 123` 能够正确解析参数
  - `programmatic` TR-3.2: `python 工作流测试.py --list-templates` 能够列出所有可用模板
  - `programmatic` TR-3.3: 帮助信息正确显示
- **Notes**: 使用argparse模块解析命令行参数

## [ ] 任务 4: 实现模板加载功能
- **Priority**: P0
- **Depends On**: 任务 3
- **Description**:
  - 实现从 `web/templates_data.json` 加载模板的函数
  - 实现模板数据验证和错误处理
  - 实现模板配置与工作流参数的映射
- **Acceptance Criteria Addressed**: AC-2, AC-3
- **Test Requirements**:
  - `programmatic` TR-4.1: 加载存在的模板ID返回正确的模板数据
  - `programmatic` TR-4.2: 加载不存在的模板ID返回None或抛出异常
  - `programmatic` TR-4.3: 模板数据损坏时能够正确处理
- **Notes**: 需要处理文件不存在、JSON解析错误等情况

## [ ] 任务 5: 实现模板配置应用到剪映草稿生成
- **Priority**: P0
- **Depends On**: 任务 4
- **Description**:
  - 修改剪映草稿生成逻辑，支持使用模板配置
  - 将模板中的背景颜色、标题样式、字幕样式等配置应用到生成过程
  - 确保默认配置在模板配置缺失时能够正常工作
- **Acceptance Criteria Addressed**: AC-3, AC-4
- **Test Requirements**:
  - `human-judgment` TR-5.1: 生成的剪映草稿使用了模板配置
  - `human-judgment` TR-5.2: 模板配置缺失时使用默认配置
- **Notes**: 需要修改相关的草稿生成函数

## [ ] 任务 6: 测试完整流程
- **Priority**: P0
- **Depends On**: 任务 5
- **Description**:
  - 在Web界面创建一个测试模板
  - 使用命令行参数指定该模板运行工作流
  - 在剪映中打开生成的草稿，验证模板配置是否生效
- **Acceptance Criteria Addressed**: AC-5
- **Test Requirements**:
  - `human-judgment` TR-6.1: Web界面创建的模板能够被命令行加载
  - `human-judgment` TR-6.2: 命令行生成的草稿包含Web界面中定义的配置
  - `programmatic` TR-6.3: 无报错运行完成
- **Notes**: 需要实际运行工作流进行验证

## Task Dependencies
```
任务1 → 任务2 → 任务3 → 任务4 → 任务5 → 任务6
```