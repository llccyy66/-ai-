# Tasks

- [x] Task 1: 搭建 Flask 后端服务
  - [x] SubTask 1.1: 安装 Flask 依赖
  - [x] SubTask 1.2: 创建 `web_app.py` Flask 应用主文件
  - [x] SubTask 1.3: 实现工作流 API 端点
  - [x] SubTask 1.4: 实现 SocketIO 实时日志推送
  - [x] SubTask 1.5: 实现模型设置 API
  - [x] SubTask 1.6: 实现背景模板 API

- [x] Task 2: 创建 Web 前端界面
  - [x] SubTask 2.1: 创建 `web/static/` 目录结构
  - [x] SubTask 2.2: 创建 `web/templates/index.html` 主页面
  - [x] SubTask 2.3: 实现参数设置面板
  - [x] SubTask 2.4: 实现模型设置弹窗
  - [x] SubTask 2.5: 实现结果显示面板
  - [x] SubTask 2.6: 实现日志面板
  - [x] SubTask 2.7: 实现工作流控制按钮
  - [x] SubTask 2.8: 实现背景模板设置弹窗
  - [x] SubTask 2.9: 编写 CSS 样式

- [x] Task 3: 修改工作流核心逻辑
  - [x] SubTask 3.1: 修改 `generate_video_script` 函数默认1000字
  - [x] SubTask 3.2: 实现 TTS 长文本自动分割机制
  - [x] SubTask 3.3: 优化 Qwen3-ForcedAligner 强制对齐逻辑
  - [x] SubTask 3.4: 修改 `audio_first_workflow` 函数
  - [x] SubTask 3.5: 确保剪映草稿使用完整音频+分割字幕

- [x] Task 4: 编写 Playwright 自动化测试
  - [x] SubTask 4.1: 安装 Playwright 依赖
  - [x] SubTask 4.2: 编写页面加载测试
  - [x] SubTask 4.3: 编写参数设置测试
  - [x] SubTask 4.4: 编写工作流执行测试
  - [x] SubTask 4.5: 编写布局验证测试
  - [x] SubTask 4.6: 编写日志验证测试

- [x] Task 5: 第一次完整运行验证
  - [x] SubTask 5.1: 启动 Flask 服务
  - [x] SubTask 5.2: 运行 Playwright 自动化测试
  - [x] SubTask 5.3: 检查日志无任何 ERROR 或 WARNING
  - [x] SubTask 5.4: 验证生成的剪映草稿包含完整音频和分割字幕

- [x] Task 6: 第二次完整运行验证
  - [x] SubTask 6.1: 重新启动 Flask 服务
  - [x] SubTask 6.2: 再次运行 Playwright 自动化测试
  - [x] SubTask 6.3: 再次检查日志无任何 ERROR 或 WARNING
  - [x] SubTask 6.4: 再次验证生成的剪映草稿包含完整音频和分割字幕

# Task Dependencies
- Task 2 depends on Task 1
- Task 3 depends on nothing (can parallel with Task 1 and 2)
- Task 4 depends on Task 1 and Task 2
- Task 5 depends on Task 1, Task 2, Task 3, Task 4
- Task 6 depends on Task 5
