# Web UI 重构与自动化测试 - 产品需求文档

## Why
当前 GUI 基于 Python Tkinter 实现，界面美观度有限、布局灵活性差，且无法进行自动化测试。需要用 Web UI 技术重构，实现现代化界面、Playwright 自动化测试，并修复工作流中的 TTS 长文本分割和 Qwen3-ForcedAligner 强制对齐问题。

## What Changes
- **BREAKING**: 将 Tkinter GUI 完全替换为 Flask + HTML/CSS/JS 的 Web UI 架构
- 重构工作流逻辑，使用 `audio_first_workflow` 替代旧的分段配音流程
- 实现 TTS 长文本自动分割与分批处理机制（文案1000字时自动分段调用TTS，再拼接音频）
- 确保 Qwen3-ForcedAligner 强制对齐功能正常工作，降级策略作为备选
- 使用 Playwright 编写端到端自动化测试
- 文案生成字数确保为1000字

## Impact
- Affected specs: `gui_layout_optimization`, `full_audio_split_subtitles`, `audio_first_binding`
- Affected code: `gui.py`（完全重写）、`modules/`（全部重写为前端组件）、`工作流测试.py`（修改TTS和强制对齐逻辑）、`utils/style.py`（替换为CSS样式系统）

## ADDED Requirements

### Requirement: Web UI 架构
系统 SHALL 提供基于 Flask 后端 + HTML/CSS/JS 前端的 Web UI，替代原有 Tkinter GUI。

#### Scenario: 用户访问 Web UI
- **WHEN** 用户在浏览器中访问 `http://localhost:5000`
- **THEN** 显示视频工作流生成工具的主界面，包含左侧导航菜单和右侧操作区域

#### Scenario: 参数设置
- **WHEN** 用户在参数设置页面填写主题、作者、字数（默认1000）等信息并提交
- **THEN** 参数被保存到后端，可用于后续工作流执行

#### Scenario: 工作流执行
- **WHEN** 用户点击"开始生成"按钮
- **THEN** 后端异步执行完整工作流（文案生成→完整TTS配音→强制对齐→字幕分割→分镜提示词→图片生成→剪映草稿），前端实时显示进度和日志

### Requirement: TTS 长文本自动分割
系统 SHALL 在 TTS 文本超过 API 限制时自动分割文本，分批调用 TTS API，然后将音频拼接为完整音频。

#### Scenario: 文案超过 TTS 限制
- **WHEN** 文案长度超过 TTS API 的单次限制（约300字符）
- **THEN** 系统自动按标点符号将文案分割为多段，逐段调用 TTS API，然后将生成的多段音频拼接为完整音频文件
- **AND** 拼接后的音频文件时长等于各段音频时长之和
- **AND** 日志中记录分割和拼接的详细信息

### Requirement: Qwen3-ForcedAligner 强制对齐
系统 SHALL 优先使用 Qwen3-ForcedAligner 进行音文强制对齐，当其不可用时降级为文本分割。

#### Scenario: 强制对齐成功
- **WHEN** Qwen3-ForcedAligner 可用且音频文件有效
- **THEN** 返回精确的字幕时间戳，字幕与音频内容精准对齐

#### Scenario: 强制对齐失败降级
- **WHEN** Qwen3-ForcedAligner 不可用（如缺少依赖）
- **THEN** 自动降级为基于标点符号的文本分割，并基于音频总时长估算时间戳
- **AND** 日志中明确记录降级原因

### Requirement: 1000字文案生成
系统 SHALL 生成1000字的视频文案。

#### Scenario: 文案字数
- **WHEN** 用户设置字数为1000并执行工作流
- **THEN** 生成的文案字数在900-1100字之间（允许±10%的浮动）

### Requirement: Playwright 自动化测试
系统 SHALL 提供 Playwright 端到端自动化测试，覆盖所有核心流程。

#### Scenario: 全流程自动化测试
- **WHEN** 运行 Playwright 测试脚本
- **THEN** 自动打开浏览器、访问页面、填写参数、执行工作流、验证结果，所有步骤无错误完成

#### Scenario: 页面布局验证
- **WHEN** Playwright 测试脚本检查页面元素
- **THEN** 所有元素位置正确、无错位、无重叠、样式符合设计规范

### Requirement: 两次运行验证
系统 SHALL 通过两次完整运行验证，两次均无错误才算验收成功。

#### Scenario: 第一次运行
- **WHEN** 执行第一次完整工作流运行
- **THEN** 日志中无任何 ERROR 或 WARNING 级别的问题，工作流成功完成

#### Scenario: 第二次运行
- **WHEN** 执行第二次完整工作流运行
- **THEN** 日志中无任何 ERROR 或 WARNING 级别的问题，工作流成功完成

## MODIFIED Requirements

### Requirement: 工作流流程
原流程（分段配音）替换为新流程（音频优先）：
1. 生成1000字完整文案（不切割）
2. 完整文案→TTS生成分段音频→拼接为完整音频
3. Qwen3-ForcedAligner 强制对齐（降级为文本分割）
4. 字幕分割与时间戳生成
5. 分镜提示词生成
6. 图片生成
7. 剪映草稿生成（完整音频+分割字幕+图片）

## REMOVED Requirements

### Requirement: Tkinter GUI
**Reason**: 完全替换为 Web UI
**Migration**: 所有 Tkinter 相关代码（gui.py、modules/、utils/style.py、utils/base_module.py）将被 Web UI 代码替代
