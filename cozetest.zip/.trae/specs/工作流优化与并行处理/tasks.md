# 工作流优化与并行处理 - 实现计划

## [ ] Task 1: 实现新版本工作流顺序
- **Priority**: P0
- **Depends On**: None
- **Description**:
  - 修改 `segmented_workflow` 函数，实现新版本工作流顺序
  - 口播稿生成 → 语义群提示词生成&TTS配音生成（并行）→ 千问三强制对齐（与图片生成并行）→ 剪映草稿生成 → 自检
  - 使用 ThreadPoolExecutor 实现并行处理
- **Acceptance Criteria Addressed**: AC-1
- **Test Requirements**:
  - `programmatic` TR-1.1: 验证语义群提示词生成和TTS配音生成并行执行
  - `programmatic` TR-1.2: 验证千问三强制对齐和图片生成并行执行
  - `programmatic` TR-1.3: 验证整体执行顺序符合要求

## [ ] Task 2: 解决工作流重复执行问题
- **Priority**: P0
- **Depends On**: None
- **Description**:
  - 检查并修复 main 函数中的重复调用问题
  - 实现锁机制或队列机制确保工作流只执行一次
  - 验证工作流执行后不再重复执行
- **Acceptance Criteria Addressed**: AC-2
- **Test Requirements**:
  - `programmatic` TR-2.1: 验证工作流只执行一次
  - `programmatic` TR-2.2: 验证没有重复的处理步骤

## [ ] Task 3: 增强API限流处理
- **Priority**: P0
- **Depends On**: None
- **Description**:
  - 修改 `batch_generate_images` 函数，将并发数从2减少到1
  - 修改 `generate_image` 函数，增加最大重试次数到8次
  - 增加重试延迟最大值到60秒
  - 实现请求队列，按顺序生成图片
- **Acceptance Criteria Addressed**: AC-3
- **Test Requirements**:
  - `programmatic` TR-3.1: 验证并发数为1
  - `programmatic` TR-3.2: 验证最大重试次数为8次
  - `programmatic` TR-3.3: 验证重试延迟最大值为60秒
  - `programmatic` TR-3.4: 验证图片生成失败率降低到10%以下

## [ ] Task 4: 编写API限流政策摸底测试程序
- **Priority**: P1
- **Depends On**: None
- **Description**:
  - 创建 `test_rate_limit.py` 文件
  - 实现不同并发数、重试次数和延迟策略的测试
  - 测试不同参数组合下的成功率和效率
  - 生成测试报告，推荐最佳参数组合
- **Acceptance Criteria Addressed**: FR-3
- **Test Requirements**:
  - `programmatic` TR-4.1: 验证测试程序能够测试不同参数组合
  - `programmatic` TR-4.2: 验证测试程序生成详细的测试报告
  - `programmatic` TR-4.3: 验证测试程序推荐最佳参数组合

## [ ] Task 5: 实现图片生成失败的处理策略
- **Priority**: P0
- **Depends On**: Task 3
- **Description**:
  - 实现 `create_blank_image` 函数，生成空白图片
  - 实现 `add_prompt_subtitle` 函数，为空白图片添加提示词字幕
  - 修改 `batch_generate_images` 函数，当图片生成失败时使用空白图片替代
  - 确保字幕时间长度与图片时间长度一致
- **Acceptance Criteria Addressed**: AC-4
- **Test Requirements**:
  - `programmatic` TR-5.1: 验证图片生成失败时使用空白图片替代
  - `programmatic` TR-5.2: 验证空白图片添加了包含提示词的字幕
  - `programmatic` TR-5.3: 验证字幕时间长度与图片时间长度一致

## [ ] Task 6: 性能测试与优化
- **Priority**: P1
- **Depends On**: Task 1, Task 2, Task 3, Task 5
- **Description**:
  - 运行工作流测试，测量处理时间
  - 验证并行处理的效果
  - 优化线程池大小和其他参数
- **Acceptance Criteria Addressed**: NFR-1
- **Test Requirements**:
  - `programmatic` TR-6.1: 验证整体处理时间不超过原有流程
  - `programmatic` TR-6.2: 验证并行处理正常工作

## [ ] Task 7: 集成测试与验证
- **Priority**: P0
- **Depends On**: Task 1, Task 2, Task 3, Task 5, Task 6
- **Description**:
  - 运行完整的工作流测试
  - 验证所有功能正常工作
  - 验证图片生成失败处理策略有效
- **Acceptance Criteria Addressed**: All
- **Test Requirements**:
  - `programmatic` TR-7.1: 验证完整工作流正常执行
  - `programmatic` TR-7.2: 验证图片生成失败时的处理策略
  - `programmatic` TR-7.3: 验证最终输出结果符合要求

## Task Dependencies
- Task 5 依赖 Task 3（需要先修改图片生成逻辑）
- Task 6 依赖 Task 1, Task 2, Task 3, Task 5（需要所有功能实现后进行测试）
- Task 7 依赖所有其他任务
