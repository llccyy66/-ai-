# 图片生成策略优化 - 实现计划

## Task 1: 删除降级策略代码
- **Priority**: P0
- **Depends On**: None
- **Description**:
  - 删除 `get_fallback_prompt` 函数
  - 删除 `find_relevant_cache_image` 函数
  - 修改 `batch_generate_images` 函数，移除备用提示词和缓存图片的调用逻辑
- **Acceptance Criteria Addressed**: REMOVED Requirements - 降级策略
- **Test Requirements**:
  - `programmatic`: 验证 get_fallback_prompt 和 find_relevant_cache_image 函数已被删除
  - `programmatic`: 验证 batch_generate_images 中不再调用这两个函数
- **Status**: [x] 已完成

## Task 2: 修改错误处理流程
- **Priority**: P0
- **Depends On**: Task 1
- **Description**:
  - 修改 batch_generate_images 函数的重试失败处理逻辑
  - 5次重试后仍失败，直接抛出异常
  - 记录详细的失败原因，但不尝试任何降级方案
- **Acceptance Criteria Addressed**: ADDED Requirements - 失败即报错
- **Test Requirements**:
  - `programmatic`: 验证重试失败后直接报错，不使用降级方案
  - `programmatic`: 验证错误信息包含详细的失败原因
- **Status**: [x] 已完成

## Task 3: 简化验收流程
- **Priority**: P0
- **Depends On**: None
- **Description**:
  - 删除测试程序中的连续运行逻辑
  - 改为单次运行并返回结果
  - 修改工作流，删除"连续运行成功两次"的要求
- **Acceptance Criteria Addressed**: ADDED Requirements - 一次结果生成
- **Test Requirements**:
  - `programmatic`: 验证工作流只运行一次
  - `programmatic`: 验证无论自检是否通过，都返回结果
- **Status**: [x] 已完成

## Task 4: 保留并优化重试机制
- **Priority**: P1
- **Depends On**: None
- **Description**:
  - 保留 API 限流检测和 Retry-After 解析
  - 保留指数退避策略（最大5次重试）
  - 保留超时处理
- **Acceptance Criteria Addressed**: ADDED Requirements - 智能重试机制
- **Test Requirements**:
  - `programmatic`: 验证 API 限流时正确处理 Retry-After
  - `programmatic`: 验证指数退避策略正确执行
  - `programmatic`: 验证超时处理正确
- **Status**: [x] 已完成（原有的重试机制已保留）

## Task 5: 集成测试与验证
- **Priority**: P0
- **Depends On**: Task 1, Task 2, Task 3, Task 4
- **Description**:
  - 运行工作流测试
  - 验证图片生成流程正常工作
  - 验证失败时直接报错，不使用降级方案
- **Acceptance Criteria Addressed**: All
- **Test Requirements**:
  - `programmatic`: 验证工作流正常执行
  - `programmatic`: 验证图片生成失败时正确报错
  - `programmatic`: 验证错误信息清晰明确
- **Status**: [ ] 待验证

## Task Dependencies
- Task 2 依赖 Task 1（需要先删除降级策略代码）
- Task 5 依赖 Task 1, Task 2, Task 3, Task 4
