# 剪映草稿生成修复 - 产品需求文档

## Overview
- **Summary**: 修复剪映草稿生成功能，确保生成的草稿能够在剪映中正常打开。根据 pyJianYingDraft 的正确使用步骤，优化草稿生成流程。
- **Purpose**: 解决当前生成的剪映草稿无法打开的问题，确保工作流能够完整生成可使用的剪映草稿。
- **Target Users**: 需要使用工作流生成剪映草稿的用户。

## Goals
- 确保生成的剪映草稿能够在剪映中正常打开
- 优化草稿生成流程，符合 pyJianYingDraft 的正确使用步骤
- 确保素材路径正确引用
- 确保时间线设置正确

## Non-Goals (Out of Scope)
- 不修改工作流的其他功能（文案生成、字幕分割、图片生成、配音生成）
- 不修改 pyJianYingDraft 库的代码
- 不添加新的功能，仅修复草稿生成问题

## Background & Context
- 当前工作流已经实现了文案生成、字幕分割、图片生成、配音生成等功能
- 但生成的剪映草稿无法在剪映中打开
- 用户提供了 pyJianYingDraft 的基础使用步骤，包括安装依赖、准备素材、编写脚本、调用 Draft() 接口

## Functional Requirements
- **FR-1**: 正确使用 pyJianYingDraft 的 Draft() 接口生成草稿
- **FR-2**: 确保素材路径正确引用
- **FR-3**: 确保时间线设置正确
- **FR-4**: 确保生成的草稿结构符合剪映要求

## Non-Functional Requirements
- **NFR-1**: 生成的草稿能够在剪映中正常打开
- **NFR-2**: 草稿生成过程稳定，无错误
- **NFR-3**: 代码结构清晰，易于维护

## Constraints
- **Technical**: 使用 pyJianYingDraft 库生成剪映草稿
- **Dependencies**: 依赖 pyJianYingDraft 库及其依赖项

## Assumptions
- pyJianYingDraft 库已经正确安装
- 素材文件（图片、音频）已经正确生成
- 剪映软件已经安装并正常运行

## Acceptance Criteria

### AC-1: 草稿生成流程正确
- **Given**: 工作流正常运行
- **When**: 调用剪映草稿生成功能
- **Then**: 能够正确使用 pyJianYingDraft 的 Draft() 接口生成草稿
- **Verification**: `programmatic`

### AC-2: 草稿能够在剪映中打开
- **Given**: 草稿生成完成
- **When**: 在剪映中打开生成的草稿
- **Then**: 剪映能够正常加载草稿，显示所有素材
- **Verification**: `human-judgment`

### AC-3: 素材路径正确
- **Given**: 草稿生成完成
- **When**: 检查草稿文件中的素材路径
- **Then**: 所有素材路径都是正确的绝对路径
- **Verification**: `programmatic`

### AC-4: 时间线设置正确
- **Given**: 草稿生成完成
- **When**: 检查草稿文件中的时间线设置
- **Then**: 时间线设置正确，片段时间范围合理
- **Verification**: `programmatic`

## Open Questions
- [ ] 如何正确使用 pyJianYingDraft 的 Draft() 接口？
- [ ] 素材路径应该如何正确引用？
- [ ] 时间线设置的最佳实践是什么？