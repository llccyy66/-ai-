# 视频处理优化 - 实现计划

## \[x] Task 1: 分析并修复字幕乱码问题

* **Priority**: P0

* **Depends On**: None

* **Description**:

  * 分析pyJianYingDraft库的字幕保存机制

  * 找出字幕乱码的具体原因

  * 实现工作流层面的修复方案

* **Acceptance Criteria Addressed**: AC-1

* **Test Requirements**:

  * `human-judgment` TR-1.1: 打开生成的草稿，检查所有字幕是否正确显示

  * `programmatic` TR-1.2: 检查draft\_content.json文件中的字幕内容是否正确

* **Notes**: 重点检查pyJianYingDraft库的export\_material方法和script\_file.py中的保存逻辑

## \[x] Task 2: 优化图片生成逻辑

* **Priority**: P0

* **Depends On**: None

* **Description**:

  * 修改build\_binding\_data函数，实现5-10秒的时间范围

  * 结合语义群信息，确保图片与内容匹配

  * 优化图片分配算法，避免重复使用相同的提示词

* **Acceptance Criteria Addressed**: AC-2

* **Test Requirements**:

  * `programmatic` TR-2.1: 1分49秒视频生成10-20张图片

  * `human-judgment` TR-2.2: 图片内容与对应时间段的语音内容匹配

* **Notes**: 确保图片生成数量符合要求，同时保持语义相关性

## \[x] Task 3: 优化语音文本处理流程

* **Priority**: P0

* **Depends On**: None

* **Description**:

  * 分析\_compare\_and\_fix\_text函数的逻辑

  * 优化文本相似度计算和判断逻辑

  * 减少不必要的TTS重新生成

* **Acceptance Criteria Addressed**: AC-3

* **Test Requirements**:

  * `programmatic` TR-3.1: 处理时间比优化前减少30%

  * `programmatic` TR-3.2: 减少TTS重新生成的次数

* **Notes**: 重点优化文本校验逻辑，提高判断准确性

## \[/] Task 4: 测试验证

* **Priority**: P1

* **Depends On**: Task 1, Task 2, Task 3

* **Description**:

  * 运行完整的视频处理流程

  * 验证三个问题是否都已解决

  * 确保两次运行都能成功

* **Acceptance Criteria Addressed**: AC-1, AC-2, AC-3

* **Test Requirements**:

  * `programmatic` TR-4.1: 两次运行都能成功完成

  * `human-judgment` TR-4.2: 最终视频质量符合要求

* **Notes**: 确保修复后的流程稳定可靠

