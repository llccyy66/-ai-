# Tasks

- [x] Task 1: 重构Web UI导航和布局框架
  - [ ] SubTask 1.1: 修改index.html，将导航菜单从5项扩展为8项（参数设置、模型设置、限流测试、提示词编辑、背景模板、结果显示、历史记录、日志面板）
  - [ ] SubTask 1.2: 为新增面板创建HTML结构
  - [ ] SubTask 1.3: 更新CSS样式，支持8个面板的布局

- [x] Task 2: 实现API限流测试页面
  - [ ] SubTask 2.1: 在web_app.py中添加限流测试API端点（/api/rate_limit/start, /api/rate_limit/status, /api/rate_limit/report）
  - [ ] SubTask 2.2: 在前端实现限流测试页面，包含测试配置、实时进度、测试报告展示
  - [ ] SubTask 2.3: 集成test_rate_limit.py的分阶段测试、参数分组测试、动态调整功能

- [x] Task 3: 实现模型状态检测面板
  - [ ] SubTask 3.1: 在web_app.py中添加模型状态API端点（/api/model_status）
  - [ ] SubTask 3.2: 在前端实现模型状态面板，展示LLM/TTS/图像模型的实时状态和额度

- [x] Task 4: 实现提示词编辑器
  - [ ] SubTask 4.1: 在web_app.py中添加提示词API端点（/api/prompts GET/PUT）
  - [ ] SubTask 4.2: 在前端实现提示词编辑器，支持编辑文案生成、图片生成、TTS配置提示词
  - [ ] SubTask 4.3: 实现提示词保存功能，更新对应的JSON配置文件

- [x] Task 5: 增强结果显示面板
  - [ ] SubTask 5.1: 在web_app.py中添加结果详情API端点（/api/result_detail）
  - [ ] SubTask 5.2: 在前端实现图片预览（缩略图网格）、音频播放器、字幕文本预览
  - [ ] SubTask 5.3: 实现草稿验证报告展示（字幕同步、时长匹配、图片绑定检查结果）

- [x] Task 6: 实现历史记录页面
  - [ ] SubTask 6.1: 在web_app.py中添加历史记录API端点（/api/history GET）
  - [ ] SubTask 6.2: 在前端实现历史记录列表，展示主题、时间、状态
  - [ ] SubTask 6.3: 实现历史详情查看，支持查看图片、音频、字幕等

- [x] Task 7: 增强模板管理
  - [ ] SubTask 7.1: 在web_app.py中增强模板API，支持完整的背景模板配置
  - [ ] SubTask 7.2: 在前端实现完整的模板编辑器（背景颜色、标题文字/字号/颜色、字幕字号、淡入淡出时长）

- [x] Task 8: 增强工作流进度显示
  - [ ] SubTask 8.1: 修改web_app.py的工作流进度推送，包含每个步骤的详细信息
  - [ ] SubTask 8.2: 在前端实现步骤详情展示（步骤名称、耗时、时间戳）

- [x] Task 9: 测试和验证
  - [ ] SubTask 9.1: 启动Web应用，验证所有页面正常加载
  - [ ] SubTask 9.2: 测试API限流测试功能
  - [ ] SubTask 9.3: 测试模型状态检测功能
  - [ ] SubTask 9.4: 测试提示词编辑功能
  - [ ] SubTask 9.5: 测试结果显示和历史记录功能

# Task Dependencies
- [Task 2] depends on [Task 1]
- [Task 3] depends on [Task 1]
- [Task 4] depends on [Task 1]
- [Task 5] depends on [Task 1]
- [Task 6] depends on [Task 1]
- [Task 7] depends on [Task 1]
- [Task 8] depends on [Task 1]
- [Task 9] depends on [Task 2, Task 3, Task 4, Task 5, Task 6, Task 7, Task 8]
