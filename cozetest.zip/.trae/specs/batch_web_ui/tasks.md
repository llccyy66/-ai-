# Tasks

- [x] Task 1: 扩展web_app.py后端API - 点子生成器API
  - [x] SubTask 1.1: 新增 `/api/ideas/generate` POST路由，调用idea_generator.generate_topics
  - [x] SubTask 1.2: 新增 `/api/ideas/import` POST路由，支持手动导入主题列表
  - [x] SubTask 1.3: 新增 `/api/ideas/export` GET路由，导出当前主题列表
  - [x] SubTask 1.4: 新增 `/api/ideas/create_tasks` POST路由，调用idea_generator.create_init_tasks将选中主题转为任务

- [x] Task 2: 扩展web_app.py后端API - 批量处理API
  - [x] SubTask 2.1: 新增 `/api/batch/load` GET路由，加载任务队列
  - [x] SubTask 2.2: 新增 `/api/batch/save` POST路由，保存任务队列
  - [x] SubTask 2.3: 新增 `/api/batch/tasks` GET/POST路由，获取/添加任务
  - [x] SubTask 2.4: 新增 `/api/batch/tasks/<id>` GET/PUT/DELETE路由，任务详情/更新/删除
  - [x] SubTask 2.5: 新增 `/api/batch/tasks/<id>/script` GET/PUT路由，获取/更新口播稿
  - [x] SubTask 2.6: 新增 `/api/batch/start` POST路由，启动批量执行（调用IntegratedHeteroScheduler）
  - [x] SubTask 2.7: 新增 `/api/batch/pause` POST路由，暂停执行
  - [x] SubTask 2.8: 新增 `/api/batch/stop` POST路由，停止执行
  - [x] SubTask 2.9: 新增 `/api/batch/status` GET路由，获取执行状态
  - [x] SubTask 2.10: 新增 `/api/batch/import` POST和`/api/batch/export` GET路由，导入导出任务

- [x] Task 3: 扩展web_app.py后端 - SocketIO事件和批量执行线程
  - [x] SubTask 3.1: 新增SocketIO事件处理（batch_status_update、batch_log、batch_progress、batch_complete、batch_error）
  - [x] SubTask 3.2: 实现批量执行线程，在线程中运行IntegratedHeteroScheduler.run()，通过SocketIO推送进度
  - [x] SubTask 3.3: 实现余额不足检测，遇到余额不足错误时终止执行并通知前端

- [x] Task 4: 创建批量处理主页面 batch.html
  - [x] SubTask 4.1: 创建页面骨架，包含左侧导航面板和主内容区
  - [x] SubTask 4.2: 实现左侧导航面板（点子生成器/任务队列/批量执行/执行统计/执行日志）
  - [x] SubTask 4.3: 添加路由 `/batch` 渲染batch.html

- [x] Task 5: 实现点子生成器前端组件
  - [x] SubTask 5.1: 生成配置面板（主题数量、内容分类、模型选择、Temperature滑块）
  - [x] SubTask 5.2: 主题列表展示（带勾选框、全选/反选、选中计数）
  - [x] SubTask 5.3: 批量操作面板（作者模板、字数设置、A/B类分配、创建任务队列按钮）
  - [x] SubTask 5.4: 生成进度动画和实时日志显示
  - [x] SubTask 5.5: 成功/失败提示弹窗

- [x] Task 6: 实现任务队列前端组件
  - [x] SubTask 6.1: 任务列表视图（卡片式布局，显示主题、作者、字数、类型、状态、操作按钮）
  - [x] SubTask 6.2: 搜索和过滤功能（关键词搜索、状态筛选、类型筛选）
  - [x] SubTask 6.3: 任务操作按钮（执行、编辑文案、预览、删除）
  - [x] SubTask 6.4: 批量操作工具栏（全选、反选、批量删除、重新执行失败任务、导入、导出）

- [x] Task 7: 实现批量执行控制前端组件
  - [x] SubTask 7.1: 执行控制按钮组（启动全部、暂停、停止）
  - [x] SubTask 7.2: 进度条和状态显示
  - [x] SubTask 7.3: 执行统计卡片（总数、已完成、失败、待处理、处理中）
  - [x] SubTask 7.4: SocketIO实时更新绑定

- [x] Task 8: 实现文案编辑器前端组件
  - [x] SubTask 8.1: 编辑器模态框（任务基本信息、字数统计、口播稿内容区）
  - [x] SubTask 8.2: 分段查看/编辑功能
  - [x] SubTask 8.3: 语气词工具栏（lip-smacking、clear-throat、em、hissing）和插入功能
  - [x] SubTask 8.4: 字数实时统计（去除语气词标签后计算，与目标字数对比）
  - [x] SubTask 8.5: 自动保存（2秒防抖）和快捷键支持（Ctrl+S保存、Ctrl+Enter确认、Esc取消）

- [x] Task 9: 实现执行日志前端组件
  - [x] SubTask 9.1: 实时日志面板（滚动显示、自动滚底）
  - [x] SubTask 9.2: 日志级别颜色区分（info/warning/error）

- [x] Task 10: 创建批量处理样式文件 batch.css
  - [x] SubTask 10.1: 与现有style.css风格一致的暗色主题样式
  - [x] SubTask 10.2: 响应式布局适配

- [x] Task 11: 集成测试和功能验证
  - [x] SubTask 11.1: 启动Web服务，验证所有页面可正常访问
  - [x] SubTask 11.2: 测试点子生成器完整流程（生成->筛选->创建任务）
  - [x] SubTask 11.3: 测试任务队列CRUD操作
  - [x] SubTask 11.4: 测试文案编辑器（编辑、语气词插入、自动保存）
  - [x] SubTask 11.5: 测试批量执行控制（启动/暂停/停止），严格确保最多生成3张图片
  - [x] SubTask 11.6: 遇到余额不足时终止测试，继续其他功能验证
  - [x] SubTask 11.7: 审查Web界面的人性化和直觉性

# Task Dependencies
- [Task 2] depends on [Task 1] (批量处理API依赖点子生成器API的基础结构)
- [Task 3] depends on [Task 2] (SocketIO事件依赖API路由定义)
- [Task 5] depends on [Task 1] (前端组件依赖后端API)
- [Task 6] depends on [Task 2] (前端组件依赖后端API)
- [Task 7] depends on [Task 3] (执行控制依赖SocketIO事件)
- [Task 8] depends on [Task 2] (文案编辑器依赖任务API)
- [Task 11] depends on [Task 4, Task 5, Task 6, Task 7, Task 8, Task 9, Task 10] (集成测试依赖所有前端组件完成)
- [Task 1, Task 4, Task 10] 可并行执行
- [Task 5, Task 6, Task 7, Task 8, Task 9] 在对应后端API完成后可并行执行
