# 点子生成器 & 批量处理 Web UI 规格文档

## Why
当前视频工作流系统（工作流测试.py + hetero_scheduler）已实现完整的单任务视频生成和异构调度能力，但缺少Web界面的批量任务管理、AI点子生成和文案编辑功能，用户只能通过终端操作，效率低下且不直观。

## What Changes
- **新增点子生成器Web模块**：将终端交互的idea_generator.py改造为Web界面，支持AI生成主题、可视化筛选、一键创建任务队列
- **新增批量处理管理Web模块**：在现有batch_queue_app.py基础上扩展，提供完整的任务CRUD、批量执行控制、实时状态监控
- **新增文案编辑器Web模块**：提供口播稿可视化编辑、分段管理、语气词标注插入、字数统计、自动保存
- **扩展web_app.py**：集成批量处理API路由，复用现有Flask+SocketIO架构
- **新增前端页面和资源**：批量处理主页面、点子生成器组件、文案编辑器模态框、对应JS/CSS

## Impact
- Affected specs: web_ui_full_features, batch_queue_integration, task_queue_system
- Affected code: web_app.py（新增API路由）、idea_generator.py（新增Web调用入口）、batch_queue_app.py（合并到主应用）、modules/batch_queue_monitor.py（扩展API）、hetero_scheduler/integrated_scheduler.py（Web集成调用）、任务队列.json（读写）

## ADDED Requirements

### Requirement: 点子生成器Web界面
系统SHALL提供Web界面的点子生成器，支持AI批量生成视频主题。

#### Scenario: 用户生成主题
- **WHEN** 用户设置主题数量、内容分类、生成模型、Temperature参数并点击"开始生成主题"
- **THEN** 系统调用idea_generator.py的generate_topics函数生成主题列表，并在页面实时显示生成进度和日志

#### Scenario: 用户筛选主题
- **WHEN** 主题列表生成完毕后，用户通过勾选/取消勾选筛选主题
- **THEN** 系统显示全选、反选、选中计数功能，用户可自由筛选

#### Scenario: 用户创建任务队列
- **WHEN** 用户设置作者模板、字数、A/B类分配后点击"创建任务队列"
- **THEN** 系统调用idea_generator.py的create_init_tasks函数，将选中主题转为任务写入任务队列.json，显示成功提示

#### Scenario: AI生成失败
- **WHEN** LLM调用失败
- **THEN** 系统使用模拟数据填充，显示警告提示"AI生成失败，使用模拟数据"，允许用户手动编辑

### Requirement: 批量处理管理Web界面
系统SHALL提供完整的批量任务管理界面，包括任务列表、批量执行控制和实时监控。

#### Scenario: 查看任务列表
- **WHEN** 用户进入批量处理模式
- **THEN** 系统从任务队列.json加载所有任务，显示任务列表（含主题、作者、字数、类型、状态、操作按钮），支持搜索、状态过滤、类型过滤

#### Scenario: 任务CRUD操作
- **WHEN** 用户对任务执行增删改查操作
- **THEN** 系统通过task_queue_utils.py操作任务队列.json，实时更新界面，支持单任务执行、编辑文案、预览、删除

#### Scenario: 批量执行控制
- **WHEN** 用户点击"启动全部"/"暂停"/"停止"按钮
- **THEN** 系统调用IntegratedHeteroScheduler的run/pause/stop方法，通过SocketIO实时推送执行进度、日志和状态更新

#### Scenario: 实时状态监控
- **WHEN** 批量执行正在进行
- **THEN** 系统通过SocketIO推送batch_status_update、batch_log、batch_progress、batch_complete事件，前端实时更新进度条、统计卡片和日志面板

### Requirement: 文案编辑器Web界面
系统SHALL提供口播稿可视化编辑器，支持分段管理、语气词标注和字数统计。

#### Scenario: 打开文案编辑器
- **WHEN** 用户在任务列表点击"编辑文案"按钮
- **THEN** 系统弹出模态框，加载任务基本信息（主题、作者、字数、类型）和口播稿内容，支持分段查看

#### Scenario: 编辑口播稿
- **WHEN** 用户在编辑器中修改口播稿内容
- **THEN** 系统实时更新字数统计（去除语气词标签后计算），2秒无操作后自动保存，支持Ctrl+S手动保存

#### Scenario: 插入语气词
- **WHEN** 用户在文本中选中位置并点击语气词按钮
- **THEN** 系统在光标位置插入对应语气词标记（如`(lip-smacking)`、`(clear-throat)`、`(em)`、`(hissing)`），语气词渲染为特殊样式便于识别

#### Scenario: 字数统计
- **WHEN** 口播稿内容发生变化
- **THEN** 系统计算当前字数（去除语气词标签），与目标字数对比，显示"字数合适"/"字数不足"/"超出"状态

### Requirement: 与现有系统集成
系统SHALL与现有工作流测试.py和hetero_scheduler深度集成，复用核心功能。

#### Scenario: 工作流执行
- **WHEN** 批量执行启动时
- **THEN** 系统调用工作流测试.py的segmented_workflow函数执行实际视频生成流程，严格保持图片最多生成3张的限制

#### Scenario: 任务调度
- **WHEN** 批量执行中
- **THEN** 系统通过IntegratedHeteroScheduler实现A类串行、B类并行的异构调度策略

#### Scenario: 余额不足处理
- **WHEN** API调用返回余额不足错误
- **THEN** 系统终止当前执行，显示余额不足提示，保留已完成任务状态

### Requirement: 统一Web界面架构
系统SHALL将所有功能整合到统一的Web界面中，采用左侧导航+主内容区布局。

#### Scenario: 页面导航
- **WHEN** 用户在左侧导航面板点击不同模块
- **THEN** 主内容区切换显示对应功能模块（点子生成器/任务队列/批量执行/执行统计/执行日志）

#### Scenario: 执行统计摘要
- **WHEN** 用户查看导航面板
- **THEN** 导航面板显示任务队列摘要（任务数、完成/失败/待处理）和执行控制按钮

## MODIFIED Requirements

### Requirement: web_app.py扩展
现有web_app.py SHALL新增批量处理相关的API路由和SocketIO事件处理，复用现有Flask+SocketIO架构，端口保持5001。

### Requirement: batch_queue_app.py合并
现有独立运行的batch_queue_app.py（端口5002）的功能SHALL合并到主web_app.py中，通过导航切换访问，不再需要独立端口。

### Requirement: idea_generator.py Web适配
现有终端交互的idea_generator.py SHALL新增Web调用入口函数，保持原有终端功能不变。

## REMOVED Requirements
无移除需求。所有现有功能保持不变，仅新增和扩展。
