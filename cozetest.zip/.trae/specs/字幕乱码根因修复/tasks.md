# Tasks

- [x] Task 1: 修复子进程通信编码问题 - 将stdout通信改为文件通信
  - [x] SubTask 1.1: 修改 qwen3_align_worker.py，增加输出文件路径参数，将结果写入JSON文件而非stdout
  - [x] SubTask 1.2: 修改 _subprocess_align_batch 函数，传递输出文件路径参数，从文件读取结果
  - [x] SubTask 1.3: 修改 _subprocess_align_single 函数，同样使用文件通信
  - [x] SubTask 1.4: 测试验证修复后字幕文本无乱码

- [x] Task 2: 增加字幕乱码自检逻辑
  - [x] SubTask 2.1: 编写 is_garbled_text() 函数，检测文本中是否包含乱码字符
  - [x] SubTask 2.2: 在 validate_draft 函数中增加字幕乱码检测
  - [x] SubTask 2.3: 在终端输出中标注乱码字幕（红色警告）
  - [x] SubTask 2.4: 测试验证自检逻辑能正确检测乱码

- [x] Task 3: 增加字幕文本来源验证
  - [x] SubTask 3.1: 在 binding_data 中保存原始口播稿文本
  - [x] SubTask 3.2: 在自检中对比字幕文本与口播稿原文
  - [x] SubTask 3.3: 测试验证来源验证逻辑

- [x] Task 4: 集成测试与验证
  - [x] SubTask 4.1: 运行完整工作流，验证字幕无乱码
  - [x] SubTask 4.2: 验证自检程序能正确检测乱码
  - [x] SubTask 4.3: 连续两次运行验证稳定性

# Task Dependencies
- Task 2 depends on Task 1
- Task 3 depends on Task 1
- Task 4 depends on Task 1, Task 2, Task 3
