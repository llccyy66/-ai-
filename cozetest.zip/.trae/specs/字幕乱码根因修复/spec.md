# 字幕乱码根因分析与修复 Spec

## Why
终端输出和草稿文件中的字幕仍然显示乱码（如"ͨʡǮһǽĲʶ"），之前的修复未解决根本问题。需要追踪字幕数据的完整流向，定位乱码产生的确切环节，并修复编码问题。

## What Changes
- 修复子进程通信编码问题：qwen3_align_worker.py 输出JSON时，Windows默认stdout编码(GBK)与主进程读取编码(UTF-8)不匹配导致乱码
- 在自检程序中增加乱码检测逻辑：检测字幕文本中是否包含非中文字符的异常字符
- 增加字幕文本来源验证：对比口播稿原文与最终字幕文本，确保一致性

## Impact
- Affected specs: 视频处理测试验证
- Affected code: 工作流测试.py (_subprocess_align_batch, validate_draft), qwen3_align_worker.py

## ADDED Requirements

### Requirement: 子进程通信编码修复
系统 SHALL 确保千问3子进程输出的JSON数据使用UTF-8编码，避免Windows默认GBK编码导致的乱码问题。

#### Scenario: 子进程输出中文JSON
- **WHEN** qwen3_align_worker.py 输出包含中文字符的JSON数据
- **THEN** 主进程能正确读取并解析中文内容，无乱码

### Requirement: 字幕乱码自检
系统 SHALL 在自检阶段检测字幕文本中是否存在乱码，并在发现乱码时报告错误。

#### Scenario: 字幕包含乱码
- **WHEN** 自检程序检查字幕文本
- **THEN** 能自动检测到乱码字符（非中文、非标点、非数字的异常字符），并报告错误

### Requirement: 字幕文本来源验证
系统 SHALL 验证最终字幕文本与口播稿原文的一致性，确保字幕内容正确。

#### Scenario: 字幕文本与口播稿不一致
- **WHEN** 自检程序对比字幕文本与口播稿原文
- **THEN** 能检测到不一致并报告错误

## MODIFIED Requirements

### Requirement: 子进程通信方式
将子进程的stdout通信改为文件通信，彻底避免编码问题。qwen3_align_worker.py 将结果写入JSON文件而非stdout，主进程从文件读取。

## REMOVED Requirements
(None)

## 根因分析

### 字幕数据流路径
```
LLM生成口播稿 → segments[i]["text"] (正确中文)
    ↓
分段TTS → tts_results[i]["text"] (正确中文)
    ↓
写入JSON文件 → input_data[i]["text"] (UTF-8, 正确中文)
    ↓
qwen3_align_worker.py 读取JSON → seg["text"] (UTF-8, 正确中文)
    ↓
_split_text_by_punctuation(text) → sentences (正确中文)
    ↓
_merge_char_timestamps → timestamps[i]["text"] (正确中文)
    ↓
print(json.dumps(output, ensure_ascii=False)) → stdout
    ★★★ 乱码产生点：Windows默认stdout编码为GBK，中文字符被编码为GBK字节
    ↓
主进程读取stdout (encoding='utf-8', errors='ignore')
    ★★★ GBK字节被当作UTF-8解析，产生乱码
    ↓
all_timestamps[i]["text"] → 草稿字幕 (乱码)
```

### 乱码产生原因
1. qwen3_align_worker.py 使用 `print(json.dumps(output, ensure_ascii=False))` 输出结果
2. Windows系统默认stdout编码为GBK(CP936)
3. 中文字符被编码为GBK字节输出到stdout
4. 主进程使用 `encoding='utf-8'` 读取stdout
5. GBK字节被错误地当作UTF-8解析，产生乱码字符
6. `errors='ignore'` 仅忽略完全无效的UTF-8序列，部分有效的GBK字节对会被错误解析为其他Unicode字符

### 修复方案
将子进程通信方式从stdout改为JSON文件：
1. qwen3_align_worker.py 将结果写入输出JSON文件
2. 主进程从输出JSON文件读取结果
3. 文件读写均使用 `encoding='utf-8'`，彻底避免编码问题
