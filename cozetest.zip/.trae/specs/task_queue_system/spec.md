# 短视频批量生产任务队列系统 - 产品需求文档

## Overview
- **Summary**: 基于现有单任务工作流，构建一个支持批量任务管理、串行调度、断点续跑的短视频批量生产任务队列系统
- **Purpose**: 解决用户批量生产短视频的需求，支持主题批量生成、文案审核、串行执行、异常恢复等核心能力
- **Target Users**: 短视频内容创作者、账号运营者、批量视频生产团队

## Goals
- 实现批量视频主题生成与筛选功能
- 构建完整的任务状态机与串行调度机制
- 支持断点续跑，异常中断后自动恢复
- 提供文案审核环节，支持用户手动干预
- 100%兼容现有单任务工作流，最小侵入式改造

## Non-Goals (Out of Scope)
- 不改变现有单任务工作流的业务逻辑
- 不新增独立配置文件，复用现有config.yaml
- 不支持并行任务执行（严格串行）
- 不涉及视频内容分发与发布

## Background & Context
- 现有`工作流测试.py`已具备完整的单任务视频生产能力
- 用户需要批量生产多条视频，且要求文案可审核、流程可干预
- 需要实现强容错机制，避免异常中断导致任务重复执行

## Functional Requirements
- **FR-1**: 批量生成视频主题，支持终端交互筛选
- **FR-2**: 为每个主题创建标准化任务结构（task_id、文件夹、配置）
- **FR-3**: 调用大模型批量生成口播文案，支持人工审核
- **FR-4**: 串行执行任务队列，严格按顺序完成单任务全流程
- **FR-5**: 任务失败自动重试，超过次数标记失败不影响队列
- **FR-6**: 异常中断后重启，自动跳过已完成任务继续执行
- **FR-7**: 支持文生图功能开关，按比例随机分配
- **FR-8**: 双配置备份机制，总控与子任务配置同步更新

## Non-Functional Requirements
- **NFR-1**: 任务状态更新实时持久化，确保断点续跑可靠性
- **NFR-2**: 单任务日志独立存储，便于问题排查
- **NFR-3**: 配置读取失败时有合理的默认值兜底
- **NFR-4**: 用户输入参数严格校验，避免非法输入导致崩溃

## Constraints
- **Technical**: Python 3.x，依赖pyyaml、requests等现有库
- **Business**: 与现有项目结构保持一致，不新增配置文件类型
- **Dependencies**: 依赖现有大模型API、TTS服务、文生图服务

## Assumptions
- 用户已具备可用的大模型API密钥和相关服务配置
- 现有工作流测试.py的单任务逻辑可正常运行
- 用户熟悉终端交互操作

## Acceptance Criteria

### AC-1: 主题生成与筛选
- **Given**: 用户运行idea_generator.py
- **When**: 输入主题数量并选择删除不需要的主题
- **Then**: 生成任务队列.json，包含筛选后的主题列表
- **Verification**: `programmatic`

### AC-2: 任务初始化
- **Given**: 任务队列存在待初始化任务
- **When**: 运行task_scheduler.py
- **Then**: 自动创建子文件夹结构和初始配置文件
- **Verification**: `programmatic`

### AC-3: 文案生成与审核
- **Given**: 任务状态为待生成文案
- **When**: 调度器执行文案生成
- **Then**: 文案写入口播稿.md，状态变为文案审核中
- **Verification**: `programmatic`

### AC-4: 串行任务执行
- **Given**: 任务队列存在待执行任务
- **When**: 调度器运行
- **Then**: 任务按task_id顺序串行执行，前一个完成后才启动下一个
- **Verification**: `programmatic`

### AC-5: 断点续跑
- **Given**: 任务执行中断后重启
- **When**: 重新运行task_scheduler.py
- **Then**: 自动跳过已完成/失败任务，从断点继续
- **Verification**: `programmatic`

### AC-6: 失败重试
- **Given**: 任务执行失败
- **When**: 未超过最大重试次数
- **Then**: 自动重试，状态回滚为待执行
- **Verification**: `programmatic`

### AC-7: 文生图开关
- **Given**: 配置enable_ratio=0.25
- **When**: 创建12个任务
- **Then**: 约3个任务启用文生图，9个使用默认图
- **Verification**: `programmatic`

## Open Questions
- [ ] 用户是否需要特定的文生图比例？当前默认0.25
- [ ] 是否需要支持任务优先级排序？当前仅按task_id顺序