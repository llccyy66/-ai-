# 短视频批量生产任务队列系统 - 实现计划

## [x] Task 1: 修改 config.yaml 添加任务队列配置
- **Priority**: P0
- **Depends On**: None
- **Description**: 
  - 在现有config.yaml末尾追加任务队列专属配置
  - 包含任务队列路径、重试次数、文生图比例等参数
- **Acceptance Criteria Addressed**: AC-7
- **Test Requirements**:
  - `programmatic`: 配置文件可正常读取，参数默认值正确
  - `human-judgment`: 配置结构清晰，注释完整
- **Notes**: 复用现有配置文件，不新增独立配置

## [x] Task 2: 创建 utils.py 公共工具模块
- **Priority**: P0
- **Depends On**: Task 1
- **Description**: 
  - 实现配置读取、任务队列读写、状态更新等工具函数
  - 包含load_global_config、load_task_queue、update_task_status等核心函数
- **Acceptance Criteria Addressed**: AC-2, AC-4, AC-5, AC-6
- **Test Requirements**:
  - `programmatic`: 各工具函数单元测试通过
  - `human-judgment`: 代码结构清晰，函数命名规范
- **Notes**: 所有模块共享调用，确保一致性

## [x] Task 3: 创建 idea_generator.py 点子生成器
- **Priority**: P0
- **Depends On**: Task 2
- **Description**: 
  - 实现主题批量生成、终端筛选、任务初始化功能
  - 支持文生图按比例分配
- **Acceptance Criteria Addressed**: AC-1, AC-2, AC-7
- **Test Requirements**:
  - `programmatic`: 主题生成数量正确，筛选功能正常
  - `human-judgment`: 终端交互友好，提示清晰
- **Notes**: 调用现有大模型配置，无需新增API调用逻辑

## [x] Task 4: 创建 task_scheduler.py 任务调度器
- **Priority**: P0
- **Depends On**: Task 2
- **Description**: 
  - 实现任务批量初始化、文案生成、串行调度执行
  - 包含状态机流转、重试机制、断点续跑逻辑
- **Acceptance Criteria Addressed**: AC-2, AC-3, AC-4, AC-5, AC-6
- **Test Requirements**:
  - `programmatic`: 状态流转正确，串行执行顺序保证
  - `human-judgment`: 日志输出清晰，便于追踪
- **Notes**: 核心调度模块，需严格保证串行执行

## [x] Task 5: 封装工作流测试.py 的 run_single_task 函数
- **Priority**: P0
- **Depends On**: Task 4
- **Description**: 
  - 在现有工作流测试.py中封装标准化入口函数
  - 接收task_config路径参数，执行单任务全流程
- **Acceptance Criteria Addressed**: AC-4
- **Test Requirements**:
  - `programmatic`: 函数调用成功，返回值正确
  - `human-judgment`: 封装不影响原有单任务执行
- **Notes**: 最小侵入式改造，保留原有业务逻辑

## [x] Task 6: 实现双配置备份同步机制
- **Priority**: P1
- **Depends On**: Task 2, Task 4
- **Description**: 
  - 实现总控队列与子任务配置的双向同步
  - 修改任意一处自动同步到另一处
- **Acceptance Criteria Addressed**: AC-8
- **Test Requirements**:
  - `programmatic`: 配置修改后双文件同步更新
  - `human-judgment`: 同步逻辑清晰，有异常处理
- **Notes**: 提高数据安全性，防止配置丢失

## [x] Task 7: 实现单任务日志隔离机制
- **Priority**: P1
- **Depends On**: Task 4
- **Description**: 
  - 为每个任务创建独立日志文件夹
  - 任务执行日志单独存储，便于问题排查
- **Acceptance Criteria Addressed**: NFR-2
- **Test Requirements**:
  - `programmatic`: 任务执行时日志正确写入对应文件夹
  - `human-judgment`: 日志格式统一，便于阅读
- **Notes**: 提升可维护性，便于问题定位

## [x] Task 8: 测试验证与文档完善
- **Priority**: P2
- **Depends On**: All previous tasks
- **Description**: 
  - 端到端测试批量任务执行流程
  - 验证断点续跑、失败重试等核心功能
  - 完善README文档和使用说明
- **Acceptance Criteria Addressed**: All
- **Test Requirements**:
  - `programmatic`: 所有核心功能测试通过
  - `human-judgment`: 文档完整，使用说明清晰
- **Notes**: 确保系统稳定可靠