# 修复终端报错与优化字数 - 验证清单

## 模块安装
- [ ] qwen_asr模块在运行Python环境中可用
- [ ] mutagen模块在运行Python环境中可用

## 字数优化
- [ ] 文案字数从1000改为500

## 终端无报错
- [ ] 运行工作流后终端无 "No module named" 报错
- [ ] 运行工作流后终端无 UnicodeDecodeError 报错
- [ ] 工作流完整运行成功
