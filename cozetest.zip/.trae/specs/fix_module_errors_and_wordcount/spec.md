# 修复终端报错与优化字数 - 产品需求文档

## Why
终端运行时出现两个模块缺失报错（qwen_asr、mutagen），且文案字数1000导致测试时间过长，需要修复报错并将字数改为500。

## What Changes
- 修复 `qwen_asr` 模块导入失败问题（安装到正确的Python环境）
- 修复 `mutagen` 模块导入失败问题（安装到正确的Python环境）
- 将文案字数从1000改为500
- 运行验证确保终端无任何报错

## Impact
- Affected code: `c:\Users\18622\Documents\trae_projects\cozetest\工作流测试.py` 中的 `word_num` 参数
- Affected environment: Python环境需要安装 `qwen_asr` 和 `mutagen`

## ADDED Requirements

### Requirement: 模块安装
系统 SHALL 确保在运行工作流的Python环境中正确安装 `qwen_asr` 和 `mutagen` 模块。

#### Scenario: 模块可用
- **WHEN** 工作流运行到音频时间轴识别步骤
- **THEN** `qwen_asr` 和 `mutagen` 模块应可正常导入，不出现 "No module named" 报错

### Requirement: 字数优化
系统 SHALL 将文案生成字数从1000改为500，以减少测试时间。

#### Scenario: 字数设置
- **WHEN** 运行工作流
- **THEN** 文案生成字数应为500

### Requirement: 终端无报错
系统 SHALL 确保运行过程中终端不出现任何代码报错。

#### Scenario: 运行完成
- **WHEN** 工作流运行完成
- **THEN** 终端中不应出现任何 WARNING 或 ERROR 级别的模块缺失报错

## Acceptance Criteria

### AC-1: qwen_asr模块可用
- **Given**: 工作流运行
- **When**: 执行音频时间轴识别
- **Then**: qwen_asr模块可正常导入，不出现 "No module named 'qwen_asr'" 报错
- **Verification**: `programmatic`

### AC-2: mutagen模块可用
- **Given**: 工作流运行
- **When**: 获取音频时长
- **Then**: mutagen模块可正常导入，不出现 "No module named 'mutagen'" 报错
- **Verification**: `programmatic`

### AC-3: 字数改为500
- **Given**: 工作流运行
- **When**: 生成文案
- **Then**: 文案字数目标为500
- **Verification**: `programmatic`

### AC-4: 终端无报错
- **Given**: 工作流运行完成
- **When**: 检查终端日志
- **Then**: 不出现任何模块缺失相关的 WARNING/ERROR
- **Verification**: `programmatic`
