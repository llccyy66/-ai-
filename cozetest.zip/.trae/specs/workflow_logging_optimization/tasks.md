# 工作流测试脚本优化 - 实现计划

## [ ] Task 1: 实现音频拼接库使用情况日志
- **Priority**: P0
- **Depends On**: None
- **Description**:
  - 修改 `text_to_speech_full` 函数，添加详细的音频拼接库使用情况日志
  - 明确输出当前使用的音频拼接库（ffmpeg）
  - 记录是否出现异常
  - 在自检完成的末尾展示这些细节
- **Acceptance Criteria Addressed**: [AC-1]
- **Test Requirements**:
  - `programmatic` TR-1.1: 音频拼接时输出使用的库名称
  - `programmatic` TR-1.2: 音频拼接异常时输出详细错误信息
  - `programmatic` TR-1.3: 自检完成时输出音频拼接库使用情况汇总
- **Notes**: 重点关注ffmpeg的使用情况和异常处理

## [ ] Task 2: 实现千问3 API调用状态日志
- **Priority**: P0
- **Depends On**: None
- **Description**:
  - 修改 `audio_to_subtitles` 函数，添加千问3 API调用状态日志
  - 明确输出是否正确调用了千问3 API
  - 输出是否触发了降级方案
  - 在工作流结束位置展示这些信息
- **Acceptance Criteria Addressed**: [AC-2]
- **Test Requirements**:
  - `programmatic` TR-2.1: 输出千问3 API调用状态
  - `programmatic` TR-2.2: 输出是否触发降级方案
  - `programmatic` TR-2.3: 工作流结束时输出千问3 API使用情况汇总
- **Notes**: 重点关注强制对齐的执行情况和降级方案的触发条件

## [ ] Task 3: 完善自检报告
- **Priority**: P0
- **Depends On**: Task 1, Task 2
- **Description**:
  - 修改 `validate_image_binding` 函数，完善自检报告
  - 输出字幕数组：逐条列出字幕内容 + 对应时间戳
  - 输出图片数组：列出图片编号/内容 + 对应时间戳
  - 输出配音数组：列出配音内容 + 对应时间戳
  - 核对三个数组的绑定情况
  - 校验时间线上所有素材是否全部成功导入
- **Acceptance Criteria Addressed**: [AC-3]
- **Test Requirements**:
  - `programmatic` TR-3.1: 自检报告包含完整的字幕数组
  - `programmatic` TR-3.2: 自检报告包含完整的图片数组
  - `programmatic` TR-3.3: 自检报告包含完整的配音数组
  - `programmatic` TR-3.4: 自检报告包含绑定情况核对结果
  - `programmatic` TR-3.5: 自检报告包含素材导入校验结果
- **Notes**: 重点关注三个数组的详细信息和绑定核对

## [ ] Task 4: 优化终端输出样式
- **Priority**: P1
- **Depends On**: None
- **Description**:
  - 实现终端彩色输出功能
  - 普通信息（INFO）：白色显示
  - 警告信息（WARN）：黄色显示
  - 错误信息（ERROR）：红色显示
- **Acceptance Criteria Addressed**: [AC-4]
- **Test Requirements**:
  - `human-judgment` TR-4.1: 普通信息白色显示
  - `human-judgment` TR-4.2: 警告信息黄色显示
  - `human-judgment` TR-4.3: 错误信息红色显示
- **Notes**: 可以使用ANSI转义序列实现终端彩色输出

## [ ] Task 5: 运行测试验证
- **Priority**: P0
- **Depends On**: Task 1, Task 2, Task 3, Task 4
- **Description**:
  - 运行 `工作流测试.py` 脚本
  - 验证所有要求的信息是否正确输出
  - 验证自检报告是否完整
  - 验证终端输出样式是否优化
- **Acceptance Criteria Addressed**: [AC-1, AC-2, AC-3, AC-4]
- **Test Requirements**:
  - `programmatic` TR-5.1: 音频拼接库使用情况正确输出
  - `programmatic` TR-5.2: 千问3 API调用状态正确输出
  - `programmatic` TR-5.3: 自检报告包含所有要求的信息
  - `human-judgment` TR-5.4: 终端输出样式符合要求
- **Notes**: 运行过程中注意观察所有要求的信息是否正确输出

## Task Dependencies
- Task 3 依赖于 Task 1 和 Task 2 的完成
- Task 5 依赖于所有其他任务的完成

## 实现建议
1. **音频拼接库日志**：在 `text_to_speech_full` 函数的音频拼接部分添加详细日志，记录使用的库和异常情况
2. **千问3 API日志**：在 `audio_to_subtitles` 函数中添加API调用状态和降级方案触发的详细日志
3. **自检报告**：修改 `validate_image_binding` 函数，扩展自检报告内容，添加三大数组的详细信息
4. **终端彩色输出**：实现一个日志包装函数，根据日志级别输出不同颜色的文本
5. **测试验证**：运行完整的工作流测试，验证所有要求的信息是否正确输出