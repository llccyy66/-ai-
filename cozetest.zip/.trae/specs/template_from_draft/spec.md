# 剪映草稿模板化流程优化 - Product Requirement Document

## Overview
- **Summary**: 实现从剪映草稿导出模板、修改后回传使用的完整流程，确保工作流测试.py能正确调用模板生成字幕
- **Purpose**: 允许用户在剪映中可视化编辑草稿样式，然后将修改后的样式保存为模板供项目使用
- **Target Users**: 视频内容创作者、工作流测试.py的使用者

## Goals
- [x] 支持从剪映草稿目录导出模板配置
- [x] 支持导入剪映草稿作为模板
- [x] 工作流测试.py能正确使用模板生成字幕
- [x] 字幕样式（位置、字体大小、颜色）能从模板读取并应用

## Non-Goals (Out of Scope)
- 不支持视频轨道素材的模板化（仅支持字幕、文字样式）
- 不支持特效、转场的模板化
- 不支持音频轨道的模板化

## Background & Context
- 当前项目使用video_template.py生成剪映草稿
- 用户希望在剪映中调整样式后能复用这些样式
- 工作流测试.py需要使用模板来控制字幕样式

## Functional Requirements
- **FR-1**: 从剪映草稿目录提取字幕样式信息
- **FR-2**: 将提取的样式保存为模板文件（JSON格式）
- **FR-3**: 支持加载剪映草稿作为模板使用
- **FR-4**: 工作流测试.py能调用模板生成符合样式的字幕

## Non-Functional Requirements
- **NFR-1**: 模板文件格式与现有video_template.json兼容
- **NFR-2**: 支持剪映草稿的标准目录结构

## Constraints
- **Technical**: 基于pyJianYingDraft库，遵循剪映草稿格式
- **Dependencies**: 需要解析剪映draft_content.json格式

## Assumptions
- [x] 用户已安装剪映并能正常使用
- [x] 用户知道如何在剪映中保存草稿

## Acceptance Criteria

### AC-1: 从剪映草稿导出模板
- **Given**: 存在一个剪映草稿目录（包含draft_content.json）
- **When**: 运行导出脚本
- **Then**: 生成video_template.json格式的模板文件，包含字幕样式信息
- **Verification**: `programmatic`

### AC-2: 导入剪映草稿作为模板
- **Given**: 存在一个剪映草稿目录
- **When**: 使用VideoTemplate类加载该目录
- **Then**: 模板对象正确包含草稿中的字幕样式
- **Verification**: `programmatic`

### AC-3: 工作流测试.py使用模板生成字幕
- **Given**: 已加载模板，包含字幕样式配置
- **When**: 工作流测试.py调用create_jianying_draft_v2生成草稿
- **Then**: 生成的字幕使用模板中定义的样式（位置、大小、颜色）
- **Verification**: `programmatic`

## Open Questions
- [ ] 剪映草稿中字幕样式的具体字段结构需要确认
