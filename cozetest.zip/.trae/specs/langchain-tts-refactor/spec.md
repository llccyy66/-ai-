# LangChain统一TTS抽象重构 - Product Requirement Document

## Overview
- **Summary**: 重构当前项目的TTS系统，使用LangChain统一TTS抽象层，实现多厂商TTS适配，用户仅需配置API Key即可切换不同TTS服务商。
- **Purpose**: 解决当前项目只支持阿里百炼TTS、代码硬编码、缺乏解耦性和灵活性的问题。
- **Target Users**: 项目开发者和最终用户，需要灵活切换TTS服务商的场景。

## Goals
- [ ] 引入LangChain统一TTS抽象层
- [ ] 实现阿里百炼TTS的LangChain适配器
- [ ] 保留并适配原有的缓存机制
- [ ] 配置文件中可以灵活切换TTS服务商
- [ ] 保持现有功能完全兼容（视频生产流程不受影响）

## Non-Goals (Out of Scope)
- [ ] 不实现声音复刻（voice cloning）功能，暂不考虑
- [ ] 不添加新的TTS特性，只做抽象层适配
- [ ] 不重构非TTS相关的功能
- [ ] 不修改视频合成、字幕生成等其他模块

## Background & Context
- 项目现状：TTS硬编码在`工作流测试.py`中，仅支持阿里百炼，API调用直接写死
- 已有文件：`tts_module.py`提供了独立的TTS模块，但也是阿里百炼专用
- LangChain优势：提供了统一的TTS接口，支持多个厂商（OpenAI, ElevenLabs等），易于扩展
- 技术栈：Python 3.x，当前使用requests调用HTTP API

## Functional Requirements
- **FR-1**: 创建TTS服务抽象层，定义统一接口
- **FR-2**: 实现阿里百炼TTS的适配器，适配LangChain接口
- **FR-3**: 配置文件中可以指定TTS服务商、API Key、模型、音色
- **FR-4**: 保留原有的缓存机制（基于MD5缓存音频文件）
- **FR-5**: 保持`工作流测试.py`中的`text_to_speech`和`text_to_speech_full`函数接口不变
- **FR-6**: 支持灵活切换不同TTS服务商（框架预留扩展点）

## Non-Functional Requirements
- **NFR-1**: 性能不低于现有实现（缓存机制保持效率）
- **NFR-2**: 错误处理和异常提示保持原有质量
- **NFR-3**: 日志输出保持原有格式，便于调试
- **NFR-4**: 向后兼容，现有配置文件可以继续使用

## Constraints
- **Technical**: 
  - 必须基于LangChain实现
  - 保持与现有代码库的兼容性
  - 不能破坏现有视频生产流程
- **Business**:
  - 无需额外的商业授权（使用开源LangChain）
- **Dependencies**:
  - 需要安装langchain相关包
  - 需要保持与现有dashscope包的兼容性

## Assumptions
- [ ] 项目已安装或可以安装langchain相关依赖
- [ ] LangChain已支持或可以自定义支持阿里百炼TTS
- [ ] 用户希望保留现有阿里百炼作为默认TTS服务
- [ ] 现有的缓存机制（cache/audio目录）可以复用

## Acceptance Criteria

### AC-1: LangChain TTS抽象层集成
- **Given**: 项目已安装langchain依赖
- **When**: 查看代码架构
- **Then**: 存在统一的TTS服务抽象层，定义了标准的TTS接口
- **Verification**: `programmatic`

### AC-2: 阿里百炼适配器实现
- **Given**: LangChain抽象层已创建
- **When**: 调用TTS生成语音
- **Then**: 使用阿里百炼TTS，参数通过抽象层传递
- **Verification**: `programmatic`

### AC-3: 配置灵活切换
- **Given**: 有新的配置文件格式
- **When**: 用户修改配置文件中的TTS服务商
- **Then**: 系统自动使用对应服务商的适配器
- **Verification**: `human-judgment`

### AC-4: 缓存机制保留
- **Given**: 缓存目录存在
- **When**: 重复生成相同文本的TTS
- **Then**: 优先使用缓存，不重复调用API
- **Verification**: `programmatic`

### AC-5: 向后兼容性
- **Given**: 现有配置和代码不变
- **When**: 运行完整视频生产流程
- **Then**: 流程正常完成，功能与之前一致
- **Verification**: `programmatic`

## Open Questions
- [ ] LangChain是否原生支持阿里百炼TTS？如果不支持，需要自定义适配器
- [ ] 是否需要支持声音复刻功能？本次重构暂不考虑
- [ ] 除了阿里百炼，还需要预置哪些TTS服务商适配器？（如minimax、OpenAI等）
