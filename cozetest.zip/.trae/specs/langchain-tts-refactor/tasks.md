# LangChain统一TTS抽象重构 - The Implementation Plan (Decomposed and Prioritized Task List)

## [ ] Task 1: 研究LangChain TTS架构和项目依赖分析
- **Priority**: P0
- **Depends On**: None
- **Description**: 
  - 研究LangChain的TTS模块架构，了解其抽象接口设计
  - 检查项目当前的依赖情况，确定需要安装的langchain相关包
  - 验证LangChain是否原生支持阿里百炼TTS
- **Acceptance Criteria Addressed**: [AC-1]
- **Test Requirements**:
  - `programmatic` TR-1.1: 列出项目现有依赖和需要新增的langchain包
  - `human-judgement` TR-1.2: 撰写LangChain TTS架构分析文档
- **Notes**: 如果LangChain不支持阿里百炼，需要设计自定义适配器

## [ ] Task 2: 设计并创建TTS服务抽象层
- **Priority**: P0
- **Depends On**: Task 1
- **Description**: 
  - 定义统一的TTS服务接口，包含text_to_speech方法
  - 设计适配器基类，定义所有TTS服务商需要实现的接口
  - 设计配置结构，支持服务商、API Key、模型、音色等参数
- **Acceptance Criteria Addressed**: [AC-1]
- **Test Requirements**:
  - `programmatic` TR-2.1: 抽象层接口定义完整，包含必要的方法签名
  - `human-judgement` TR-2.2: 接口设计具有良好的可扩展性
- **Notes**: 保留与现有text_to_speech函数的兼容性

## [ ] Task 3: 实现阿里百炼TTS适配器
- **Priority**: P0
- **Depends On**: Task 2
- **Description**: 
  - 实现LangChain兼容的阿里百炼TTS适配器（自定义适配器，如无原生支持）
  - 适配现有阿里百炼的API调用逻辑
  - 支持模型、音色、instructions等参数
- **Acceptance Criteria Addressed**: [AC-2]
- **Test Requirements**:
  - `programmatic` TR-3.1: 适配器能正常调用阿里百炼API生成语音
  - `programmatic` TR-3.2: 支持不同模型(qwen3-tts-flash, qwen3-tts-instruct-flash)和音色
- **Notes**: 参考现有tts_module.py和工作流测试.py中的实现

## [ ] Task 4: 适配缓存机制到新架构
- **Priority**: P0
- **Depends On**: Task 3
- **Description**: 
  - 在TTS抽象层中集成现有的MD5缓存机制
  - 确保缓存键包含text、model、voice等所有影响输出的参数
  - 保持cache/audio目录结构不变
- **Acceptance Criteria Addressed**: [AC-4]
- **Test Requirements**:
  - `programmatic` TR-4.1: 相同文本重复调用优先返回缓存，不调用API
  - `programmatic` TR-4.2: 不同参数的调用产生不同的缓存键
- **Notes**: 保持缓存逻辑与现有实现完全一致

## [ ] Task 5: 更新配置文件支持TTS服务商切换
- **Priority**: P1
- **Depends On**: Task 2
- **Description**: 
  - 扩展utils/config.py，添加TTS服务商配置
  - 添加服务商特定的配置项（API Key、地域等）
  - 保持现有配置向后兼容
- **Acceptance Criteria Addressed**: [AC-3]
- **Test Requirements**:
  - `programmatic` TR-5.1: 配置文件可以指定TTS_PROVIDER
  - `human-judgement` TR-5.2: 配置结构清晰，易于扩展新服务商
- **Notes**: 默认使用bailian（阿里百炼）保持向后兼容

## [ ] Task 6: 重构工作流测试.py中的TTS调用
- **Priority**: P0
- **Depends On**: Task 3, Task 4, Task 5
- **Description**: 
  - 修改工作流测试.py中的text_to_speech函数，使用新的TTS抽象层
  - 保持函数签名不变，确保向后兼容
  - 修改text_to_speech_full函数，同样适配新架构
  - 更新日志输出保持原有格式
- **Acceptance Criteria Addressed**: [AC-5]
- **Test Requirements**:
  - `programmatic` TR-6.1: text_to_speech函数签名与之前完全一致
  - `programmatic` TR-6.2: 调用新TTS抽象层能正常生成语音
  - `human-judgement` TR-6.3: 日志输出格式保持不变
- **Notes**: 这是核心集成任务，需要仔细测试

## [ ] Task 7: 集成测试和端到端验证
- **Priority**: P0
- **Depends On**: Task 6
- **Description**: 
  - 运行完整的视频生产流程，验证TTS功能正常
  - 测试不同模型和音色的切换
  - 验证缓存机制正常工作
  - 检查错误处理和异常提示
- **Acceptance Criteria Addressed**: [AC-5, AC-4]
- **Test Requirements**:
  - `programmatic` TR-7.1: 完整视频生产流程能正常完成
  - `programmatic` TR-7.2: 错误处理与之前保持一致
  - `human-judgement` TR-7.3: 生成的语音质量与之前相当
- **Notes**: 这是最终验证，确保没有回归

## [ ] Task 8: 预留扩展点文档（可选）
- **Priority**: P2
- **Depends On**: Task 2
- **Description**: 
  - 编写如何添加新TTS服务商适配器的文档
  - 提供适配器开发示例模板
  - 记录配置项和扩展规范
- **Acceptance Criteria Addressed**: [AC-6]
- **Test Requirements**:
  - `human-judgement` TR-8.1: 文档清晰，步骤明确
  - `human-judgement` TR-8.2: 示例模板可直接用于开发新适配器
- **Notes**: 方便未来添加minimax、OpenAI等其他服务商
